# Reporting Playbook

Use this reference for weekly reports, monthly reports, client reviews, business reviews, and performance summaries.

For COPC-style management reporting, executive review logic, or challenge-question handling, also read [copc-client-reporting-and-defense.md](copc-client-reporting-and-defense.md) and [copc-management-principles-cn.md](copc-management-principles-cn.md) when the output should sound like Chinese management language rather than standard terminology.

This file is for outputs that should look ready for Word, PPT, or an email summary to leaders or clients.

## Default Structure

1. overall conclusion
2. KPI table
3. trend analysis
4. key highlights
5. key issues and causes
6. corrective actions
7. next-stage priorities

## First-Paragraph Rule

The report should begin with a one-paragraph conclusion, not with a raw KPI list.

Good pattern:

- this week overall operations remained stable, with service level and satisfaction within the controllable range; the main pressure came from evening peak seat shortage and a mild rise in repeat contacts, and corrective actions have already been launched around schedule adjustment and billing-scenario coaching

Avoid:

- please see the KPI status below
- overall operations were normal
- all work progressed smoothly

## KPI Table Rule

Use a KPI block whenever metrics are part of the request.

Preferred table:

| KPI | Target | Actual | Gap | Trend | Main reason | Current action |
| --- | --- | --- | --- | --- | --- | --- |

Guidance:

- target: what the team promised or planned
- actual: the real result for the period
- gap: numeric or directional difference
- trend: up, down, stable, or a short phrase
- main reason: one dominant driver, not a paragraph
- current action: the key fix already underway

## Trend Analysis Rule

When explaining a KPI shift, prefer this sequence:

1. what changed
2. why it changed
3. whether the change is short-term or structural
4. what is being done next

## Internal vs Client-Facing Wording

### Internal version

Use sharper operational judgment:

- the drop in service level is mainly caused by peak-hour understaffing rather than agent willingness
- current repeat-contact pressure is concentrated in billing clarification and transfer scenarios

### Client-facing version

Use accountable but stable wording:

- service level pressure was mainly driven by concentrated peak-hour traffic and temporary seat gap
- repeat-contact pressure is concentrated in a small number of billing and transfer scenarios, and targeted optimization has been initiated

Do not use emotional, defensive, or blame-shifting language in client-facing reports.

## Issue Writing Rule

Every issue line must be paired with:

- cause
- action
- next checkpoint

Bad:

- complaint rate increased and needs attention

Better:

- complaint rate increased mainly in logistics-delay explanations during the campaign period; targeted wording was updated on Wednesday, supervisor side-by-side review has started, and the first checkpoint will be reviewed next Monday

## Highlight Writing Rule

Highlights should not be empty praise. They should show business meaning.

Examples:

- despite a 12 percent week-on-week traffic increase, the team maintained queue recovery within the agreed range through temporary seat coordination and break-window adjustment
- first-response timeliness improved after macro optimization, indicating the current SOP refresh is beginning to translate into handling efficiency

## Next-Stage Priorities Rule

The last section should be specific. Prefer 3 priorities:

1. stabilize the biggest current risk
2. deepen one proven improvement action
3. prepare for the next business node

## Typical Report Types

### Weekly report

Focus on:

- current-state summary
- main KPI shift
- immediate actions
- next-week focus

### Monthly review

Focus on:

- trend across the month
- root causes that repeated
- management effectiveness
- next-month management priorities

### Client review

Focus on:

- stability
- accountability
- corrective action progress
- visible control of risk
- whether the issue is being managed through a credible governance loop rather than only end-period recovery

## Typical User Requests

- 帮我出一版周报
- 帮我整理成月度复盘
- 改成给甲方汇报的口径
- 这组指标怎么汇报更好看
