# COPC Problem-Solving Playbook

Use this file when the user wants to apply COPC to operational diagnosis, service-solution design, outsourcing governance, CX technology planning, or client-facing proposals.

Read this after `copc-core.md` when the task is not just “what is COPC?” but “how does COPC help us solve a real problem?”

## Table of Contents

- Problem-solving stance
- Diagnostic sequence
- Solution-design sequence
- Proposal and outsourcing translation
- Common scenario patterns
- Anti-patterns

## Problem-Solving Stance

Use COPC as a way to force complete management thinking.

When a problem appears, do not jump directly to:

- more staffing
- more training
- a new system
- a new vendor
- a new KPI target

Instead, ask whether the issue is best explained by one or more of these layers:

1. leadership and planning
2. service-journey or process design
3. process control and operating discipline
4. measurement architecture
5. people capability and coaching
6. knowledge and policy usability
7. technology or AI governance
8. weak corrective-action closure

## Diagnostic Sequence

When using COPC to diagnose, follow this sequence.

### 1. Confirm the real result gap

Define the operational outcome that matters:

- customer result
- client result
- service result
- quality or risk result
- cost or productivity result

Do not start from a symptom KPI if the business outcome is still unclear.

### 2. Map the service journey or operating path

Trace the end-to-end path that produces the outcome. Include:

- entry channel
- routing
- handoffs
- self-service or bot steps
- human handling
- back-office dependencies
- closure and follow-up

If the customer crosses teams or channels, assume the journey may explain more than any single departmental report.

### 3. Test the scorecard architecture

Ask:

- are we measuring the right categories
- are customer, quality, service, efficiency, and cost being seen together
- are we hiding reality behind averages or blended scores
- are targets still relevant to current strategy and channel mix

### 4. Separate leadership review from local coaching

Ask whether the issue belongs mainly to:

- program-level governance
- supervisor coaching
- process or policy redesign
- technology or knowledge repair

This keeps management from overusing agent coaching for structural defects.

### 5. Find the dominant cause layer

Use the smallest set of cause layers that explains the gap:

- planning mismatch
- journey friction
- workflow or policy defect
- quality-measurement design failure
- WFM inconsistency
- knowledge breakdown
- insufficient capability transfer
- weak AI or technology controls
- no closed-loop corrective action

### 6. Check whether the governance loop is broken

Even when the cause is known, the deeper failure may be that:

- no owner is assigned
- reviews happen too late
- actions are not verified
- measures are not refreshed
- one function cannot force cross-functional closure

## Solution-Design Sequence

Use this sequence when writing an improvement plan or operational solution.

### 1. Define the operating objective

State the result to improve and the guardrails that cannot be harmed.

### 2. Design around the journey

Specify what must change in the journey:

- fewer handoffs
- clearer decision rights
- better routing
- aligned self-service and human flows
- faster knowledge access
- better visibility of status and ownership

### 3. Set the control system

Define:

- scorecard categories
- review cadence
- owner set
- escalation thresholds
- corrective-action mechanism

### 4. Translate into functional workstreams

Split actions into:

- operations
- WFM
- QA
- training
- knowledge
- process/policy
- technology/AI
- vendor or partner governance

### 5. Add verification logic

Every solution should include:

- proof of adoption
- proof of outcome movement
- proof of stability over time

## Proposal and Outsourcing Translation

When using COPC logic in RFPs, proposals, or supplier governance:

- define the operating objective before defining the supplier profile
- document both contractual and non-contractual requirements
- include process details, WFM assumptions, quality requirements, and governance routines
- evaluate suppliers with weighted criteria, not price alone
- inspect whether the supplier has real capability in leadership, planning, internal processes, people, and historical performance
- use site assessments to test data-backed claims and frontline reality, not only presentation quality

Management meaning:

- good vendor governance starts before go-live, in requirement quality and selection discipline

## Common Scenario Patterns

### KPI good, customer unhappy

Use COPC to inspect:

- journey friction
- wrong quality design
- over-weighted efficiency
- missing expectation management
- broken transitions between self-service and human support

### Service level unstable

Use COPC to inspect:

- whether targets are treated as one static monthly number instead of a consistency band
- whether interval or prime-interval control is weak
- whether over-service cost is being ignored

### QA high, CSAT low

Use COPC to inspect:

- whether the quality form reflects the real customer drivers
- whether customer, business, and compliance quality are blended into one misleading score
- whether scoring is done from the customer perspective

### New AI tool, weak business value

Use COPC to inspect:

- whether the journey requirement was defined before tool selection
- whether data, guardrails, and verification were ready
- whether bot-human handoffs were designed and measured
- whether leaders can detect drift and intervene

### Repeated vendor underperformance

Use COPC to inspect:

- weak initial requirement definition
- weak scorecard architecture
- poor governance cadence
- unclear roles and responsibilities
- overreliance on contracts instead of performance management

## Anti-Patterns

Avoid:

- using COPC only as a label to make a proposal look stronger
- writing a “COPC-based solution” that contains no review rhythm, no owner logic, and no verification
- treating every performance issue as a frontline behavior problem
- buying technology based on generic features before diagnosing the journey
- letting each site, vendor, or channel build incomparable metrics
