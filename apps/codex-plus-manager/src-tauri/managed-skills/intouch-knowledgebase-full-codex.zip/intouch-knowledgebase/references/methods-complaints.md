# Complaint and Escalation Method

Use for complaint increases, sensitive cases, escalation pressure, repeated complaint scenarios, service recovery, and complaint-driven improvement.

## Management Judgment

Manage complaints on two tracks: contain and resolve the current case, then remove the repeated cause. A case can be closed while the operating risk remains open.

## Cause Structure

Classify complaints by:

- reason and customer expectation gap
- process stage and ownership break
- product, policy, logistics, system, or upstream dependency
- channel, region, team, time, or customer segment
- explanation, promise, consent, privacy, or trust-boundary failure
- escalation suppression caused by unclear authority, punishment pressure, or frontline reluctance to report risk
- severity, repeat pattern, and spread risk

Do not assume complaints are service-attitude issues. In sales or sensitive products, inspect consent, product explanation, rejection handling, recording, data use, and promise consistency.

## Immediate Handling

Use this sequence:

1. stabilize emotion and prevent further spread
2. verify facts, customer expectation, and business record
3. define the accountable owner and next update time
4. solve, compensate, clarify, or escalate within authority
5. confirm customer understanding and closure status
6. preserve evidence and tag the cause

For urgent floor or service incidents, add [event.md](event.md).

## Structural Improvement

- create a complaint reason and stage taxonomy
- identify high-frequency, high-severity, and preventable scenarios
- connect repeated causes to process, policy, knowledge, script, system, or partner owners
- define early-warning and pre-escalation triggers
- set tiered aging thresholds, automatic reminders, and a fast arbitration path for cross-functional cases
- review whether incentives encourage concealment, delayed escalation, or premature closure
- define compensation authority and verify whether compensation removed the cause or only purchased temporary calm
- refresh expectation-setting language and proactive updates
- verify whether the same cause, not only the same case, declines

## Ownership

- frontline/team lead: recognition, first response, complete record, and timely escalation
- complaint owner: customer communication and case closure
- operations: concentration analysis and action integration
- process/product/policy/system/logistics/compliance owners: structural repair
- client or senior management: material risk decision and external communication

## Rhythm

- immediate: severe or spreading case containment
- daily: open high-risk cases and overdue updates
- weekly: reason concentration, repeated causes, and owner closure
- monthly: structural prevention, policy, process, and trust-boundary review

## Metrics and Signals

- complaint and escalation rate with a clear denominator
- repeat complaint or same-cause recurrence
- first response, update, and closure time
- reopen, overdue, and closure-quality rate
- aging by severity, cross-functional handoff time, and escalation-after-delay rate
- frontline early-report rate and cases discovered outside the formal complaint path
- high-severity case count
- complaint linkage to QA, repeat contact, satisfaction, refund, or churn

## Anti-Patterns

Avoid:

- defensive communication or premature blame
- closing the ticket without confirming the customer's issue state
- assigning all complaints to frontline attitude
- measuring speed without closure quality
- using compensation as the default solution without checking fairness, precedent, and recurrence
- penalizing escalation so strongly that risk stays hidden at the frontline
- using one script for every severity and expectation context

## Output Contract

Provide the containment decision, verified facts needed, case owner and update time, structural cause, prevention action, review rhythm, and recurrence indicators.
