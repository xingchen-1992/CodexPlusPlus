# Intouch Maintenance Governance

Use this file when updating the skill, adding sources, or changing routing.

## File Responsibilities

- `SKILL.md`: core role, workflow, output contract, safety, and links to the primary router
- `core-routing-table.md`: the single source of truth for topic-to-reference routing
- `methods-*.md`: reusable management logic and decision rules
- scenario files: business-line, operations, reporting, tender, and event adaptation
- sample libraries: wording support only
- full-text folders and indexes: raw knowledge inputs
- validation assets: evaluation criteria and historical evidence, not live routing requirements

Do not duplicate a routing rule in `SKILL.md`, the router, and several scenario files. Put topic selection in the router and domain detail in the selected reference.

## Update Sequence

For a method or routing change:

1. identify the business problem and intended behavior change
2. update the relevant `methods-*.md` file
3. update `core-routing-table.md` only if topic selection changed
4. update a sample only when expression or deliverable conversion changed
5. keep `SKILL.md` unchanged unless core behavior, scope, or safety changed

For a corpus addition:

1. check source quality, date, duplication, and relevance
2. record governance fields from `knowledge-governance.md`
3. add or refresh the relevant index
4. promote only reusable insights into a method file
5. avoid increasing mandatory reading routes because a new article was added
6. regenerate the governance manifest and review its anomaly summary
7. regenerate the method-promotion digests, review source-text quality, and record promotion decisions in the ledger

For deferred promotion records caused by broken or polluted full text:

1. run `tools/repair-promotion-source-texts.py --dry-run`
2. review validation failures instead of lowering thresholds blindly
3. run the repair without `--dry-run` only after every target validates
4. regenerate the governance manifest before rebuilding method-promotion digests
5. treat repaired records as `ready_for_lane_synthesis` until their recovered evidence is reviewed
6. after manual synthesis, record the decision with `tools/record-method-promotion-review.py` and rebuild the promotion digests

## Size and Duplication Limits

- Keep `SKILL.md` under 500 lines and preferably near 250 lines.
- Keep one primary router.
- Keep each narrow question's default route to one primary method plus at most one scenario file.
- Do not make broad full-text indexes mandatory for routine questions.
- Avoid repeating the same instruction or link in multiple sections.
- Add a table of contents to reference files longer than 100 lines when they lack clear navigation.

## Compatibility Rules

- Preserve the skill name and folder name unless a deliberate migration is approved.
- Preserve existing raw corpus paths when possible; mass renaming creates unnecessary broken-link risk.
- Keep `agents/openai.yaml` aligned with the scope and default workflow in `SKILL.md`.
- Store backups outside the live skill directory so they cannot be mistaken for active references.

## Release Discipline

Before a future release, separate three checks:

1. structural integrity: frontmatter, required files, links, and naming
2. retrieval behavior: whether prompts choose the smallest correct route
3. answer quality: blind evaluation on realistic prompts

Do not treat corpus size, self-authored examples, or a historical score as proof of current production quality.

When validation is intentionally deferred, record the version as structurally revised but not newly behavior-validated.
