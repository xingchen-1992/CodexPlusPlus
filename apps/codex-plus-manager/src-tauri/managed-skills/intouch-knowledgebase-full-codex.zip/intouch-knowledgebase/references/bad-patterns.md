# Bad Patterns Library

Use this file as a negative calibration guide.

The goal is to avoid outputs that look professional at first glance but are weak, generic, or unusable in real management work.

## Pattern 1: Empty Management Verbs

Bad wording:

- strengthen management
- continue to optimize
- improve efficiency
- reinforce execution
- follow up closely

Why it is weak:

- no action
- no owner
- no time node
- no management meaning

Better pattern:

- define what will change
- define who owns it
- define when it will be checked
- define what signal proves improvement

## Pattern 2: KPI Without Diagnosis

Bad pattern:

- service level dropped by 3 points
- AHT increased by 20 seconds
- satisfaction declined

Why it is weak:

- reports the result
- does not explain the driver
- does not help the reader act

Better pattern:

- describe the KPI change
- explain the main cause
- judge whether it is short-term or structural
- state the corrective action

## Pattern 3: Theory Without Management Action

Bad pattern:

- employee retention is important
- training should be improved
- quality management should be strengthened

Why it is weak:

- reads like a textbook
- does not show how to run the operation

Better pattern:

- convert the principle into a daily, weekly, or monthly management action

## Pattern 4: No Internal vs Client Distinction

Bad pattern:

- uses one tone for all audiences

Why it is weak:

- internal reviews need sharper diagnosis
- client reviews need calmer accountability wording

Better pattern:

- internal: direct, diagnostic, operational
- client-facing: stable, accountable, risk-aware

## Pattern 5: Improvement Plan Without Rhythm

Bad pattern:

- optimize schedule
- enhance coaching
- improve knowledge base

Why it is weak:

- no sequence
- no review point
- no stage objective

Better pattern:

- week 1 corrective move
- week 2 stabilization check
- month-end structural review

## Pattern 6: One-Size-Fits-All KPI

Bad pattern:

- uses the same KPI set for voice, chat, annotation, LLM data, and robotics operations

Why it is weak:

- hides business-line differences
- leads to wrong management focus

Better pattern:

- choose KPI based on business line, task risk, and operating objective

## Pattern 7: Output That Cannot Be Pasted Into a Real Document

Bad pattern:

- too conversational
- too repetitive
- too many headings with too little substance

Why it is weak:

- the user still needs to rewrite heavily

Better pattern:

- one opening judgment
- one KPI or diagnosis block
- one action block
- one next-step block

## Final Check

Before sending, ask:

"Would a manager need to rewrite most of this before putting it into a weekly deck, client summary, or action plan?"

If the answer is yes, tighten the output.
