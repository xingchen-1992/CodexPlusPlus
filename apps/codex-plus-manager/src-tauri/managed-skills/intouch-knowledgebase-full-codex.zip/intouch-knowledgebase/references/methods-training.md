# Training and Coaching Method

Use for onboarding, nesting, refresher training, supervisor coaching, repeated errors, capability equalization, and post-training effectiveness.

## Management Judgment

Treat training as behavior conversion, not course delivery. When errors repeat after training, determine whether people know the rule, can apply it in the scenario, receive useful feedback, and sustain the behavior on the floor.

## Cause Structure

Separate:

- target: the business behavior to change is unclear
- audience: different tenure, skill, or role groups receive the same intervention
- content: knowledge is correct but not scenario-based
- practice: learners understand but cannot perform under pressure
- transfer: supervisors do not reinforce the behavior on the floor
- environment: process, tool, policy, or workload prevents correct execution
- measurement: completion or satisfaction is mistaken for effectiveness

## Capability Chain

Use this sequence:

1. diagnose the business gap and target behavior
2. segment the audience and readiness level
3. select the smallest effective learning intervention
4. practice with real scenarios, cases, calls, chats, or tasks
5. define release or completion criteria
6. reinforce on the floor through supervisor coaching
7. recheck behavior and business result

## Intervention Design

Choose the intervention according to the gap:

- knowledge gap: concise explanation and recall check
- judgment gap: boundary cases and comparison practice
- behavior gap: demonstration, role-play, replay, and observed practice
- confidence or emotion gap: supported practice and difficult-scenario coping
- process or system gap: repair the environment instead of adding more training

For one-to-one coaching, use one real case, one root behavior, one agreed action, and one follow-up date.

Structure the conversation around evidence, employee self-assessment, focused questions, one practiced behavior, and a dated recheck. Protect coaching time in the WFM plan; repeated cancellation signals a capacity or priority problem.

Separate developmental coaching from corrective performance management. Developmental coaching needs psychological safety, employee ownership, inquiry, and room to surface uncertainty; corrective action needs clear evidence, expectation, consequence, and support. Do not disguise one as the other.

Align QA and training on the business outcome, defect taxonomy, examples, and proof of behavior transfer. For outsourced teams, include client context, product and policy boundaries, brand expectations, escalation paths, and change synchronization.

## Ownership

- training owner: diagnosis support, design, facilitation, and learning evidence
- supervisor/team lead: floor reinforcement, observation, and recheck
- QA: defect evidence and recurrence signal
- process/knowledge/system owner: remove non-capability causes
- OM: priority, resource, and cross-role closure

## Rhythm

- before training: baseline and target behavior
- same day: understanding and practice evidence
- within three to seven days: observed behavior check
- within two to four weeks: recurrence and KPI review
- monthly: recurring capability gaps and curriculum relevance

## Metrics and Signals

- knowledge or simulation pass
- release readiness and time to proficiency
- observed target-behavior adoption
- retention of the behavior after the initial check, not only immediate post-session performance
- repeated-defect and post-coaching recurrence
- relevant QA, complaint, rework, FCR, productivity, or conversion movement
- supervisor follow-up completion and quality
- coaching agreement completion and recheck rate

## Anti-Patterns

Avoid:

- responding to every problem with a full class
- teaching policy without scenario judgment
- ending training at attendance or satisfaction
- separating training from supervisor routines
- turning coaching into a one-way lecture or score-defense meeting
- allowing QA, training, and operations to use different definitions of the same behavior
- holding employees accountable for an environment defect

## Output Contract

Provide the target behavior, audience segment, intervention, practice, owner, follow-up timing, and behavior plus business verification signals.
