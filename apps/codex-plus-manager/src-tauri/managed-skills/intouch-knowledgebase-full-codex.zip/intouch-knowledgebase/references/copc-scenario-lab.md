# COPC Scenario Lab

Use this file when the user wants to apply COPC to realistic BPO management scenarios, rehearse a solution approach, or stress-test whether a proposed diagnosis or action plan is management-complete.

Read this after `copc-core.md` and `copc-problem-solving-playbook.md`.

## How To Use This File

For each scenario:

1. define the real operating objective
2. identify the likely dominant cause layers
3. map the journey or operating path
4. test whether the scorecard is measuring the right things
5. design a governed action set with owner, cadence, and proof signal

Do not answer these scenarios with generic “加强管理”“优化流程”“持续跟进”.

## Scenario 1: SLA Green, CSAT Red

### Situation

- service level meets target for the month
- average AHT is stable
- customer satisfaction falls sharply in two product-change scenarios
- repeat contact rises
- complaint cases mention unclear explanation and multiple transfers

### COPC diagnostic focus

- whether accessibility is overemphasized relative to journey quality
- whether quality design is missing the real customer drivers
- whether handoff design and knowledge refresh are weak
- whether month-end scorecard structure hides scenario concentration

### Good answer signal

- identifies the high-friction journey stages
- separates service-level success from customer-outcome failure
- shows action across QA, knowledge, process, and transfer governance

## Scenario 2: Month-End Recovery, Daily Instability

### Situation

- service level recovers to target by month end
- first three weeks show repeated interval failures
- occupancy is high
- training and coaching keep getting cancelled
- supervisors report “人够，但就是每天都很乱”

### COPC diagnostic focus

- whether the operation relies on catch-up instead of stable control
- whether the wrong level of capacity data is being used
- whether training cancellation is hiding a capacity-design problem
- whether review cadence is too slow for the volatility pattern

### Good answer signal

- distinguishes consistency from month-end attainment
- analyzes interval control, shrinkage, and governance rhythm
- avoids explaining everything as “traffic fluctuation”

## Scenario 3: QA High, Escalations Rising

### Situation

- internal QA score remains strong
- escalations and sensitive complaints increase
- agents pass the scorecard but clients say frontline “doesn't own the issue”
- supervisors keep refreshing script wording with limited effect

### COPC diagnostic focus

- whether the quality form rewards compliance more than ownership and closure
- whether customer, business, and compliance quality are blended poorly
- whether the journey requires better resolution ownership or follow-up visibility

### Good answer signal

- challenges the quality design itself
- links QA logic to customer experience and escalation management
- proposes scorecard redesign plus operating controls

## Scenario 4: New AI Tool, Weak Business Value

### Situation

- a new bot or copilot is launched
- containment looks acceptable on paper
- human queues remain pressured
- agents complain handoff context is missing
- customers still repeat information

### COPC diagnostic focus

- whether the use case was designed from the service journey
- whether bot-human transition quality is measured
- whether AI value is being confused with tool usage volume
- whether performance verification and drift review exist

### Good answer signal

- diagnoses the journey and handoff mechanism
- defines AI-specific control metrics and governance cadence
- avoids treating the tool launch as the end of transformation

## Scenario 5: Supplier Price Attractive, Delivery Risky

### Situation

- a bidder offers lower cost
- reference materials look polished
- site visit reveals weak morale and thin support functions
- governance model is vague
- quality and WFM capabilities look dependent on a few individuals

### COPC diagnostic focus

- whether the weighted score model is aligned to the real operating objective
- whether commercial attractiveness is distorting capability judgment
- whether the site visit changes the evidence picture materially

### Good answer signal

- separates price from delivery fitness
- shows how site evidence should affect supplier scoring
- recommends a governance-based selection decision, not a sales-impression decision

## Scenario 6: Complex Business Growing, Same Old Scorecard

### Situation

- text, voice, and AI-assisted work now coexist
- new business scenarios were added over two quarters
- same KPI set and same review format are still used
- teams argue with each other using incompatible local numbers

### COPC diagnostic focus

- whether the scorecard architecture still matches the business model
- whether one management language exists across channels
- whether role, scenario, and technology differences are being handled intelligently

### Good answer signal

- redesigns the scorecard architecture without fragmenting governance
- keeps a common leadership language while allowing structural metric differences
- strengthens cross-functional review rhythm

## Scenario 7: Client Review Feels Defensive

### Situation

- monthly client review spends most time explaining misses
- presentation is KPI-heavy and action-light
- client asks repeated follow-up questions about risk control
- team feels they “说了很多，但甲方还是不放心”

### COPC diagnostic focus

- whether the report starts with operating judgment
- whether causes are explained at the right management layer
- whether actions include owner, cadence, and verification point
- whether the client can see the control system, not only the current issue

### Good answer signal

- reframes the review as a governance discussion
- shows balanced metrics, cause split, and governed corrective action
- improves client confidence without using decorative language
