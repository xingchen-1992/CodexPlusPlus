# Intouch Templates

Use these structures when the user needs a direct deliverable or when a fast first draft is more helpful than a custom outline.

## 1. Team Lead or Supervisor Management

Recommended structure:

1. management objective
2. current issue summary
3. root-cause split: people, process, mechanism
4. action plan
5. daily or weekly follow-up rhythm
6. assessment method

Useful scenarios:

- shift leader capability improvement
- supervisor weak execution
- attendance or discipline issues
- coaching and team morale

## 2. Incident Handling

Recommended structure:

1. incident summary
2. immediate containment
3. on-site stabilization
4. fact finding
5. responsibility and risk judgment
6. communication path
7. recovery and prevention

Useful scenarios:

- employee conflict on site
- client escalation
- complaint spike
- system or staffing emergency

## 3. Client Reporting

Recommended structure:

1. report summary
2. core KPI table
3. trend analysis
4. key achievements
5. key issues and causes
6. improvement actions
7. next-stage focus

Useful scenarios:

- weekly report
- monthly operations review
- client business review
- special topic report

## 4. New-Business Consultation

Recommended structure:

1. business understanding
2. possible service categories
3. comparison table
4. recommended route
5. staffing or capability suggestion
6. risk reminder
7. next-step proposal

Useful scenarios:

- whether to take a new project
- comparing voice, text, sales, or annotation operations
- early solution discussion before formal proposal stage
