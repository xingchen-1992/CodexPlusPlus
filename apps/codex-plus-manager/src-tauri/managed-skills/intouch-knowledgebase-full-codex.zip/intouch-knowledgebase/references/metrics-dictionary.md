# Metrics Dictionary

Use this file when the answer depends on KPI wording, metric explanation, target selection, or comparing management priorities across domains.

## A. BPO and Contact-Center Metrics

### Service Level

- Meaning:
  percentage of contacts answered within the target threshold
- Management meaning:
  reflects real-time service capacity and staffing fit

### AHT

- Meaning:
  average handle time
- Management meaning:
  reflects handling efficiency, but should be read together with quality and FCR

### FCR

- Meaning:
  first contact resolution
- Management meaning:
  indicates whether the issue was solved at the first interaction rather than pushed into repeat contact

### CSAT

- Meaning:
  customer satisfaction
- Management meaning:
  reflects customer-perceived service quality and expectation gap

### Shrinkage

- Meaning:
  paid time not available for live handling because of breaks, meetings, leave, training, or other non-productive intervals
- Management meaning:
  critical for staffing and schedule realism

### Adherence

- Meaning:
  the degree to which staff follow planned schedule
- Management meaning:
  an early warning signal for discipline, pressure, or morale issues

## B. AI Annotation Metrics

### Accepted Output Volume

- Meaning:
  output that passes review or acceptance criteria
- Management meaning:
  more useful than raw output volume when quality is unstable

### Accuracy or Acceptance Rate

- Meaning:
  proportion of output meeting the required quality threshold
- Management meaning:
  core quality indicator for delivery reliability

### Rework Rate

- Meaning:
  percentage of output requiring correction or relabeling
- Management meaning:
  quality-loss and capacity-loss indicator at the same time

### Calibration Pass Rate

- Meaning:
  percentage of staff or reviewers aligned with golden or standard samples
- Management meaning:
  measures consistency of rule understanding

### TAT

- Meaning:
  turnaround time from task assignment to accepted completion
- Management meaning:
  reflects delivery speed and process efficiency

## C. LLM Data and Evaluation Metrics

### Instruction-Following Quality

- Meaning:
  how well responses follow task requirements
- Management meaning:
  key quality dimension in SFT and eval work

### Preference Agreement

- Meaning:
  consistency of human preference judgments across reviewers
- Management meaning:
  weak agreement often signals rubric ambiguity

### Safety Coverage

- Meaning:
  breadth of risky or policy-sensitive scenarios covered in the data or evaluation set
- Management meaning:
  a low number here means hidden release risk even if general quality looks good

### Regression Defect Rate

- Meaning:
  proportion of important scenarios that got worse versus the prior model or release
- Management meaning:
  key release-readiness metric

### Blocking Issue Count

- Meaning:
  number of defects severe enough to stop release or require mitigation
- Management meaning:
  turns evaluation output into a decision-making tool

## D. Embodied Robotics Training Metrics

### Scenario Coverage Rate

- Meaning:
  proportion of target task and environment variations covered by data collection
- Management meaning:
  more important than raw data count for robustness

### Trajectory Usability Rate

- Meaning:
  proportion of collected trajectories that are actually usable for training
- Management meaning:
  reveals whether collection quality is stable

### Failure-Case Replay Coverage

- Meaning:
  degree to which high-value failures are captured and reintroduced into training or analysis
- Management meaning:
  important for robustness improvement

### Operator Consistency

- Meaning:
  degree to which teleoperators or demonstrators produce aligned behavior under the same task standard
- Management meaning:
  a hidden driver of data quality and policy stability

### Sim-to-Real Readiness

- Meaning:
  how prepared the dataset and workflow are for transfer into real environments
- Management meaning:
  connects collection quality to actual deployment usefulness

## Metric Selection Rule

When choosing metrics:

1. start from the operating objective
2. choose only metrics that explain the objective
3. avoid stacking too many indicators without management meaning
4. pair result metrics with cause or process metrics
