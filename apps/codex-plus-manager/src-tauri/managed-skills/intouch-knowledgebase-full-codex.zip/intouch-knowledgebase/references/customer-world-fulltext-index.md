# Customer World Full-Text Index

Use this file as the first routing layer for the local high-value full-text library.

This is not the broad title index.
It is the curated body-text layer for the articles most worth learning deeply.

## Current coverage

The local full-text layer currently covers these method-heavy streams in full:

- `cjyj`: 966
- `ftdh`: 151
- `ksyc`: 179
- `szyc`: 35
- `zjgd`: 61
- total: 1392

## Current Priority Themes

### 1. Complaints and escalation

- `18555` 浅谈数智时代下客户投诉的主动管理
- `18577` 融合数字化与 AI 的投诉问题一线不愿升级解决方案

Use when the user asks about:

- 投诉治理
- 升级压降
- 主动投诉管理
- 一线不愿升级

### 2. Management rhythm and analysis meetings

- `18562` 如何务实、高效地开好经营分析会？

Use when the user asks about:

- 经营分析会
- 运营复盘会
- 数据复盘
- 管理闭环

### 3. Attrition, people stability, and team management

- `18645` 对外包呼叫中心座席代表频繁流失的反思
- `18638` 聚拢人心 带好队伍
- `18643` 重视座席代表的职业生涯规划
- `18650` 《新劳动合同法》挑战呼叫中心的人力资源管理
- `18654` REBT疗法在客服中心基层管理中的应用
- `18706` 周力之:呼叫中心管理中的员工成长“目标关怀”

Use when the user asks about:

- 流失
- 队伍稳定
- 班组带教
- 员工成长
- 一线情绪管理

### 4. Quality, AHT, and interaction quality

- `18630` 热点话题：平均通话时长到底应该多少呢？
- `18597` 呼叫中心进行质量监控应覆盖哪些方面？
- `18602` 如何确保呼叫中心团队高质量客户互动？

Use when the user asks about:

- AHT
- 质量监控
- 高质量互动
- 质检作用升级

### 5. WFM, complexity, and operating design

- `18628` 专家答疑：如何缓解呼叫中心复杂性
- `18599` 呼叫中心部署人力管理能带来什么回报?
- `18603` 呼叫中心如何平衡电话业务和非电话业务？
- `18604` 电子商务企业的呼叫中心该选择外包还是自建？
- `18627` 专家答疑：如何设置客户关系管理组织架构

Use when the user asks about:

- 复杂性
- 人力管理
- 多渠道平衡
- 自建外包判断
- CRM组织架构

### 6. AI collaboration, standards, and future BPO form

- `19605` 趋势篇
- `19606` 变革篇
- `19607` 指标篇
- `19608` 实操篇
- `20059` 联络中心服务国际标准实施机制研究
- `18556` BPO 3.0：未来社会的能力网络与人机共生新范式
- `20254` 从KPI到OKR：服务型组织如何构建赋能机制
- `20255` AI协同下的服务边界

Use when the user asks about:

- AI客服协同
- 人机协同
- 标准体系
- 指标体系升级
- BPO未来模式

### 7. Experience and customer-success framing

- `20054` 客户体验管理的“四维要素模型”及其系统解读
- `20253` 服务的判断力：员工体验与客户体验如何联动
- `20257` 区分客户忠诚度管理与客户成功管理的不同定位、目标和运营

Use when the user asks about:

- 客户体验
- 员工体验联动
- 忠诚度
- 客户成功

## Working Rule

When a BPO answer needs stronger first-hand Customer World grounding:

1. route by theme here
2. read the corresponding full-text article file in `customer-world-fulltext/`
3. then combine it with the existing methods file and scenario file

Do not use the full-text layer alone.
It should deepen the skill's judgment, not replace the rest of the reference stack.
