# External Operations Learning Full-Text Layer

This folder stores non-Customer-World full-text articles selected for BPO operations management and AI data-production management learning.

Selection rules:

- focus on operations management, quality management, staffing, delivery control, evaluation, and practical governance
- exclude industry news, conference notices, member updates, and pure technical theory
- avoid URL/title duplicates against existing local references

- generated_at: 2026-07-09T23:58:56+08:00
- article_count: 308

Current sources:

- 51callcenter: 112
- nda: 73
- appen: 31
- callcentrehelper: 22
- icmi: 21
- superannotate: 21
- surge: 13
- scale: 11
- aliyun: 3
- labelbox: 1
