# Model-Evaluation Operations Method

Use for benchmark operations, human review, scenario evaluation, rubric design, calibration, arbitration, regression, release gates, and evaluation reporting.

## Management Judgment

Treat evaluation as release decision support, not score production. Separate benchmark capability, business-scenario reliability, safety, reviewer consistency, and regression risk. An aggregate score cannot by itself justify release.

## Cause Structure

When results are unstable, inspect:

- evaluation objective: the decision and risk tolerance are unclear
- dataset: coverage, difficulty, freshness, leakage, or representativeness is weak
- rubric: criteria, severity, evidence, or pass boundary is ambiguous
- reviewer: calibration, expertise, fatigue, bias, or arbitration is inconsistent
- model or system: prompt, tool, retrieval, workflow, or policy behavior changed
- aggregation: averages hide critical scenario or severity failures
- release governance: no blocking rule, owner, or regression closure

## Evaluation Stack

Use the layers needed for the decision:

1. benchmark for comparable capability signals
2. scenario evaluation for intended workflow reliability
3. human review for nuanced quality and preference judgment
4. safety and policy review for material harm
5. regression comparison for change impact
6. release gate for blocking and conditional decisions

## Human-Review Control

- define rubric, positive/negative examples, severity, and evidence requirements
- calibrate on normal, boundary, and difficult samples
- use blind or independent review where bias matters
- route disagreement to a named arbitration process
- record adjudication and update the rubric or example library

## Release Mechanism

- list improvements and regressions by scenario and severity
- identify blocking, conditional, and accepted risks
- assign mitigation and re-evaluation owners
- require blocking-item closure or explicit risk acceptance before release
- monitor post-release signals for critical scenarios

## Ownership

- evaluation owner: design, dataset, rubric, execution, and report integrity
- business SME: scenario validity and business severity
- safety/compliance owner: high-risk boundaries
- product/model/system owner: remediation
- release owner: final decision and risk acceptance

## Rhythm

- before run: objective, dataset, rubric, and gate confirmation
- during run: reviewer quality and operational exception control
- after run: arbitration, regression, and decision review
- before release: blocking-item closure
- after release: targeted monitoring and regression feedback

## Metrics and Signals

- scenario and severity-weighted pass rate
- critical failure and blocking issue count
- reviewer agreement, dispute, and overturn rate
- regression count and weighted impact
- dataset coverage and stale-item rate
- mitigation closure and re-evaluation pass
- post-release failure in protected scenarios

## Anti-Patterns

Avoid:

- treating benchmark score as scenario reliability
- reporting averages without critical-failure visibility
- using human review without calibration and arbitration
- changing the dataset or rubric without version control
- releasing with unresolved blocking issues and no explicit risk owner

## Output Contract

State the decision question, evidence layers, reliability limits, material failures, release judgment, owners, and re-evaluation or monitoring plan.
