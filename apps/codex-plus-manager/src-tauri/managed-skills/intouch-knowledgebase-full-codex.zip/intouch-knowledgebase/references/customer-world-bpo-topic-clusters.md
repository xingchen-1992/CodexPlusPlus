# Customer World BPO Topic Clusters

Use this file when the goal is not only to retrieve Customer World by abstract topic, but to route it by the BPO management problems users actually ask about in daily work.

This file is the business-facing clustering layer between:

1. full-text and article learning
2. method extraction
3. solution drafting
4. direct BPO work use

For the stable first-response path of each cluster, also read:

- `customer-world-bpo-standard-response-map.md`

## Core Principle

Do not organize learning only by article category or knowledge-engineering vocabulary.

Organize it by the work a BPO operator, OM, supervisor, project owner, or solution lead actually needs to do.

That means the first clustering question is:

- what kind of management problem is this

not:

- what kind of article is this

## Main BPO Topic Clusters

The current method-heavy full-text library should first be routed into these topic clusters:

1. operations and floor management
2. KPI and business-review management
3. quality assurance and coaching
4. staffing, scheduling, and workforce balance
5. complaints and escalation governance
6. performance, motivation, and team stability
7. knowledge governance and process optimization
8. client reporting and management communication
9. proposal, RFP, and service-solution output
10. AI-enabled service and future operating models

## Cluster Map

| BPO Topic Cluster | What it is really about | Main method files | Strongest full-text lanes | Best output assets | Typical user ask |
| --- | --- | --- | --- | --- | --- |
| operations and floor management | daily operating rhythm, team-lead control, issue closure, execution stability | `methods-teamlead.md`, `methods-metrics.md`, `methods-training.md` | `ksyc`, `cjyj`, `ftdh` | `operations.md`, `sample-library-teamlead-cn.md`, `customer-world-management-checklist-pack-cn.md`, `customer-world-management-talktrack-pack-cn.md` | 现场很乱，班长带不住怎么办 |
| KPI and business-review management | KPI split, variance analysis, operating rhythm, review meetings, management closure | `methods-metrics.md`, `methods-teamlead.md`, `methods-performance.md` | `ksyc`, `cjyj`, `zjgd` | `reporting.md`, `customer-world-kpi-commentary-pack-cn.md`, `sample-library-reporting-cn.md`, `customer-world-weekly-monthly-conclusion-pack-cn.md` | 经营分析会怎么开，指标怎么拆 |
| quality assurance and coaching | QA stability, defect classification, calibration, coaching landing, repeated-error control | `methods-quality.md`, `methods-training.md`, `methods-knowledge.md` | `zjgd`, `ksyc`, `cjyj` | `customer-world-root-cause-judgment-pack-cn.md`, `customer-world-team-issue-pack-cn.md`, `sample-library-ops-review-cn.md`, `customer-world-one-on-one-coaching-pack-cn.md` | 质检分连续掉，辅导也没效果 |
| staffing, scheduling, and workforce balance | staffing structure, shift design, shrinkage, peak coverage, service level, people tolerance | `methods-metrics.md`, `methods-teamlead.md`, `methods-emotion.md` | `ksyc`, `cjyj`, `ftdh` | `operations.md`, `examples-operations.md`, `customer-world-table-template-pack-cn.md`, `customer-world-special-plan-pack-cn.md` | 排班总顶不住 SLA，怎么调 |
| complaints and escalation governance | complaint classification, expectation management, escalation suppression, closure quality, trust recovery | `methods-complaints.md`, `methods-experience.md`, `methods-knowledge.md` | `ksyc`, `zjgd`, `cjyj` | `event.md`, `customer-world-solution-playbook-cn.md`, `sample-library-client-cn.md`, `customer-world-objection-handling-pack-cn.md` | 升级率很高，投诉老压不住 |
| performance, motivation, and team stability | attrition, attendance, morale, incentive fairness, supervisor care, first-90-day survival | `methods-retention.md`, `methods-performance.md`, `methods-emotion.md`, `methods-teamlead.md` | `ksyc`, `cjyj`, `ftdh` | `sample-library-improvement-cn.md`, `customer-world-special-plan-pack-cn.md`, `customer-world-one-on-one-coaching-pack-cn.md`, `customer-world-team-issue-pack-cn.md` | 流失高，士气差，激励也没带动 |
| knowledge governance and process optimization | knowledge usability, SOP governance, consultation frontloading, process closure, rule refresh | `methods-knowledge.md`, `methods-quality.md`, `methods-training.md` | `zjgd`, `ksyc`, `cjyj` | `sample-library-ops-review-cn.md`, `customer-world-management-checklist-pack-cn.md`, `customer-world-solution-playbook-cn.md`, `customer-world-table-template-pack-cn.md` | 知识库很多，但一线还是不会用 |
| client reporting and management communication | weekly reports, monthly reviews, client summaries, leadership reviews, meeting wording | `methods-metrics.md`, `methods-experience.md`, `methods-teamlead.md` | `ksyc`, `szyc`, `ftdh` | `reporting.md`, `sample-library-reporting-cn.md`, `customer-world-executive-report-pack-cn.md`, `customer-world-client-review-pack-cn.md` | 帮我整理成甲方汇报/经营回顾版本 |
| proposal, RFP, and service-solution output | client pain-point translation, service model, SLA, staffing logic, risk response, defense wording | `methods-service-innovation.md`, `methods-tech-enablement.md`, `methods-outsourcing-platform.md`, `methods-multichannel.md` | `szyc`, `ftdh`, `cjyj` | `tender.md`, `sample-library-client-cn.md`, `customer-world-report-skeleton-pack-cn.md`, `customer-world-problem-to-deliverable-pack-cn.md` | 这个投标怎么答，方案怎么写得专业 |
| AI-enabled service and future operating models | AI collaboration, service redesign, data production, evaluation, operating-model upgrade | `methods-service-innovation.md`, `methods-selfservice.md`, `methods-llm-ops.md`, `methods-model-eval.md`, `methods-ai-annotation.md` | `szyc`, `ksyc`, selected `cjyj` | `customer-world-ai-training-special-pack-cn.md`, `sample-library-ai-training-cn.md`, `sample-library-ai-annotation-cn.md`, `customer-world-transformation-argument-pack-cn.md` | AI客服/数据标注/大模型运营这块怎么讲清楚 |

## How To Route By Business Need

### If the user is trying to keep the site stable every day

Go first to:

- operations and floor management
- staffing, scheduling, and workforce balance
- quality assurance and coaching

This is the core operational-control lane.

### If the user is trying to explain performance or defend a result

Go first to:

- KPI and business-review management
- client reporting and management communication

This is the business-narration lane.

### If the user is trying to solve repeated people problems

Go first to:

- performance, motivation, and team stability
- operations and floor management
- quality assurance and coaching

This is the people-and-execution lane.

### If the user is trying to reduce customer risk

Go first to:

- complaints and escalation governance
- knowledge governance and process optimization
- quality assurance and coaching

This is the service-risk lane.

### If the user is trying to write something external-facing

Go first to:

- client reporting and management communication
- proposal, RFP, and service-solution output

This is the external-expression lane.

### If the user is trying to discuss transformation, AI, or future BPO form

Go first to:

- AI-enabled service and future operating models
- proposal, RFP, and service-solution output
- KPI and business-review management

This is the transformation lane.

## Full-Text Use Rule

When the answer needs stronger first-hand grounding, pull full text by cluster instead of by random article title.

Recommended full-text priority by cluster:

- operations / KPI / complaints / performance:
  `ksyc` first, then `zjgd`, then `cjyj`
- frontline scenario, interviews, benchmark practice:
  `cjyj` first, then `ftdh`
- proposal tone, strategy tone, AI-era service framing:
  `szyc` first, then `ksyc`, then `ftdh`

## What This Solves

Without this clustering layer, the skill may still behave like:

- a large article shelf
- a topic lookup table
- a sample-writing library

With this clustering layer, the skill is more likely to behave like:

- a BPO operations advisor
- a management-solution engine
- a report/proposal drafting assistant with domain judgment

## Working Rule

When the user asks a short Chinese BPO question, silently map it into one of these clusters before selecting any detailed reference.

That is how the skill moves from:

- article retrieval

to:

- usable professional judgment
