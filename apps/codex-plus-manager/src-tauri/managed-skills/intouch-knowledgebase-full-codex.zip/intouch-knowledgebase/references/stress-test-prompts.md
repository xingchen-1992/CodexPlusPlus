# Stress-Test Prompt Set

Use this file to validate whether the skill can answer realistic, high-value management questions with strong structure, correct business framing, and direct reusability.

## A. BPO and Contact Center

1. 我们班组近两个月流失率明显偏高，帮我出一版改善方案，要求能直接汇报给主管。
2. 这个月服务水平下降了，但 AHT 也没明显变长，帮我分析原因并给出管理动作。
3. 给我出一版甲方周报口径，重点解释满意度波动和下一步动作。
4. 班组长只会盯指标，不会带人，怎么做辅导机制？
5. 投诉集中在物流解释场景，帮我做一版专项复盘。
6. 排班表看起来够人，但每天实际高峰都缺口，帮我判断是预测、排班、出勤还是现场调度问题。
7. 质检评分卡越来越复杂，但坐席不知道到底该改什么，怎么重构质量管理和辅导闭环？
8. 质检员之间评分差异很大，帮我设计一套校准、仲裁和争议样本沉淀机制。
9. 知识库内容很多，但一线还是靠问老员工解决问题，怎么判断知识库是不是失效？
10. 主管每天都在救火，辅导、复盘、带班都做不深，怎么判断是不是“主管漂移”？

## B. AI Annotation

11. 我们 AI 标注项目返工率偏高，帮我做一版原因分析和改善方案。
12. 规则更新后各组理解不一致，如何快速把准确率拉稳？
13. 给我出一版 AI 标注项目月度复盘口径，重点看质量一致性和 TAT。
14. 审核团队和标注团队争议很多，怎么建校准和仲裁机制？
15. 高复杂度任务产量低，是人不行还是任务设计有问题，怎么判断？

## C. LLM Data Production

16. 我们 SFT 数据质量不稳定，帮我做一版运营改善方案。
17. 偏好对标注一致性差，怎么从规则和管理上解决？
18. 安全类数据覆盖不足，怎么补一版专项提升方案？
19. 给我出一版大模型数据生产周报，重点解释质量波动和数据回流动作。
20. 如果模型反复在同一类问题上失败，数据团队应该怎么闭环？

## D. Model Evaluation

21. 帮我出一版模型评测月报口径，重点写回归问题和是否阻断发布。
22. 人审给分分歧很大，怎么建更稳的评测运营机制？
23. benchmark 分数不错，但业务场景表现不稳，汇报时怎么讲？
24. 给我做一版评测团队 SOP，要求包括校准、仲裁、回归检查。
25. 模型上线前，哪些问题必须算阻断项？

## E. Embodied Robotics

26. 具身机器人训练数据采集量不少，但真实场景表现一般，运营上该怎么查？
27. 遥操作团队采集轨迹风格不一致，怎么管？
28. 帮我做一版具身训练项目周报，重点写场景覆盖和轨迹质量。
29. 失败样本很多，但没有形成复用价值，怎么建立回放和补采机制？
30. 如果老板只盯采集量，怎么说服他关注场景覆盖和轨迹可用率？

## Pass Criteria

A strong answer should:

- identify the right business mode
- choose relevant KPI rather than generic KPI
- give diagnosis before action
- separate short-term fix from structural fix
- include owner, timing, and review logic when appropriate
- sound reusable in Chinese management documents
