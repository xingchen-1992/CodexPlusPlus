# BPO Capability Validation Matrix CN

Use this matrix to verify whether the skill has converted its learned articles into professional BPO judgment and executable solution capability.

This file is not an article index. It is a capability gate.

## Validation Principle

The skill should pass only when it can do all four things:

1. identify the real management problem behind a short user sentence
2. choose the right knowledge route before drafting
3. give a non-generic diagnosis with operating logic
4. produce actions, owners, rhythms, KPIs, or client-ready wording that can be used directly

## Routing Evidence Gate

For practical BPO questions, do not rely on `SKILL.md` alone. Use `core-routing-table.md` as the live routing source of truth.

The default route should stay small:

1. one matching `methods-*.md` file
2. one scenario or deliverable file when the requested output requires it
3. one sample library only when direct reusable wording is needed

Use `external-ops-fulltext-index.md`, `customer-world-topic-solution-index.md`, or raw full text only when the prompt requires benchmark grounding, stronger source evidence, uncommon detail, or method-layer gap filling.

During future evaluation, record the files actually read. Do not award source-use points merely because the expected route names those files.

## Capability Test Matrix

| Capability Lane | Test Prompt | Must-Hit Judgment | Must-Hit Actions | Fail Signal |
| --- | --- | --- | --- | --- |
| floor management | 现场很忙但问题反复发生，班组长也说每天都在处理，怎么管 | judge whether the issue is routine failure, unclear ownership, or weak closure | pre-shift focus, intraday monitoring, post-shift review, owner list, recurring-issue closure | only says strengthen management |
| WFM and service level | 人不少但晚高峰服务水平扛不住，怎么判断是排班还是现场问题 | separate total headcount shortage from interval mismatch and skill mismatch | traffic curve check, break distribution, shrinkage, cross-skill support, one-week trial | only recommends adding people |
| schedule variance | 排班表看起来够人，但每天实际都缺口，怎么查 | distinguish forecast, adherence, absenteeism, shrinkage, and real-time dispatch | forecast-vs-actual, adherence review, absence roster, RTM response rules | treats it as HR attendance only |
| QA calibration | 质检分下滑，质检员之间评分也不一致，怎么拉稳 | judge calibration failure before blaming agents | scorecard review, sample calibration, dispute library, weekly calibration, defect taxonomy | only says retrain agents |
| coaching | 培训做了但错误还是反复，主管辅导怎么改 | distinguish training input from behavior conversion | one-on-one coaching, behavior target, call sample replay, follow-up check, repeated defect closure | gives only training plan |
| KPI review | 经营会总是报数，没有改进，怎么重构 | judge lack of variance interpretation and action closure | KPI tree, variance causes, owner/action/deadline, next meeting closure | gives meeting agenda only |
| productivity | AHT没变但服务水平下降，怎么看 | separate arrival pattern, occupancy, staffing interval, after-call work, backlog | interval analysis, real-time queue view, shrinkage, auxiliary status audit | assumes AHT explains everything |
| attrition | 流失高士气差，先抓离职还是情绪 | judge risk segment and sequence | 30/60/90-day roster, supervisor touchpoint, schedule fairness, retention interview, quick wins | gives scattered employee-care slogans |
| knowledge governance | 知识库一直更新但一线还老问人，说明什么 | judge usability, searchability, version drift, and scenario entry failure | top-question map, scenario index, expired-rule cleanup, use-effect review | praises content volume |
| client report | 写一段甲方周报，解释满意度波动和下周动作 | use client-facing, controlled, accountable wording | conclusion, cause, current action, next-stage action, risk watchpoint | sounds like internal complaint |
| RFP solution | 客服项目投标，怎么写得像专业BPO服务商 | shift to service model, SLA, governance, risk response | operating model, staffing, QA, WFM, reporting, escalation, SLA | writes generic company capability |
| AI annotation QA | 标注返工率高，怎么做运营闭环 | separate rules, task design, annotator capability, sampling, reviewer consistency | calibration, gold samples, dispute rules, rework reason dashboard, batch gate | says improve accuracy only |
| LLM data production | SFT数据质量不稳，怎么管理 | judge instruction ambiguity, reviewer drift, task difficulty, acceptance gate | rubric, sample review, SME arbitration, batch acceptance, feedback to prompt/data design | explains SFT technically only |
| model evaluation | benchmark分数好但业务场景不稳，怎么汇报 | distinguish benchmark score from scenario reliability | scenario eval set, regression watch, human review, release gate, risk wording | says benchmark is unreliable only |
| embodied operations | 采集量不少但真实场景效果一般，运营上怎么查 | separate volume from coverage, trajectory quality, operator consistency, scenario diversity | scene coverage matrix, trajectory acceptance, replay library, targeted recollection | only asks for more data |

## Scoring Rule

Each answer is scored on six dimensions, 0 to 2 points each:

| Dimension | 0 | 1 | 2 |
| --- | --- | --- | --- |
| route | wrong topic | roughly right | precise lane and business mode |
| diagnosis | generic | partial cause split | management-grade cause structure |
| action | scattered advice | action list | owner, rhythm, and closed-loop plan |
| metrics | absent or generic | partly relevant | relevant KPI/watchpoint set |
| wording | chat-like | usable with edits | document-ready BPO wording |
| source use | no evidence of learned methods | uses one method layer | combines methods and benchmark/full-text layer |

Pass threshold:

- 10 to 12: pass
- 7 to 9: risk
- 0 to 6: fail

## Current Evidence Baseline

As of the current library state:

- Customer World full-text articles: 1392
- external operations and AI training full-text articles: 308
- total clean learnable articles: 1700
- external short articles under 1000 characters: 0
- external C-class title hits after filtering: 0

This proves corpus readiness, not final assistant readiness.
Final readiness still requires passing the capability matrix with real answer samples.
