# Operations Playbook

Use this reference for internal operational management, people management, KPI review, scheduling, staffing, coaching, QA, and execution follow-up.

This file should be used when the user wants a management answer that can be turned into a work plan, review note, leadership memo, or PPT page.

## Default Output Structure

1. management objective
2. current-state diagnosis
3. KPI view
4. root-cause split
5. action plan
6. owner and timeline
7. review rhythm

## Mandatory Thinking Sequence

Before drafting, think in this order:

1. What is the real management goal: stabilize, improve, recover, scale, or prevent?
2. What is the main drag: people, process, mechanism, upstream dependency, or business fluctuation?
3. Which KPI proves the issue is real?
4. Which action fixes the source instead of only the symptom?
5. Who owns the action and when will it be reviewed?

## Common Cause Buckets

Use these buckets when diagnosing any issue:

- people: skill gap, attitude issue, attendance instability, weak frontline management
- process: poor SOP, weak handoff, unclear escalation path, redundant steps
- mechanism: target setting, incentive design, staffing rule, QA rule, schedule rule
- business fluctuation: peak traffic, promotion, campaign node, lead quality change
- upstream dependency: policy, system, product, logistics, client-side delay

Do not stop at "performance declined." Push the diagnosis into one or more cause buckets.

## Standard Management Output Pattern

### Opening judgment

Start with one sentence that gives the conclusion:

- the current issue is mainly a staffing-and-coaching problem rather than a pure effort problem
- service pressure is controllable, but current recovery depends too much on ad hoc floor intervention
- the team can still hit the monthly target if schedule correction and scenario coaching are completed this week

### KPI view

Use only the KPIs that support the decision. Do not stack every available metric.

Preferred pattern:

| KPI | Current state | Signal | Management meaning |
| --- | --- | --- | --- |

## Business-Line KPI Focus

### Inbound Voice

Primary KPI:

- service level
- AHT
- FCR
- CSAT
- complaint rate
- attendance and shrinkage

Management focus:

- queue recovery during peak periods
- long-call and repeat-call control
- transfer and escalation reason analysis
- schedule fit against real traffic curve
- QA plus coaching on complaint-prone scenarios

### Outbound Telesales

Primary KPI:

- connect rate
- conversation rate
- conversion rate
- output per seat
- attendance
- QA pass rate

Management focus:

- lead quality versus execution quality split
- script consistency and objection handling
- callback completion discipline
- incentive linkage to quality conversion

### Text Customer Service and Ecommerce

Primary KPI:

- first response timeliness
- average response time
- one-time resolution
- satisfaction
- backlog and backlog aging
- concurrency efficiency

Management focus:

- queue balance by hour and skill group
- macro or SOP usefulness
- peak staffing and escalation response
- refund, complaint, or negative-review risk

### AI Data Annotation

Primary KPI:

- output volume
- accuracy
- rework rate
- turnaround time
- calibration pass rate
- attendance stability

Management focus:

- rule understanding and edge-case governance
- calibration rhythm
- review and recheck process
- productivity versus quality balance

## Action Design Rule

Every action should answer four questions:

1. what exactly will be done
2. who owns it
3. when it will be completed or reviewed
4. what KPI or signal will show it worked

Preferred action table:

| Topic | Action | Owner | Timing | Success signal |
| --- | --- | --- | --- | --- |

## Scenario Modules

### Low-performance team diagnosis

Recommended response flow:

1. define the target gap
2. segment the gap by team, shift, scenario, or leader
3. identify whether the main issue is effort, skill, schedule, or process
4. give a 2-week corrective plan
5. set a daily and weekly review rhythm

### Supervisor improvement plan

Must include:

- what the supervisor is currently not doing well
- what management routine is missing
- what support will be given
- how progress will be checked

### Staffing or shift optimization proposal

Must include:

- current mismatch
- expected traffic or workload pattern
- revised staffing logic
- risk of not adjusting
- trial period and review node

### QA and coaching mechanism

Must include:

- sampling object
- scoring or observation focus
- coaching trigger
- coaching cadence
- post-coaching verification

## Empty Output Fixes

If the draft sounds generic, tighten it using one of these upgrades:

- replace "improve efficiency" with the exact scenario to optimize
- replace "strengthen coaching" with a coaching object, script, and review node
- replace "optimize staffing" with a time band, seat gap, and adjustment rule

## Good Output Characteristics

The answer should read like:

- a manager diagnosing a business problem
- not a consultant giving broad theory
- not a frontline SOP pasted upward

It should be specific enough that another manager can assign work from it immediately.
