# COPC RFP, SLA, and Governance Translation

Use this file when the user needs COPC-informed help for RFP responses, service proposals, SLA design, outsourcing selection, vendor governance, site assessments, or client-facing service architecture.

Read this after `copc-core.md`. Add `tender.md` when the user needs direct proposal structure or client-facing wording.

## Table of Contents

- Why COPC matters in proposals
- RFP design
- Supplier evaluation
- Site assessment
- SLA design
- Governance model
- Proposal-writing translation
- Common anti-patterns

## Why COPC Matters in Proposals

COPC gives proposals and service designs a management backbone.

Its value is not that the deck can mention “COPC.” Its value is that the proposal can show:

- clear operating objectives
- measurable control mechanisms
- defined roles and decision rights
- cross-functional governance cadence
- performance verification and corrective action
- alignment across internal and outsourced operations

This is especially useful when the client is worried about delivery stability, scaling, vendor coordination, AI adoption, or whether the service model will survive beyond go-live.

## RFP Design

Translate COPC into RFP logic like this:

### 1. Start with the operating objective

Before drafting the supplier profile, clarify whether the client is primarily pursuing:

- cost efficiency
- quality improvement
- customer-experience improvement
- technology modernization
- multilingual or multichannel expansion
- operating-risk reduction

If the objective is vague, the supplier response will also be vague.

### 2. Define both contractual and non-contractual requirements

Do not stop at legal or commercial clauses.

Contractual requirements usually include:

- scope
- pricing rules
- service commitments
- roles and responsibilities
- contractual performance obligations

Non-contractual requirements often determine delivery quality more strongly:

- historical volume, handle time, occupancy, and shrinkage context
- quality forms and calibration mechanism
- workforce-management process and assumptions
- communication architecture
- support-process design
- knowledge and change-management expectations
- reporting and escalation routines

Management meaning:

- suppliers price contractual requirements
- suppliers operationalize both contractual and non-contractual requirements

### 3. Make the RFP a selection mechanism, not a document dump

A useful RFP should help strong suppliers self-identify and weak suppliers self-filter.

Include:

- response instructions and selection process
- MSA template
- SOW template
- business and technology requirements
- capability questions
- process requirements
- glossary or definitions where ambiguity would damage comparability

## Supplier Evaluation

Use a weighted evaluation model rather than informal discussion.

### Evaluation rule

Evaluate suppliers on both fit and evidence.

Useful dimensions include:

- leadership and planning capability
- internal process maturity
- historical performance on similar programs
- people model
- technology and data capability
- governance approach
- location and scalability fit
- commercial model

### Practical scoring rules

- separate pricing review from capability review as long as possible
- assign higher weights to the most business-critical dimensions
- define non-negotiables that create automatic exclusion
- require data-backed evidence, not presentation confidence

Use references to test whether supplier claims survive outside the sales process.

## Site Assessment

Treat site visits as an evidence stage, not a courtesy stage.

### Before the visit

- define the schedule tightly
- prioritize value-added activities
- ensure meetings with frontline and support roles, not only leadership

### During the visit

- challenge opinion-based claims
- ask for data behind performance statements
- inspect culture, morale, floor discipline, and support-process reality
- test whether what was presented in the RFP exists in daily practice

### After the visit

- compare what the visit confirmed, contradicted, or newly revealed
- use the visit to refine the weighted score, not to replace it with intuition

## SLA Design

COPC-style SLA design should protect customer experience, consistency, and cost discipline together.

### 1. Avoid one static service-level target

For accessibility measures such as service level, use a performance band instead of one fixed number where the operation permits it.

Management meaning:

- under-service hurts customer experience
- over-service also damages the business through avoidable cost and low occupancy

### 2. Measure consistency, not only month-end recovery

Prefer daily, interval, or prime-interval control rather than relying on one month-end number that can hide poor consistency.

### 3. Pair outcome measures with operating controls

For each major SLA, define:

- the result measure
- the supporting control signals
- the escalation rule
- the action expected when performance misses target

Examples:

- service level with forecast accuracy, staffing gap, adherence, and recovery time
- quality with calibration, dispute handling, and recurrence checks
- customer satisfaction with key-driver evidence and journey-stage analysis
- AI or self-service performance with containment quality, handoff success, and drift review

### 4. Align internal and outsourced expectations

One common failure mode is holding outsourced teams to stricter expectations than internal teams, or vice versa.

Use one management language across both.

## Governance Model

COPC helps convert a proposal from “team plus KPI” into a governed operating model.

### Governance layers

- executive review: strategy, risk, investment, structural issues
- operational review: KPI movement, root cause, action closure
- functional governance: WFM, QA, training, knowledge, technology, vendor management
- real-time or short-cycle control: intraday service risk, incident handling, workflow exceptions

### Governance rules

- prepare diagnosis before the review, not during it
- define owner and expected action for missed performance
- keep one scorecard architecture across internal and outsourced sites
- align vendor governance with internal governance instead of creating two management systems
- require corrective-action verification, not only action logs

### AI and technology governance

When the service design includes AI, bots, self-service, or new platforms, governance should also cover:

- ethics and policy boundaries
- performance verification
- bot-to-human handoff quality
- journey-stage friction
- change control after launch

## Proposal-Writing Translation

When writing a proposal, make the COPC logic visible in these sections:

- project understanding: define the business objective and customer-experience objective together
- service process: show the end-to-end journey, not only staffing and SOP
- staffing model: tie capacity assumptions to service objectives and workload patterns
- SLA and KPI: explain why the measures were selected and how misses will be controlled
- QA: show link to customer drivers and business risk
- governance: define cadence, participants, decision rights, escalation, and closure
- continuity and risk: show how the operation remains stable through change, incidents, and technology evolution
- outsourcing or partner management: show selection logic, onboarding controls, and performance-management discipline

Good proposal signal:

- the client can see how the service will be run after the presentation ends

Weak proposal signal:

- the deck names standards and tools but does not show owners, rhythms, thresholds, and proof signals

## Common Anti-Patterns

Avoid:

- writing an RFP that shares only contractual requirements
- scoring suppliers mainly by price before capability fit is understood
- accepting management claims without data or floor-level validation
- designing SLAs as isolated headline numbers without control logic
- treating governance as a meeting calendar rather than a decision system
- describing outsourced and internal operations with different expectations and no common scorecard architecture
