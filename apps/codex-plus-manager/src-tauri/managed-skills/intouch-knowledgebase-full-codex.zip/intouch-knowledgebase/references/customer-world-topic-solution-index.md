# Customer World Topic-Solution Index

Use this file when Customer World learning needs to be retrieved by topic rather than by raw article list.

This is the routing layer between:

1. article/topic absorption
2. method extraction
3. solution drafting
4. reporting or client-facing output

## How To Use

When the user raises a topic, route in this order:

1. identify the BPO work cluster in `customer-world-bpo-topic-clusters.md`
2. identify the topic family
3. use the cluster to decide which method / solution / wording lane should dominate
4. only then read the mapped detailed references

This keeps the skill aligned to business work rather than abstract article grouping.

## Business-First Routing Layer

Before using the topic map below, first read:

- `customer-world-bpo-topic-clusters.md`
- `customer-world-bpo-standard-response-map.md`

Use it when the user's ask sounds like:

- a daily operations problem
- a KPI / review problem
- a QA / coaching problem
- a scheduling / staffing problem
- a complaint / escalation problem
- a people / motivation / attrition problem
- a knowledge / SOP / process problem
- a client-reporting ask
- a proposal / RFP / service-solution ask
- an AI-enabled service or data-ops ask

Then continue with the topic map below.

## Detailed Topic Routing

When the cluster is clear, route in this order:

1. identify the detailed topic family
2. read the mapped `methods-*.md`
3. read the mapped solution file
4. read the mapped sample library if wording polish is needed
5. add source flavor from original-stream or conference-stream notes when useful

## Topic Map

| Topic Family | Main Method Files | Main Solution Assets | Best Sample Files | Source Flavor Lane | Typical User Ask |
| --- | --- | --- | --- | --- | --- |
| attrition and team stability | `methods-retention.md`, `methods-emotion.md`, `methods-teamlead.md`, `methods-performance.md` | `customer-world-solution-playbook-cn.md` Solution 1, `customer-world-solution-variants-cn.md` Scenario 1 | `sample-library-improvement-cn.md`, `sample-library-teamlead-cn.md` | `ksyc` people-management realism | 我们班组流失率很大，怎么办 |
| quality decline and complaint rise | `methods-quality.md`, `methods-complaints.md`, `methods-knowledge.md`, `methods-experience.md` | playbook Solution 2 and 9, variants Scenario 2 and 7 | `sample-library-ops-review-cn.md`, `sample-library-reporting-cn.md`, `sample-library-client-cn.md` | `ksyc` complaint-governance realism | 质检分掉了，投诉还在涨 |
| execution weakness and team-lead upgrade | `methods-teamlead.md`, `methods-metrics.md`, `methods-training.md`, `methods-performance.md` | playbook Solution 3 and 5, variants Scenario 3 | `sample-library-teamlead-cn.md`, `sample-library-improvement-cn.md` | `ksyc` frontline-operating realism | 现场执行不稳，班组长带不动 |
| scheduling pressure and morale risk | `methods-metrics.md`, `methods-emotion.md`, `methods-teamlead.md` | playbook Solution 4, variants Scenario 4 | `sample-library-improvement-cn.md`, `sample-library-reporting-cn.md` | `ksyc` people-and-rhythm realism | 排班紧，士气也不稳 |
| knowledge governance and rule frontloading | `methods-knowledge.md`, `methods-quality.md`, `methods-training.md` | playbook Solution 10, variants Scenario 8 | `sample-library-ops-review-cn.md` | `ksyc` consultation-to-knowledge realism | 知识库很多，但一线还是不会用 |
| complaint governance and escalation prevention | `methods-complaints.md`, `methods-experience.md`, `methods-knowledge.md` | playbook Solution 9, variants Scenario 7 | `sample-library-reporting-cn.md`, `sample-library-client-cn.md` | `ksyc` complaint-governance realism | 投诉为什么总压不下来 |
| public hotline closure and public trust | `methods-hotline.md`, `methods-digital-governance.md`, `methods-complaints.md` | playbook Solution 11, 20, 22 and 24, variants Scenario 9, 18, 20 and 22 | `sample-library-hotline-cn.md`, `sample-library-client-cn.md` | `hyhz` standards-and-credibility phrasing | 政务热线办结了，群众还不满意 |
| digital maturity and governance upgrade | `methods-digital-governance.md`, `methods-tech-enablement.md`, `methods-service-innovation.md` | playbook Solution 12, variants Scenario 10 | `sample-library-ops-review-cn.md`, `sample-library-service-innovation-cn.md`, `sample-library-client-cn.md` | `hyhz` certification framing plus `szyc` strategy tone | 数字化做了很多，管理效果还是弱 |
| service innovation and contact-center evolution | `methods-service-innovation.md`, `methods-selfservice.md`, `methods-tech-enablement.md`, `methods-multichannel.md` | playbook Solution 13, 19, 21 and 23, variants Scenario 11, 17, 19 and 21 | `sample-library-service-innovation-cn.md`, `sample-library-client-cn.md` | `szyc` strategic AI/CX tone plus `hyhz` ecosystem phrasing | 服务创新怎么证明不是讲概念 |
| CRM maturity and customer-intelligence enablement | `methods-tech-enablement.md`, `methods-digital-governance.md`, `methods-experience.md` | playbook Solution 17, variants Scenario 15 | `sample-library-outsourcing-cn.md`, `sample-library-ops-review-cn.md`, `sample-library-client-cn.md` | `hyhz` CRM-commercial practice | CRM系统有了，但价值没出来 |
| public-service standard, certification, and benchmark wording | `methods-hotline.md`, `methods-digital-governance.md` | playbook Solution 18, variants Scenario 16 | `sample-library-hotline-cn.md`, `sample-library-outsourcing-cn.md`, `sample-library-client-cn.md` | `hyhz` and `jrm` benchmark-credibility lane | 怎么写得更像行业标杆、更有公信力 |
| AI annotation delivery management | `methods-ai-annotation.md`, `methods-model-eval.md`, `methods-training.md` | playbook Solution 6, variants Scenario 5 | `sample-library-ai-annotation-cn.md` | `szyc` AI-organization tone | 标注质量不稳怎么管 |
| LLM data production and evaluation ops | `methods-llm-ops.md`, `methods-model-eval.md` | playbook Solution 7, variants Scenario 6 | `sample-library-ai-training-cn.md` | `szyc` AI-strategy tone | 大模型训练数据怎么运营 |
| embodied training operations | `methods-embodied-ops.md`, `methods-model-eval.md`, `methods-training.md` | playbook Solution 8 | `sample-library-ai-training-cn.md` | `szyc` intelligent-agent operating models | 具身机器人训练怎么稳交付 |

## Topic Families By Source Character

### Best topics for `ksyc`

Use when the user wants answers that feel grounded, operational, and close to frontline management reality:

- attrition and morale
- complaint governance
- team-lead execution
- business review rhythm
- people-process-mechanism diagnosis

### Best topics for `szyc`

Use when the user wants answers that sound more strategic, AI-era, or executive-level:

- AI-era service redesign
- human-machine collaboration
- digital maturity
- innovation proof
- capability-network and role-redesign thinking

### Best topics for `hyhz` and `jrm`

Use when the user wants stronger industry atmosphere, standards framing, benchmark naming, or credibility language:

- hotline governance
- certification and standard wording
- benchmark and ecosystem framing
- conference and capability-program naming
- client-facing proposals and maturity positioning

## Fast Routing Rules

### If the user wants diagnosis

Go to:

- matching `methods-*.md`
- `customer-world-root-cause-judgment-pack-cn.md` for management-grade cause splitting
- then `customer-world-solution-variants-cn.md` diagnosis version
- if the user wants spoken manager wording for meetings or coaching, also check `customer-world-management-talktrack-pack-cn.md`

### If the user wants an improvement plan

Go to:

- `customer-world-solution-playbook-cn.md`
- `sample-library-improvement-cn.md` for ready-to-paste improvement paragraphs
- `customer-world-special-plan-pack-cn.md` for topic-specific special plans
- then the matching topic's method file

### If the user wants root-cause judgment, issue analysis, or deeper problem splitting

Go to:

- `customer-world-root-cause-judgment-pack-cn.md`
- then the matching `methods-*.md`
- and add `methods-metrics.md` if KPI logic needs to support the judgment

### If the user wants a full solution body,整改正文, or Word/PPT-ready plan paragraph

Go to:

- `customer-world-solution-playbook-cn.md`
- then `sample-library-improvement-cn.md`
- and add the matching sample-library file if the wording needs more report polish

### If the user wants a one-page review, PPT review page, or executive summary page

Go to:

- `sample-library-reporting-cn.md`
- then `customer-world-weekly-monthly-conclusion-pack-cn.md`
- and add `customer-world-kpi-commentary-pack-cn.md` if the page needs stronger data commentary

### If the user wants titles, headline phrases, summary lines, or stronger section naming

Go to:

- `customer-world-weekly-monthly-conclusion-pack-cn.md`
- then `customer-world-executive-report-pack-cn.md`
- and add `customer-world-transformation-argument-pack-cn.md` if the wording needs more management height

### If the user wants a practical table, tracking sheet, or KPI template

Go to:

- `customer-world-table-template-pack-cn.md`
- then `metrics-dictionary.md`
- and add the matching content pack if the table needs to reflect a specific topic

### If the user wants business-line adaptation, industry-specific wording, or the same topic rewritten by line of business

Go to:

- `customer-world-industry-version-pack-cn.md`
- then `business-lines.md`
- and add the matching sample-library file for the target business line

### If the user wants weekly report or monthly review wording

Go to:

- `customer-world-solution-variants-cn.md` internal reporting version
- `customer-world-weekly-monthly-conclusion-pack-cn.md` for direct weekly/monthly conclusion paragraphs
- `sample-library-reporting-cn.md` for one-page review content
- then the matching sample library
- for direct ready-to-paste high-level reporting paragraphs, also check `customer-world-executive-report-pack-cn.md`

### If the user wants a special plan,专项方案, or fuller topic package

Go to:

- `customer-world-special-plan-pack-cn.md`
- then the matching `methods-*.md`
- and add the matching sample-library file if the plan needs report-ready polish

### If the user wants a full report structure, deck outline, or complete document skeleton

Go to:

- `customer-world-report-skeleton-pack-cn.md`
- then `customer-world-weekly-monthly-conclusion-pack-cn.md`
- and add the matching content pack for each section

### If the user wants live Q&A, boss-question handling, or meeting-response wording

Go to:

- `customer-world-scenario-qa-pack-cn.md`
- then `customer-world-objection-handling-pack-cn.md`
- and add the matching methods file if the reply needs stronger operational substance

### If the user wants a full draft, whole-document version, or directly editable sample text

Go to:

- `customer-world-report-skeleton-pack-cn.md`
- then `customer-world-solution-playbook-cn.md`
- and add the matching conclusion or sample-library pack if needed

### If the user wants AI training, LLM data operations, model-eval management, or embodied-training management written as a practical management package

Go to:

- `customer-world-ai-training-special-pack-cn.md`
- then `methods-llm-ops.md`, `methods-model-eval.md`, or `methods-embodied-ops.md`
- `customer-world-industry-version-pack-cn.md`
- and add `sample-library-ai-training-cn.md` if the wording needs more report-ready polish

### If the user raises one problem but actually needs it rewritten into weekly report, monthly review, special plan, client review, and boss wording

Go to:

- `customer-world-problem-to-deliverable-pack-cn.md`
- then `customer-world-root-cause-judgment-pack-cn.md`
- `customer-world-solution-playbook-cn.md`
- and add the matching conclusion, title, or table pack as needed

### If the user wants a management conclusion, business-review summary, or one-paragraph executive judgment

Go to:

- `customer-world-weekly-monthly-conclusion-pack-cn.md`
- then `customer-world-kpi-commentary-pack-cn.md` if KPI interpretation needs to be added
- and add `methods-metrics.md` if the conclusion also needs stronger operating judgment

### If the user wants a frontline team issue paragraph, supervisor judgment, or class-team problem summary

Go to:

- `customer-world-team-issue-pack-cn.md`
- then the matching `methods-retention.md`, `methods-teamlead.md`, `methods-quality.md`, or `methods-emotion.md`
- and add `customer-world-management-talktrack-pack-cn.md` if spoken management wording is also needed

### If the user wants KPI commentary, metrics analysis, or business-review wording

Go to:

- `customer-world-kpi-commentary-pack-cn.md`
- then `methods-metrics.md`
- and add the matching reporting sample file if the paragraph needs fuller report polish

### If the user wants client-facing wording or proposal language

Go to:

- `customer-world-solution-variants-cn.md` client-facing version
- `customer-world-client-review-pack-cn.md` for direct external-facing review paragraphs
- `sample-library-client-cn.md`
- conference-stream phrasing if industry credibility matters
- for executive summary paragraphs on transformation, hotline governance, or control capability, also check `customer-world-executive-report-pack-cn.md`

### If the user wants objection handling, client challenge response, or bid-stage Q&A wording

Go to:

- `customer-world-objection-handling-pack-cn.md`
- then `sample-library-client-cn.md`
- and add the matching `methods-*.md` file if the answer needs stronger operational substance behind the wording

### If the user wants stronger transformation explanation, executive argument, or management Q&A wording

Go to:

- `customer-world-transformation-argument-pack-cn.md`
- then the matching `methods-*.md`
- and add `sample-library-service-innovation-cn.md` if the wording needs more written-report polish

### If the user wants meeting wording, coaching script, or spoken management phrasing

Go to:

- `customer-world-management-talktrack-pack-cn.md`
- then the matching team-lead or improvement sample file if needed

### If the user wants one-on-one coaching, private correction wording, or manager-to-employee talk tracks

Go to:

- `customer-world-one-on-one-coaching-pack-cn.md`
- then `methods-teamlead.md`, `methods-emotion.md`, or `methods-performance.md`
- and add the talktrack pack if the user also wants a more public team-facing version

### If the user wants training outline, trainer script, or teachable capability-building content

Go to:

- `customer-world-training-delivery-pack-cn.md`
- then `methods-training.md`
- and add the matching team-lead or improvement sample file if the user also wants post-training landing language

### If the user wants retrospective facilitation, meeting-host wording, or post-shift review structure

Go to:

- `customer-world-retrospective-facilitation-pack-cn.md`
- then `sample-library-ops-review-cn.md`
- and add `methods-teamlead.md` or `methods-metrics.md` if the meeting also needs stronger management diagnosis logic

### If the user wants a short operational checklist

Go to:

- `customer-world-management-checklist-pack-cn.md`
- then the matching methods file if a deeper explanation is needed

## Practical Meaning

Customer World learning is strongest when it is no longer retrieved only by article title.

It should be retrievable by:

- problem
- topic
- management method
- solution structure
- document form

This file is the bridge for that retrieval model.
