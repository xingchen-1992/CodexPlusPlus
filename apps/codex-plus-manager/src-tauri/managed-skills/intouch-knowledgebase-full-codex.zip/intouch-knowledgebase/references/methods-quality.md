# QA, Calibration, and Quality-Closure Method

Use for quality decline, scorecards, scorer inconsistency, calibration, repeated defects, quality meetings, and QA-driven improvement.

## Management Judgment

Treat QA as a measurement-to-improvement system. When quality falls, first determine whether the measurement system is stable; do not blame agents while standards, samples, or scorers are inconsistent.

Treat quality as one of the strongest operational windows into customer experience and process reliability. If quality scores and customer outcomes diverge, inspect whether the quality design is measuring the true drivers of customer and business results.

## Cause Structure

Classify the defect source:

- standard: unclear, outdated, overly complex, or disconnected from customer and risk priorities
- measurement: biased sampling, inconsistent scoring, or unclear evidence
- process or policy: the correct behavior is hard or impossible within the current flow
- knowledge or script: the frontline lacks a usable judgment entry or explanation
- system or tool: interface, routing, data, or automation creates error
- capability or behavior: the agent knows the standard but cannot or does not apply it
- management: findings are published without coaching, ownership, or recheck
- trust: QA is perceived as punishment, appeal is unsafe, or scorers and operations are rewarded for opposing outcomes
- automation: model coverage is mistaken for model accuracy, or detection drift is not checked against human-reviewed samples
- scorecard fit: one form is applied across roles, channels, or journey stages with different customer, process, and compliance responsibilities

## Quality-Control Chain

Use this loop:

1. define the customer, business, and risk outcome to protect
2. translate it into a short executable scorecard
3. sample the right scenarios and risk levels
4. calibrate borderline and disputed cases
5. classify defects by source, not only by deduction item
6. assign coaching, process, knowledge, system, or policy action
7. verify recurrence and business impact
8. feed disputes, false detections, and new scenarios back into standards and model validation

Design scorecards around three explicit layers: customer-interaction quality, business-process or outcome accuracy, and compliance or critical risk. Adjust scenarios and weights by role or channel without changing shared non-negotiable boundaries.

Keep output measures separate from reason codes when practical. Score the result or customer-impact outcome clearly, then use sub-attributes or defect taxonomy to explain why the error happened. A long blended checklist often hides the true driver.

For multichannel or outsourced operations, keep one quality architecture across programs while allowing scenario-specific scoring detail. Shared scorecard logic improves comparability; local examples and weights can still adapt to role, channel, or risk level.

## Calibration Mechanism

- select normal, low-score, disputed, and boundary samples
- require independent scoring before discussion when practical
- clarify must-deduct, coaching-only, and no-deduct boundaries
- record the decision, rationale, positive and negative examples, and effective date
- keep an evidence-based appeal route and analyze overturns as a measurement-quality signal
- track scorer consistency, dispute, and overturn trends
- recalibrate promptly after product, policy, journey, channel, or AI-behavior changes instead of waiting for month-end quality drift to appear

## Coaching Connection

Route findings into:

- one-to-one coaching for individual behavior
- team refresh for common understanding gaps
- process or knowledge repair for structural defects
- immediate risk intervention for compliance or severe customer harm

Use [methods-training.md](methods-training.md) when behavior conversion or capability building is the primary problem.

## Ownership

- QA owner: scorecard, sampling, calibration, taxonomy, and evidence quality
- operations owner: prioritization, team action, and closure
- team lead: individual coaching and follow-up check
- training/knowledge/process/system/policy owners: structural correction
- governance lead or review chair when applicable: ensure quality findings translate into cross-functional decisions rather than remain inside QA

## Rhythm

- immediate: severe-risk containment
- weekly: calibration, repeated defects, and coaching closure
- monthly: scorecard usefulness, scorer variance, structural causes, and business impact
- after major change: targeted recalibration before normal scoring resumes

## Metrics and Signals

- score or pass rate by scenario and risk tier
- quality movement against customer, resolution, or repeat-contact outcomes when those relationships can be observed
- scorer consistency, dispute rate, and overturn rate
- feedback latency from interaction to coaching or structural action
- repeated-defect and post-coaching recurrence
- critical-error or compliance defect rate
- for automated QA: precision, recall, false-positive rate, false-negative risk, drift, and human-review agreement by scenario
- process/knowledge/system defect share
- complaint, repeat contact, rework, or customer impact linked to defects

## Anti-Patterns

Avoid:

- expanding the scorecard whenever a new issue appears
- treating score movement as proof of real quality change without checking calibration
- sending every problem to training
- using QA only for punishment
- assuming full interaction coverage means reliable scoring or complete risk detection
- reporting findings without owner and recheck

## Output Contract

State whether measurement is reliable, identify the defect-source mix, define containment and structural actions, assign owners, and name the recurrence and impact indicators.
