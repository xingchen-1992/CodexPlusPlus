# Intouch Knowledge Governance

Use this file to judge how strongly a source should influence an answer and how the corpus should be maintained.

## Knowledge Layers

### Distilled methods

Files such as `methods-quality.md`, `methods-metrics.md`, and `methods-ai-annotation.md` contain the preferred reusable management logic.

Use these first for diagnosis and solution design.

### Scenario and deliverable playbooks

Files such as `operations.md`, `reporting.md`, `tender.md`, `event.md`, and `business-lines.md` adapt methods to audience, KPI, risk, and output form.

Use these after selecting the method.

### Calibrated samples

Sample libraries support wording and document conversion. They do not replace diagnosis and must not be treated as factual evidence.

### Raw full text and indexes

Raw articles are knowledge inputs. Use them only after identifying a specific topic, benchmark need, or evidence gap. Do not load broad full-text indexes by default.

## Source Levels

Classify source influence before using a claim.

| Level | Typical source | Use |
| --- | --- | --- |
| A | laws, regulators, official standards, official metric definitions, primary research | authoritative definitions, requirements, and high-confidence factual grounding |
| B | established professional bodies, mature industry publications, well-documented operating methods | professional methods and benchmark context |
| C | vendor articles, company cases, practitioner opinion, promotional content | practical ideas and examples that require qualification |

Do not promote a C-level claim to an industry standard. A case proves that an approach was used in one context, not that it is universally effective.

## Freshness Classes

Classify knowledge by likely drift:

- stable: management frameworks, cause structures, operating routines
- review periodically: benchmark ranges, platform capabilities, industry practices
- verify current: laws, regulations, product features, prices, named leadership, current market or policy facts

When current accuracy matters, verify the claim or clearly state that the source may be outdated.

## Claim Discipline

Separate:

- user-provided facts
- source-supported facts
- professional inference
- assumptions used because information is missing

Never invent project data, targets, benchmark values, causes, or source support. If a quantitative target is needed but unavailable, provide a formula, a target-setting method, or an explicitly labeled example.

When using source material:

- read the actual relevant content, not only an index title
- preserve the source's applicable context and limitations
- avoid copying long passages
- synthesize the management implication in original wording
- cite or identify sources when the user requests evidence or when a high-stakes claim depends on them

## Corpus Entry Fields

When adding or refreshing an article, retain these fields when available:

- title
- source and URL
- author or issuing organization
- publication date
- retrieval or refresh date
- source level
- business line
- topic and content type
- freshness class
- applicable scenario
- limitation or vendor-interest note

Do not add a full-text article solely because it matches a keyword. It must improve diagnosis, action design, KPI selection, delivery language, or risk judgment.

## Governance Assets

Use `knowledge-governance-summary.md` for corpus-level maintenance decisions.

Filter `knowledge-governance-manifest.csv` for article-level review. Do not load the full manifest for routine business answers.

Regenerate both assets with `tools/build-knowledge-governance-manifest.py` after adding, removing, or materially changing corpus records. Treat its classifications as deterministic triage labels; manually review an article before promoting it into a `methods-*.md` file.

For the high-priority promotion queue, use `method-promotion-digests/index.md` and `method-promotion-ledger.csv`. Regenerate them with `tools/build-method-promotion-digests.py`. The digests are maintenance evidence, not runtime answer references; records marked `source_text_cleanup_required` must not influence a method until the source text is repaired.

## Promotion Rule

Promote raw content into a `methods-*.md` file only when it provides a reusable management principle, cause structure, action mechanism, KPI relationship, or decision boundary.

Do not promote news, event announcements, broad trend commentary, or unsupported slogans into the method layer.

Record one of these outcomes in the promotion ledger:

- `synthesized_at_lane_level`: reviewed as part of a topic evidence pool; only recurring net-new mechanisms entered the method file
- `pending_review`: source text is repaired and evidence is available, but the recovered content still needs lane-level synthesis
- `retain_background`: useful context but too weak, narrow, or mismatched for method promotion
- `defer`: source quality, date, or corroboration must be repaired first
