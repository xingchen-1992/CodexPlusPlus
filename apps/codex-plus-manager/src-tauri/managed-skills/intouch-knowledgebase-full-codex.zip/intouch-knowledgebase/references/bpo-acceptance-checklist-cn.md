# BPO Acceptance Checklist CN

Use this file to verify whether the skill can really answer practical BPO questions in a professional and reusable way after learning Customer World content.

This file is not for article harvesting.
It is for final-use acceptance.

## Acceptance Goal

The goal is to verify three things:

1. can the skill identify the right BPO problem type quickly
2. can the skill give professional judgment before giving format
3. can the skill produce executable management action or directly usable wording

## Acceptance Standard

A pass-level answer should meet all of these:

1. the topic cluster is correct
2. the diagnosis is not generic
3. the cause split is management-grade rather than slogan-like
4. the action package includes owners or rhythms when needed
5. the KPI or watchpoints are relevant
6. the wording sounds like BPO management material, not ordinary chat

## Core Acceptance Questions

### 1. Operations and floor management

Question:

- 现场最近总是乱，班组长每天都很忙，但问题还是反复发生，怎么处理

Expected route:

- `operations and floor management`

Expected answer traits:

- first judge whether the real issue is routine weakness, owner ambiguity, or weak follow-up
- should mention pre-shift / intraday / post-shift management actions
- should not answer only with “加强管理”

### 2. KPI and business-review management

Question:

- 经营分析会老开成报数会，怎么改

Expected route:

- `KPI and business-review management`

Expected answer traits:

- first judge whether the problem is lack of variance interpretation or lack of action closure
- should mention KPI split, variance source, and review rhythm
- should sound usable for a management meeting

### 3. Quality assurance and coaching

Question:

- 质检分连续两周下滑，但培训也做了，为什么还是压不住

Expected route:

- `quality assurance and coaching`

Expected answer traits:

- should split defects into rule / knowledge / process / people causes
- should mention calibration and repeated-problem closure
- should not reduce the issue to employee attitude

### 4. Staffing, scheduling, and workforce balance

Question:

- 人不少，但晚高峰还是扛不住，这到底是排班问题还是现场问题

Expected route:

- `staffing, scheduling, and workforce balance`

Expected answer traits:

- should separate shortage from structure mismatch
- should mention traffic curve, break concentration, intraday dispatch, or cross-skill support
- should give a trial-and-recheck idea

### 5. Complaints and escalation governance

Question:

- 投诉和升级最近一起涨，这种情况先抓什么

Expected route:

- `complaints and escalation governance`

Expected answer traits:

- should separate immediate stabilization from structural governance
- should mention complaint reason split, high-risk scenes, and closure quality
- should not answer only with “加强服务意识”

### 6. Performance, motivation, and team stability

Question:

- 流失率高，士气也差，现在应该先管离职还是先管情绪

Expected route:

- `performance, motivation, and team stability`

Expected answer traits:

- should judge whether the risk is concentrated in early tenure, schedule fairness, supervisor care, or incentive distortion
- should mention 30/60/90-day checkpoints or high-risk roster
- should show sequence rather than giving scattered suggestions

### 7. Knowledge governance and process optimization

Question:

- 知识库一直在更新，但一线还是老来问人，这到底说明什么

Expected route:

- `knowledge governance and process optimization`

Expected answer traits:

- should judge whether the issue is usability, indexing, version governance, or process drift
- should mention scenario entries and use-effect review
- should not praise the knowledge base just because content is large

### 8. Client reporting and management communication

Question:

- 帮我写一段给甲方的周报总结，重点讲满意度波动和下周动作

Expected route:

- `client reporting and management communication`

Expected answer traits:

- should begin with overall conclusion
- should include KPI trend + issue/cause + action + next-stage line
- should sound directly usable in a client summary

### 9. Proposal, RFP, and service-solution output

Question:

- 这个客服项目投标，怎么把服务方案写得更像专业 BPO 服务商

Expected route:

- `proposal, RFP, and service-solution output`

Expected answer traits:

- should switch to client-facing service-model logic
- should mention service model, staffing or governance, SLA, and risk response
- should not answer like an internal management memo

### 10. AI-enabled service and future operating models

Question:

- AI客服上线了，但领导觉得没看出价值，这种汇报怎么讲

Expected route:

- `AI-enabled service and future operating models`

Expected answer traits:

- should distinguish launch from value proof
- should mention human-machine boundary, quality/governance, and value-proof logic
- should not stop at abstract digital-transformation language

## Extended Acceptance Questions

These are useful after the first 10 pass:

1. 班组长只会盯指标，不会带人，怎么做辅导机制
2. 服务水平掉了，但 AHT 没变长，这种情况怎么看
3. 投诉集中在物流解释场景，帮我做一版专项复盘
4. 规则更新后各组理解不一致，怎么快速拉稳准确率
5. 大模型数据质量不稳，怎么做运营闭环
6. 模型评测分数不错，但业务场景表现不稳，汇报时怎么讲

## Pass / Risk / Fail Rule

### Pass

- route is correct
- diagnosis is specific
- action path is executable
- wording sounds professional and reusable

### Risk

- route is roughly right
- but answer is still too generic, too light, or too template-like

### Fail

- route is wrong
- diagnosis is shallow
- no real cause split
- no action rhythm or management owner
- wording sounds like ordinary chat instead of BPO management output

## Practical Meaning

If the skill can answer these questions well, then the Customer World learning has not only been stored.

It has been converted into usable BPO solution capability.
