# KPI and Variance-Management Method

Use for KPI design, operating reviews, business-analysis meetings, productivity diagnosis, variance control, and action closure.

## Management Judgment

Treat metrics as a decision system, not a reporting product. When meetings become number-reading sessions, the missing link is usually variance interpretation, ownership, or action verification.

## Cause Structure

For an abnormal KPI, separate:

- measurement: definition, denominator, time window, or data-quality error
- demand: volume, mix, channel, campaign, or scenario change
- capacity: staffing, skill, adherence, shrinkage, or tool availability
- execution: behavior, coaching, handoff, or process compliance
- mechanism: target conflict, incentive distortion, or missing threshold
- gaming: local optimization, denominator manipulation, selective case handling, or behavior that protects the number while harming the outcome
- controllability: the result is assigned to a role that cannot influence the main driver
- avoidable demand: repeated contacts or workload are treated only as productivity volume instead of a process, product, or communication defect to remove
- upstream: policy, product, system, logistics, or client dependency

Read both level and distribution. An acceptable average can hide serious variation by interval, team, tenure, scenario, or channel.

## Decision Chain

Require every review to answer:

1. what changed and against which baseline
2. where the change is concentrated
3. what evidence supports the main cause
4. whether it is temporary or structural
5. what decision follows
6. who owns it and when it will be verified
7. what guardrail will show whether the countermeasure creates a new problem

Review the portfolio across accessibility, efficiency, quality, customer, cost, people, risk, and strategic value. Not every review needs every dimension, but the operating system should not be blind to one of them.

Distinguish between:

- program-level scorecards that govern the operation, resource decisions, and cross-functional accountability
- agent-level scorecards that support coaching, development, and fair people decisions

Do not use one scorecard structure to serve both purposes without clarifying which management decision it exists to support.

Use a small KPI tree:

- outcome indicators: customer, quality, delivery, revenue, or cost result
- driver indicators: workload, capacity, behavior, process, or quality cause
- early-warning indicators: adherence, backlog age, repeat defects, complaints, or risk signals

## Action Mechanism

- select the three to five indicators needed for the decision
- maintain a metric charter with definition, denominator, source, owner, refresh rhythm, and known limitation
- review the metric set when channel mix, customer promise, process, technology, or economic conditions materially change
- segment the gap by interval, team, scenario, channel, or tenure
- pair productivity indicators with quality, customer, risk, and people guardrails
- standardize scorecard architecture across sites or programs by keeping common category logic, weighting method, calculation rules, and review cadence while allowing local targets or contract-specific metrics
- define one primary cause and secondary contributors
- require the owner of each underperforming metric to prepare root-cause analysis before the formal review; use the review meeting to confirm decisions, allocate resources, and close prior actions
- assign one owner, one action, one due date, and one proof signal
- open the next review by closing the previous action ledger

## Ownership

- data or BI owner: definition and data quality
- operations owner: diagnosis and action integration
- functional owner: QA, WFM, training, process, system, or HR correction
- meeting chair: prioritization and closure discipline

## Rhythm

- intraday: queue, capacity, backlog, and service risk
- daily: major exception and immediate owner action
- weekly: trend, repeated causes, and action closure
- monthly: target fit, structural mechanisms, and cross-functional issues

## Metrics and Signals

Choose indicators according to the decision. Do not apply one KPI set to every business line.

Useful control signals include:

- target gap and trend
- scorecard target relevance and target age when a metric is repeatedly exceeded or has lost decision value
- interval or team variance
- distribution width, standard deviation, or coefficient of variation when scale and sample size make them meaningful
- forecast error and adherence
- repeat-contact or repeated-defect rate
- action closure and overdue rate
- productivity with its quality or customer guardrail
- cost per contact decomposed into workload, staffing, utilization, handling, channel mix, support cost, and preventable-demand drivers when cost is the decision

## Anti-Patterns

Avoid:

- treating averages as the complete story
- listing every KPI without a management decision
- assuming correlation proves the cause
- pushing productivity without quality, customer, or people guardrails
- cascading a target to a role that cannot control its main drivers
- treating a precise dashboard as proof that the underlying definition and behavior are sound
- repeating an action that has no owner or proof signal

## Output Contract

State the KPI change, concentration, cause evidence, decision, owner, timing, and next verification point.
