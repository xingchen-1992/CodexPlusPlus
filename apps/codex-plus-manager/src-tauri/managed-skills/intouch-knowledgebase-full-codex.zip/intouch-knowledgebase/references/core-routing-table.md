# Intouch Core Routing Table

Use this as the single primary router for BPO business questions. Select the smallest sufficient route; do not read every listed file.

## Routing Rules

1. Start with one primary method file.
2. Add one scenario or deliverable file only when the requested output requires it.
3. Add one sample library only for direct reusable wording.
4. Use broad indexes or raw full text only for deeper grounding, benchmarks, or uncommon questions.
5. Use `metrics-dictionary.md` when metric definition, formula, or KPI selection is central.
6. Use `quality-bar.md` for formal deliverables and `bad-patterns.md` when the draft becomes generic.

## Main Routes

| User topic | Primary method | Add when needed | Sample or output support |
| --- | --- | --- | --- |
| Floor management, team-lead routines, repeated firefighting | [methods-teamlead.md](methods-teamlead.md) | [operations.md](operations.md) | [sample-library-teamlead-cn.md](sample-library-teamlead-cn.md) |
| KPI review, variance, operating rhythm, productivity | [methods-metrics.md](methods-metrics.md) | [operations.md](operations.md), [metrics-dictionary.md](metrics-dictionary.md) | [sample-library-ops-review-cn.md](sample-library-ops-review-cn.md) |
| COPC, standards-based CX operating system, certification-style management framework | [copc-core.md](copc-core.md) | [copc-problem-solving-playbook.md](copc-problem-solving-playbook.md), [copc-scenario-lab.md](copc-scenario-lab.md), [copc-rfp-sla-governance.md](copc-rfp-sla-governance.md), [copc-client-reporting-and-defense.md](copc-client-reporting-and-defense.md), [copc-defense-qna-bank.md](copc-defense-qna-bank.md), [copc-gap-map.md](copc-gap-map.md), [operations.md](operations.md) | [sample-library-ops-review-cn.md](sample-library-ops-review-cn.md) |
| WFM, staffing, scheduling, service level, attendance | [methods-wfm.md](methods-wfm.md) | [operations.md](operations.md), [business-lines.md](business-lines.md) | [examples-operations.md](examples-operations.md) |
| QA, scorecards, calibration, repeated defects | [methods-quality.md](methods-quality.md) | [operations.md](operations.md), [metrics-dictionary.md](metrics-dictionary.md) | [sample-library-improvement-cn.md](sample-library-improvement-cn.md) |
| Training, onboarding, capability building | [methods-training.md](methods-training.md) | [operations.md](operations.md) | [sample-library-teamlead-cn.md](sample-library-teamlead-cn.md) |
| Attrition, retention, absenteeism, morale | [methods-retention.md](methods-retention.md) | [methods-emotion.md](methods-emotion.md), [operations.md](operations.md) | [sample-library-improvement-cn.md](sample-library-improvement-cn.md) |
| Performance and incentives | [methods-performance.md](methods-performance.md) | [operations.md](operations.md), [metrics-dictionary.md](metrics-dictionary.md) | [sample-library-improvement-cn.md](sample-library-improvement-cn.md) |
| Complaints, escalation, service recovery | [methods-complaints.md](methods-complaints.md) | [event.md](event.md), [methods-experience.md](methods-experience.md) | [sample-library-client-cn.md](sample-library-client-cn.md) |
| Satisfaction and customer experience | [methods-experience.md](methods-experience.md) | [reporting.md](reporting.md), [metrics-dictionary.md](metrics-dictionary.md) | [sample-library-reporting-cn.md](sample-library-reporting-cn.md) |
| Knowledge base, SOP drift, rule governance | [methods-knowledge.md](methods-knowledge.md) | [operations.md](operations.md) | [sample-library-ops-review-cn.md](sample-library-ops-review-cn.md) |
| Text, ecommerce, multichannel service | [methods-multichannel.md](methods-multichannel.md) | [business-lines.md](business-lines.md), [methods-selfservice.md](methods-selfservice.md) | [sample-library-service-innovation-cn.md](sample-library-service-innovation-cn.md) |
| Public hotline and public-service operations | [methods-hotline.md](methods-hotline.md) | [business-lines.md](business-lines.md), [event.md](event.md) | [sample-library-hotline-cn.md](sample-library-hotline-cn.md) |
| Self-service and human-machine collaboration | [methods-selfservice.md](methods-selfservice.md) | [methods-service-innovation.md](methods-service-innovation.md) | [sample-library-service-innovation-cn.md](sample-library-service-innovation-cn.md) |
| Platform, SaaS, BI, unified communications | [methods-tech-enablement.md](methods-tech-enablement.md) | [methods-service-innovation.md](methods-service-innovation.md) | [sample-library-service-innovation-cn.md](sample-library-service-innovation-cn.md) |
| Outsourcing platform and delivery architecture | [methods-outsourcing-platform.md](methods-outsourcing-platform.md) | [business-lines.md](business-lines.md), [tender.md](tender.md), [copc-rfp-sla-governance.md](copc-rfp-sla-governance.md) | [sample-library-outsourcing-cn.md](sample-library-outsourcing-cn.md) |
| Digital governance and maturity | [methods-digital-governance.md](methods-digital-governance.md) | [methods-service-innovation.md](methods-service-innovation.md) | [sample-library-outsourcing-cn.md](sample-library-outsourcing-cn.md) |
| AI annotation quality and delivery | [methods-ai-annotation.md](methods-ai-annotation.md) | [metrics-dictionary.md](metrics-dictionary.md) | [sample-library-ai-annotation-cn.md](sample-library-ai-annotation-cn.md) |
| SFT, preference data, safety data, LLM data production | [methods-llm-ops.md](methods-llm-ops.md) | [ai-training-index.md](ai-training-index.md) | [sample-library-ai-training-cn.md](sample-library-ai-training-cn.md) |
| Model evaluation, human review, benchmark governance | [methods-model-eval.md](methods-model-eval.md) | [ai-training-index.md](ai-training-index.md) | [sample-library-ai-training-cn.md](sample-library-ai-training-cn.md) |
| Embodied data collection, teleoperation, trajectory quality | [methods-embodied-ops.md](methods-embodied-ops.md) | [ai-training-index.md](ai-training-index.md) | [sample-library-ai-training-cn.md](sample-library-ai-training-cn.md) |

## Deliverable Conversion

After the management judgment is clear, add only the matching deliverable file:

| Requested deliverable | Read |
| --- | --- |
| Weekly report, monthly report, review, client summary | [reporting.md](reporting.md), [copc-client-reporting-and-defense.md](copc-client-reporting-and-defense.md), [copc-defense-qna-bank.md](copc-defense-qna-bank.md) |
| Operations diagnosis or improvement plan | [operations.md](operations.md) |
| RFP, proposal, SLA, staffing model, defense Q&A | [tender.md](tender.md), [copc-rfp-sla-governance.md](copc-rfp-sla-governance.md) |
| Incident, conflict, complaint escalation, staffing emergency | [event.md](event.md) |
| Direct Chinese reporting wording | [sample-library-reporting-cn.md](sample-library-reporting-cn.md) |
| Direct Chinese improvement-plan wording | [sample-library-improvement-cn.md](sample-library-improvement-cn.md) |
| Direct client-facing wording | [sample-library-client-cn.md](sample-library-client-cn.md) |

## Deeper Source Route

Use deeper sources only when the user asks for stronger methodology, benchmark grounding, article learning, or a niche issue not covered by the distilled method files.

- Search [customer-world-topic-solution-index.md](customer-world-topic-solution-index.md) for topic-level Customer World routing.
- Search [external-ops-fulltext-index.md](external-ops-fulltext-index.md) for WFM, QA, contact-center benchmarks, AI data operations, and evaluation governance.
- Use [customer-world-fulltext-index.md](customer-world-fulltext-index.md) or raw full text only after identifying a specific relevant topic or article.
- Use [customer-world-conference-stream-themes.md](customer-world-conference-stream-themes.md) only when the user explicitly wants conference, certification, ecosystem, or broader industry context.

Do not infer that an indexed article was used unless its content was actually read. Do not assign authority based only on source volume.

## High-Frequency Shortcut

For attrition, QA decline, schedule pressure, complaint rise, or weak team-lead execution, use [high-frequency-problem-routes.md](high-frequency-problem-routes.md) if the primary method file does not provide a sufficiently direct route.

For broad practical problem solving across multiple domains, use [customer-world-problem-solving-map.md](customer-world-problem-solving-map.md). Do not add it automatically to narrow questions.
