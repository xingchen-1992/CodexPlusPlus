# Customer World BPO Standard Response Map

Use this file when the user asks a short or medium BPO question and the skill needs a stable default response path for one of the main BPO topic clusters.

This file converts the business-facing topic clusters into:

1. standard diagnosis frame
2. standard action package
3. standard KPI watchpoints
4. standard user-ask mapping
5. standard output direction

## Core Use

The goal is to stop the skill from re-deciding the whole answer logic from scratch every time.

For each major BPO topic cluster, this file defines the default first answer shape.

Use it after:

- `customer-world-bpo-topic-clusters.md`

and before:

- detailed methods files
- sample files
- long-form solution packs

## Standard Cluster Response Table

| BPO Topic Cluster | Standard diagnosis frame | Standard action package | KPI watchpoints | Typical user asks | Best first output |
| --- | --- | --- | --- | --- | --- |
| operations and floor management | is the issue target translation, routine weakness, exception ownership, or cross-role follow-up | split KPI into pre-shift / intraday / post-shift actions, define abnormal-scenario owner, tighten daily review rhythm, make repeated issues close-loop | service level, repeated abnormal scenarios, team-lead coaching completion, same-day closure rate | 现场乱、班长弱、执行不稳、带不住 | management diagnosis + execution recovery plan |
| KPI and business-review management | is the KPI issue structural, temporary, behavioral, or reporting-only | split metric variance, identify main driver, define weekly review rhythm, translate KPI into operational actions, prepare management commentary | KPI variance, trend slope, gap concentration, action closure rate, next-period risk points | 指标怎么拆、经营分析会怎么开、复盘怎么讲 | KPI diagnosis + business-review summary |
| quality assurance and coaching | is quality loss caused by rule, knowledge, process, tool, or people capability | defect classification, calibration, one-to-one coaching, repeated-scenario recheck, rule/SOP refresh | QA score, defect concentration, recheck pass rate, repeat-defect recurrence, complaint linkage | 质检分掉、辅导没用、校准争议多 | root-cause judgment + quality improvement plan |
| staffing, scheduling, and workforce balance | is the problem headcount shortage, roster structure, shrinkage, break-window design, intraday dispatch, or tolerance/fairness | check traffic curve vs seat curve, adjust shift structure, control break concentration, add relief/support logic, set trial and recheck period | service level, occupancy, peak-gap coverage, abnormal leave rate, schedule satisfaction | 排班顶不住、SLA老掉、人不少还忙不过来 | staffing diagnosis + shift adjustment plan |
| complaints and escalation governance | is the complaint issue expectation-setting, process closure, sensitive wording, trust boundary, or coordination failure | classify complaint reasons, define high-risk scenes, tighten callback/closure wording, separate case handling from structural governance, review repeat issues weekly | complaint rate, escalation rate, repeat complaints, closure timeliness, same-cause recurrence | 投诉高、升级多、客诉压不住 | complaint diagnosis + governance plan |
| performance, motivation, and team stability | is the people issue early-tenure loss, morale decline, incentive distortion, supervisor weakness, or unfair experience | split high-risk groups, build 30/60/90-day checkpoints, tighten one-to-one communication, refresh incentive fairness, set weekly risk roster | attrition rate, early-tenure attrition, absenteeism, high-risk roster size, key-person stability | 流失高、士气差、激励没带动、团队不稳 | people-risk diagnosis + stability improvement plan |
| knowledge governance and process optimization | is the issue content shortage, usability failure, version governance weakness, or process-to-knowledge delay | mine high-frequency consultations, rebuild scenario entries, define release/abolish owner chain, review post-release use effect, connect knowledge to QA and AHT problems | knowledge hit rate, escalation from knowledge gaps, consultation volume, FCR, long-handle share | 知识库不会用、规则老滞后、流程总卡 | knowledge-governance diagnosis + SOP/KB plan |
| client reporting and management communication | is the user trying to explain status, defend performance, summarize problems, or push next-stage plan | give overall conclusion first, then KPI trend, then problem/cause/action, then next-step commitments, and adapt tone to internal vs client audience | KPI summary block, trend movement, key risk points, corrective-action progress, next-period commitments | 周报、月报、甲方汇报、经营回顾 | report-ready management summary |
| proposal, RFP, and service-solution output | is the task about client pain-point understanding, operating model, staffing, SLA, governance, or risk response | define client perspective, translate pain point to service model, present staffing/governance/SLA, add risk response and differentiation, prepare Q&A or challenge handling | staffing logic, SLA commitments, governance rhythm, risk-control coverage, differentiators | 标书怎么答、RFP怎么写、方案怎么专业 | client-facing solution draft |
| AI-enabled service and future operating models | is the issue AI service redesign, self-service/human handoff, data production, quality calibration, or transformation value proof | split scenario, clarify human-machine boundary, define quality and arbitration loop, connect data to management actions, prove value by stage | automation success, handoff success, evaluation consistency, quality pass rate, value-proof cadence | AI客服怎么做、标注质量不稳、大模型运营怎么管 | transformation diagnosis + AI operating plan |

## Standard Cluster Playbooks

### 1. Operations and floor management

Default answer order:

1. current execution judgment
2. where the routine broke
3. what must be fixed today / this week
4. who owns each repeated issue
5. what to review next

Default first files:

- `methods-teamlead.md`
- `methods-metrics.md`
- `operations.md`
- `customer-world-management-checklist-pack-cn.md`

### 2. KPI and business-review management

Default answer order:

1. overall KPI judgment
2. core variance split
3. which variance matters most
4. management action linked to the variance
5. review wording and next-step line

Default first files:

- `methods-metrics.md`
- `reporting.md`
- `customer-world-kpi-commentary-pack-cn.md`
- `customer-world-weekly-monthly-conclusion-pack-cn.md`

### 3. Quality assurance and coaching

Default answer order:

1. quality judgment
2. defect-source split
3. immediate calibration/coaching action
4. repeated-problem closure mechanism
5. recheck indicator

Default first files:

- `methods-quality.md`
- `methods-knowledge.md`
- `customer-world-root-cause-judgment-pack-cn.md`
- `customer-world-one-on-one-coaching-pack-cn.md`

### 4. Staffing, scheduling, and workforce balance

Default answer order:

1. service-level judgment
2. structure vs shortage split
3. schedule and intraday control actions
4. morale/fairness reminder
5. trial period and recheck

Default first files:

- `methods-metrics.md`
- `operations.md`
- `examples-operations.md`
- `customer-world-table-template-pack-cn.md`

### 5. Complaints and escalation governance

Default answer order:

1. complaint-governance judgment
2. root-cause family split
3. immediate stabilization action
4. prevention/governance action
5. review rhythm and owner

Default first files:

- `methods-complaints.md`
- `methods-experience.md`
- `event.md`
- `customer-world-solution-playbook-cn.md`

### 6. Performance, motivation, and team stability

Default answer order:

1. people-risk judgment
2. who is unstable and why
3. what to do in 7/30/60/90 days
4. what team leads and supervisors must own
5. what to monitor weekly

Default first files:

- `methods-retention.md`
- `methods-emotion.md`
- `customer-world-team-issue-pack-cn.md`
- `sample-library-improvement-cn.md`

### 7. Knowledge governance and process optimization

Default answer order:

1. governance judgment
2. why the frontline still cannot use it
3. which scenes must be rebuilt first
4. who owns version / release / validation
5. how to verify effect

Default first files:

- `methods-knowledge.md`
- `methods-quality.md`
- `customer-world-management-checklist-pack-cn.md`
- `customer-world-solution-playbook-cn.md`

### 8. Client reporting and management communication

Default answer order:

1. overall conclusion
2. KPI trend and key highlight
3. main issue and cause
4. corrective action progress
5. next-stage plan and confidence line

Default first files:

- `reporting.md`
- `sample-library-reporting-cn.md`
- `customer-world-executive-report-pack-cn.md`
- `customer-world-client-review-pack-cn.md`

### 9. Proposal, RFP, and service-solution output

Default answer order:

1. client pain-point judgment
2. service model and mechanism
3. staffing and SLA logic
4. risk response and governance rhythm
5. differentiation and likely Q&A

Default first files:

- `tender.md`
- `sample-library-client-cn.md`
- `customer-world-report-skeleton-pack-cn.md`
- `customer-world-objection-handling-pack-cn.md`

### 10. AI-enabled service and future operating models

Default answer order:

1. transformation or AI-ops judgment
2. boundary split between people / tool / process / data
3. rollout or stabilization action
4. quality and governance mechanism
5. value-proof or phase-review logic

Default first files:

- `methods-service-innovation.md`
- `methods-llm-ops.md`
- `methods-ai-annotation.md`
- `customer-world-transformation-argument-pack-cn.md`

## Short-Question Mapping

If the user asks in a very short way, map by these examples:

- “现场乱了” -> operations and floor management
- “指标压不住” -> KPI and business-review management
- “质检分掉了” -> quality assurance and coaching
- “排班顶不住” -> staffing, scheduling, and workforce balance
- “投诉太多” -> complaints and escalation governance
- “人不稳” -> performance, motivation, and team stability
- “知识库没用” -> knowledge governance and process optimization
- “帮我写甲方汇报” -> client reporting and management communication
- “这个投标怎么答” -> proposal, RFP, and service-solution output
- “AI客服/标注怎么管” -> AI-enabled service and future operating models

## Final Rule

If the user gives only one sentence, do not start from formatting.

Start from the matching standard cluster response above, then deepen with:

1. method file
2. root-cause or solution pack
3. sample or report pack if needed

That is the stable route from BPO topic cluster to usable professional response.
