# Attrition, Retention, and Stability Method

Use for attrition, early-tenure loss, key-talent loss, hiring fit, morale-linked instability, attendance warning, and retention mechanisms.

## Management Judgment

Do not pursue the lowest possible attrition. Separate healthy movement from preventable loss, concentrated early-tenure loss, and key-talent loss. Treat attrition as an operating-system outcome shared by recruitment, onboarding, supervision, scheduling, performance, and employee experience.

## Cause Structure

Segment the cause:

- fit: recruitment profile or realistic job preview is weak
- onboarding: training, nesting, and early support do not prepare employees for real work
- supervisor: communication, fairness, feedback, or recognition varies by team
- work design: schedule, breaks, workload, emotional labor, or system friction is unsustainable
- performance: target or incentive design creates perceived unfairness or constant failure
- growth and belonging: role identity, development, recognition, or team attachment is weak
- early disengagement: absence, lateness, transfer requests, participation decline, quality volatility, or withdrawal from coaching
- presenteeism: the employee remains present but shows exhaustion, reduced judgment, skipped recovery, or sustained output decline before absence or resignation
- external: labor-market, location, seasonality, or competitor change

## Risk Segmentation

Read attrition by:

- tenure: 0–30, 31–60, 61–90 days, later tenure
- performance and critical skill
- team, supervisor, shift, site, and business line
- voluntary versus involuntary
- regrettable versus non-regrettable
- reason category and time concentration

Use emotion and attendance as early signals, not proof of resignation intent. Read [methods-emotion.md](methods-emotion.md) when burnout or emotional incidents are central.

## Action Mechanism

- immediate: identify high-risk segments, protect service and people, and address reversible workload or fairness issues
- early tenure: improve job preview, training release, nesting, buddy support, and 30/60/90-day check-ins
- supervisor: require regular stay conversations, fair schedule communication, and issue escalation
- work experience: improve practical schedule choice, shift-swap access, recovery breaks, task variety, and manager role-modeling where operationally feasible
- emotion risk: use a tiered monitor-warning-intervention approach, with privacy boundaries and qualified support for serious cases
- structural: calibrate hiring profile, schedule policy, incentives, growth paths, and supervisor capability
- economics: quantify vacancy, recruitment, training, ramp loss, overtime, quality, and customer impact before deciding attrition is cheaper than retention
- departure: conduct structured exit review, protect customer quality, and complete knowledge handoff

## Ownership

- HR/recruitment: fit, labor-market insight, and exit data quality
- training: readiness and early-tenure support
- team lead/supervisor: warning detection, stay conversation, and local management action
- WFM/OM: workload, schedule fairness, and project mechanism
- senior operations: cross-team variance and structural correction

## Rhythm

- weekly: high-risk roster and immediate actions
- monthly: cohort, team, reason, and key-talent review
- quarterly: hiring, schedule, incentive, and supervisor-mechanism review

## Metrics and Signals

- voluntary, early-tenure, and key-talent attrition
- 30/60/90-day retention
- regrettable loss and team-to-team variance
- absenteeism, adherence, schedule complaints, and emotional incidents
- transfer requests, coaching withdrawal, quality volatility, and repeated high-conflict exposure
- stay-interview action closure
- hiring-to-stable-production conversion

## Anti-Patterns

Avoid:

- treating attrition as only an HR or salary problem
- launching broad care activities without risk segmentation
- hiding unhealthy management behind a “young people are unstable” narrative
- forcing retention of poor fit or harmful behavior
- measuring conversations completed without action closure
- treating wellness activities as a substitute for workload, fairness, or manager correction
- monitoring emotion without consent, safeguards, escalation boundaries, or a real support path

## Output Contract

State the attrition type, risk segment, leading evidence, immediate retention action, structural owner split, review rhythm, and success measures.
