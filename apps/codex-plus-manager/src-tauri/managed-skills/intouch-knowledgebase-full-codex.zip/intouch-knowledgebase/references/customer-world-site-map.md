# Customer World Site Map and Harvest Notes

Use this file when continuing the long-term goal of absorbing Customer World content at broader scale.

For the current skill strategy, treat this file as a site-acquisition reference only.
It does not override the active learning boundary, which is centered on operations-management value.

This file is not a management-method file. It is an acquisition map for where the content lives and how the site is paginated.

## Top-Level Navigation Observed

Main navigation on the site home page currently exposes:

- `/hyyw/` industry news
- `/hyhz/` conferences and exhibitions
- `/ycwz/` original articles
- `/cjyj/` scenario research
- `/hyxx/` member information
- `/zjgd/` expert viewpoints
- `/ftdh/` interview dialogue
- `/jrm/` Golden Headset related content

## Category Pagination Observed

The following category pages were directly checked and their current pagination pattern was visible:

### `/cjyj/` Scenario Research

- total count observed: 966
- last page observed: 49
- pagination pattern: `/cjyj/p2.html`, `/cjyj/p3.html`
- harvest boundary reached: pages `1-49`
- current-page extraction value:
  this category contains many service-case, experience, channel, and public-service related articles that are highly reusable for management-method enrichment.

### `/hyyw/` Industry News

- total count observed: 3441
- last page observed: 173
- pagination pattern: `/hyyw/p2.html`, `/hyyw/p3.html`
- harvest boundary reached: pages `1-173`
- current-page extraction value:
  this category is much broader and noisier, but it contains standards, outsourcing trends, certifications, and industry-structure signals useful for context framing.

### `/hyxx/` Member Information

- total count observed: 2408
- last page observed: 121
- pagination pattern: `/hyxx/p2.html`, `/hyxx/p3.html`
- harvest boundary reached: pages `1-121`
- current-page extraction value:
  this category often carries ecosystem updates, maturity models, reports, and organization announcements that help frame capability evolution.

### `/hyhz/` Conferences and Exhibitions

- total count observed: 2264
- last page observed: 114
- pagination pattern: `/hyhz/p2.html`, `/hyhz/p3.html`
- harvest boundary reached: pages `1-114`
- current-page extraction value:
  this category is useful for conference themes, capability-taxonomy language, certification naming, training-program signals, and broader ecosystem context around customer centers and AI-related roles.

### `/zjgd/` Expert Viewpoints

- total count observed: 61
- last visible page range harvested: 1-4
- pagination pattern observed: `/zjgd/p2.html`
- current-page extraction value:
  this is a compact but high-value category for extracting explicit观点, standards interpretation, and management phrasing.

### `/ftdh/` Interview Dialogue

- total count observed: 151
- last page observed: 8
- currently harvested through page 8
- pagination pattern: `/ftdh/p2.html`, `/ftdh/p3.html`
- current-page extraction value:
  this category is useful for industry interviews, outsourcing geography, client-service transformation, and high-level benchmark language.

## Original-Article Note

The `/ycwz/` entry appears to surface sub-streams such as:

- `/ksyc/`
- `/szyc/`

This suggests that "original articles" may be a gateway category rather than a single simple list. When harvesting original-article content, inspect the sub-stream pages directly instead of assuming one flat archive.

### `/ksyc/` Customer World Original Articles

- total count observed: 179
- last page observed: 9
- pagination pattern: `/ksyc/p2.html`, `/ksyc/p3.html`
- current-page extraction value:
  this stream contains a high concentration of first-hand management essays on service operations, AI, organization, and transformation themes that are especially useful for enriching professional methodology tone.

### `/szyc/` CEO Original Articles

- total count observed: 35
- last visible page range observed: 1-2
- pagination pattern observed: `/szyc/p2.html`
- current-page extraction value:
  this stream is smaller, but it is dense in strategy-level phrasing, service philosophy, and transformation judgment that can strengthen executive-style writing.

### `/jrm/` Golden Headset Related Content

- total count observed: 11
- last page observed: 1
- pagination pattern: single page observed
- current harvest boundary: pages `1-1`
- current-page extraction value:
  this category is small but useful for award-history and benchmark-language context, especially when the skill needs industry-recognition phrasing.

## Practical Harvest Rule

For the current operations-management learning target, keep the active harvest order as:

1. `cjyj` for reusable service-management and scenario articles
2. `ksyc` for first-hand original management thought and transformation language
3. `ftdh` for benchmark and industry-language reinforcement
4. `zjgd` for dense观点 and standards interpretation
5. `szyc` for compact executive-level strategic phrasing

Do not actively harvest `hyxx`, `hyhz`, `hyyw`, or `jrm` for the main skill-learning path.
They may remain archived for traceability, but they are not priority learning lanes.

## Current Harvest Boundaries

The current broad-harvest boundary stands at:

- `cjyj`: complete through visible last page `49`
- `hyxx`: complete through visible last page `121`
- `hyhz`: complete through visible last page `114`
- `hyyw`: complete through visible last page `173`
- `ftdh`: through visible last page `8`
- `jrm`: through visible last page `1`
- `zjgd`: through visible range `1-4`
- `ksyc`: through visible last page `9`
- `szyc`: through visible range `1-2`

## Repeatability Rule

Because the site uses predictable `pN.html` pagination, it is feasible to harvest category lists progressively rather than manually adding single articles one by one.

## Related Files

For actual harvested outputs and progress status, also read:

- [customer-world-harvest-progress.md](customer-world-harvest-progress.md)
- `customer-world-master-seed.csv` if the broader historical seed table is still needed for traceability
