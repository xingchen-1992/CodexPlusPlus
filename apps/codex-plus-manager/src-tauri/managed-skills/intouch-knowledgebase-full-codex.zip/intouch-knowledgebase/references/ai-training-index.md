# AI Training Source Index

Use this file as a source map for AI training operations, LLM data production, model evaluation, and embodied-intelligence training management.

This file is not limited to one media type. It groups together:

- official documentation
- platform solution pages
- developer communities
- industry media or公众号-type outlets

Use official or platform sources first when the user needs execution details. Use community and media sources to enrich trend language, examples, and industry framing.

## How to use

- For operational design or SOP work, prefer official documentation and platform solution pages.
- For industry scans, management trends, and example phrasing, add community and media sources.
- For embodied intelligence, prefer company, platform, or guide-type sources over general AI news outlets.

## A. Community and Media Sources

### 1. 量子位 QbitAI

- Link: https://www.qbitai.com/%E5%85%B3%E4%BA%8E%E6%88%91%E4%BB%AC
- Type: media or公众号 ecosystem
- Why it matters:
  useful for tracking AI industry trends, model launches, and具身智能热点. Strong for breadth and market framing, weaker than official docs for execution standards.

### 2. 机器之心

- Link: https://www.jiqizhixin.com/columns
- Type: AI media and technical commentary
- Why it matters:
  useful for model, data, evaluation, and robotics topic scans with stronger technical depth than general news outlets.

### 3. Datawhale

- Link: https://www.datawhale.cn/about
- Type: open learning community
- Why it matters:
  good for systematic learning, tutorials, and structured learning paths that can support training-manager education and internal enablement.

### 4. HyperAI 超神经

- Link: https://hub.baai.ac.cn/view/33865
- Type: AI community plus公众号 ecosystem
- Why it matters:
  useful for large-model ecosystem coverage, data infrastructure discussion, and curated reports. Strong as a bridge between technical and industry language.

### 5. 智源社区

- Link: https://hub.baai.ac.cn/
- Type: research and community platform
- Why it matters:
  useful for ecosystem tracking around evaluation, open models, tooling, and AI community resources. Good for method awareness and public reports.

## B. Official and Platform Sources for LLM Data and Annotation

### 6. 阿里云 PAI iTAG 概述

- Link: https://help.aliyun.com/zh/pai/itag
- Type: official documentation
- Why it matters:
  directly useful for understanding annotation workflow stages such as 标注, 检查, 验收 and how large-model data tasks are structured operationally.

### 7. 阿里云 多模态 RLHF 标注

- Link: https://help.aliyun.com/zh/pai/rlhf-based-annotation
- Type: official documentation
- Why it matters:
  useful for grounding RLHF-style operations in an actual task template, especially for multimodal or prompt-response production workflows.

### 8. 阿里云 标注模板总览

- Link: https://help.aliyun.com/zh/pai/templates-for-labeling/
- Type: official documentation
- Why it matters:
  shows task varieties such as 对话排序, 对话分组, 视觉问答, 多模态 RLHF, which helps convert abstract LLM-data talk into real operating task design.

### 9. 阿里云 视频打点模板

- Link: https://help.aliyun.com/zh/pai/video-marking-template
- Type: official documentation
- Why it matters:
  useful when AI training operations include video data or time-based content annotation instead of only text tasks.

### 10. 数据堂 大模型数据解决方案

- Link: https://www.datatang.com/largemodel
- Type: platform solution page
- Why it matters:
  useful for understanding one-stop views of data sourcing, tuning annotation, model evaluation, and operational packaging for LLM projects.

### 11. 数据堂 高质量数据集建设方案

- Link: https://datatang.com/news/1182
- Type: platform solution content
- Why it matters:
  useful for data governance framing: source intake, cleaning, labeling, evaluation, and acceptance as a complete operating chain.

### 12. 数据堂 教育高质量数据集案例

- Link: https://datatang.com/news/1188
- Type: platform case content
- Why it matters:
  useful for showing that domain LLM work needs multidimensional quality evaluation and sustained data-production capability, not just one-off collection.

### 13. BasicFinder RLHF 介绍

- Link: https://www.basicfinder.com/AboutUs/newsDetail/rlhf/
- Type: platform article
- Why it matters:
  useful for plain-language explanation of RLHF pipeline logic and the relationship between human feedback and language-model optimization.

### 14. BasicFinder RLHF 多轮对话标注工具

- Link: https://www.basicfinder.com/AboutUs/aboutUsList/rlhf-multiwheel/
- Type: platform tool introduction
- Why it matters:
  useful for understanding how RLHF and multi-turn dialogue work can be operationalized into concrete labeling tools and tasks.

### 15. BasicFinder AI 数据管理中台

- Link: https://www.basicfinder.com/model/
- Type: platform solution page
- Why it matters:
  useful for connecting RLHF, chain-of-thought construction, dialogue evaluation, multimodal annotation, and model fine-tuning into one data-operations picture.

## C. Embodied Intelligence and Robotics Sources

### 16. 智元机器人 具身智能文章

- Link: https://www.agibot.com/article/188/detail/7.html
- Type: company content
- Why it matters:
  useful for high-level framing of具身智能 learning architecture, especially real-plus-synthetic data and the role of training data in generalization.

### 17. 智元机器人 具身智能演进路线

- Link: https://jp.agibot.com/article/188/detail/32.html
- Type: company content
- Why it matters:
  useful for understanding staged evolution from reusable atomic skills toward more data-driven end-to-end systems, which matters for training-ops planning.

### 18. 智元机器人 RoboDual 技术解读

- Link: https://agibot.com/jp/article/188/detail/43.html
- Type: company content
- Why it matters:
  useful for scenario-generalization and training-efficiency framing when discussing robot-training capability development and data needs.

### 19. 京东云 具身数据工厂

- Link: https://robotdata.jdcloud.com/data-factory
- Type: platform solution page
- Why it matters:
  useful for data-pipeline thinking across collection, cleaning, labeling, quality inspection, and training for embodied or robot-oriented systems.

### 20. Embodied AI Guide

- Link: https://github.com/tianxingchen/Embodied-AI-Guide
- Type: curated open guide
- Why it matters:
  useful as a structured orientation source for embodied-AI tasks, papers, datasets, and subdomains when building a broader knowledge map.

## Fast Routing

If the user asks about:

- AI标注交付、抽检、返工、规则版本:
  start from entries 6, 10, 11, 15
- RLHF、SFT、多轮对话、偏好数据:
  start from entries 7, 8, 13, 14, 15
- 模型评测、质量评审、数据治理:
  start from entries 10, 11, 12, 15
- 具身智能、机器人训练、轨迹与场景覆盖:
  start from entries 16, 17, 18, 19, 20
- 行业趋势、公众号追踪、社区学习:
  start from entries 1, 2, 3, 4, 5
