# High-Frequency BPO Problem Routes

Use this file only when a short or vague request matches one of the ten lanes below. Use the lane's primary method first; add the scenario or sample file only when the output requires it.

## Common Answer Contract

For every lane, provide:

1. management judgment
2. cause split
3. immediate and structural actions
4. owner and operating rhythm
5. KPI or verification signal
6. one warning against the most likely management mistake

Do not load a broad full-text index for routine questions.

## 1. Floor and Team-Lead Management

- Typical asks: 现场乱、主管救火、班组长只盯指标、执行反复
- Primary method: [methods-teamlead.md](methods-teamlead.md)
- Add only for a formal plan: [operations.md](operations.md)
- First judgment: distinguish routine failure, ownership ambiguity, coaching weakness, and cross-role closure failure
- Must hit: pre-shift, intraday, end-of-day, repeated-problem review, named owner
- Avoid: attributing weak execution to attitude alone

## 2. KPI and Business Review

- Typical asks: 经营会变成报数会、指标波动看不懂、行动不闭环
- Primary method: [methods-metrics.md](methods-metrics.md)
- Add for metric definitions: [metrics-dictionary.md](metrics-dictionary.md)
- First judgment: distinguish result reporting from variance interpretation and decision closure
- Must hit: change, cause, structural versus temporary, action, owner, next checkpoint
- Avoid: presenting a long KPI list without a decision

## 3. WFM, Scheduling, and Service Level

- Typical asks: 人不少但高峰扛不住、排班够但实际缺口、服务水平下降
- Primary method: [methods-wfm.md](methods-wfm.md)
- Add for a formal staffing plan: [operations.md](operations.md)
- First judgment: separate total capacity, interval fit, shrinkage, adherence, skill mix, and real-time management
- Must hit: forecast-versus-actual, scheduled-versus-logged-in, effective online capacity, trial period
- Avoid: recommending headcount increase before locating the interval loss

## 4. QA, Calibration, and Quality Closure

- Typical asks: 质检下降、评分不一致、错误反复、评分卡太复杂
- Primary method: [methods-quality.md](methods-quality.md)
- Add for coaching design: [methods-training.md](methods-training.md)
- First judgment: separate standard, scorer, process, knowledge, system, and agent causes
- Must hit: calibration, defect taxonomy, owner, recheck, recurrence indicator
- Avoid: turning every quality issue into retraining

## 5. Training and Coaching

- Typical asks: 培训做了没效果、主管不会辅导、新人上线不稳
- Primary method: [methods-training.md](methods-training.md)
- Add for QA-triggered coaching: [methods-quality.md](methods-quality.md)
- First judgment: distinguish knowing, applying, receiving feedback, and sustaining behavior
- Must hit: target behavior, practice, floor follow-up, recheck, result signal
- Avoid: measuring training by attendance or satisfaction alone

## 6. Attrition, Emotion, and Stability

- Typical asks: 流失高、士气差、新人留不住、情绪事件增多
- Primary method: [methods-retention.md](methods-retention.md)
- Add when emotion or burnout is central: [methods-emotion.md](methods-emotion.md)
- First judgment: separate healthy movement, preventable loss, early-tenure loss, and key-talent loss
- Must hit: risk segments, 30/60/90-day checkpoints, owner split, warning roster
- Avoid: treating attrition as only pay, HR, or employee attitude

## 7. Complaints and Escalation

- Typical asks: 投诉上涨、升级集中、同类客诉反复、现场敏感事件
- Primary method: [methods-complaints.md](methods-complaints.md)
- Add for an urgent event: [event.md](event.md)
- First judgment: separate immediate containment from repeated-defect governance
- Must hit: reason and stage classification, expectation boundary, closure ownership, repeat monitoring
- Avoid: solving the individual case without repairing the recurring cause

## 8. Knowledge and Rule Governance

- Typical asks: 知识库很多但一线仍问人、规则更新后理解不一、SOP失效
- Primary method: [methods-knowledge.md](methods-knowledge.md)
- Add for a formal improvement plan: [operations.md](operations.md)
- First judgment: separate findability, readability, trust, applicability, and version drift
- Must hit: frontline-demand map, lifecycle owner, scenario entry, usage-effect review
- Avoid: measuring knowledge maturity by article count or update frequency

## 9. AI Annotation Operations

- Typical asks: 返工高、准确率不稳、组间口径不一、产量与质量冲突
- Primary method: [methods-ai-annotation.md](methods-ai-annotation.md)
- Add for direct reporting wording: [sample-library-ai-annotation-cn.md](sample-library-ai-annotation-cn.md)
- First judgment: separate guideline, task design, annotator, reviewer, tool, and productivity-pressure causes
- Must hit: calibration, gold samples, arbitration, batch gate, rework reason dashboard
- Avoid: blaming annotators before checking rule and reviewer consistency

## 10. Model Evaluation Operations

- Typical asks: benchmark好但场景不稳、人审分歧、回归问题、发布阻断
- Primary method: [methods-model-eval.md](methods-model-eval.md)
- Add for AI-training source depth: [ai-training-index.md](ai-training-index.md)
- First judgment: separate benchmark capability, scenario reliability, reviewer consistency, safety, and regression risk
- Must hit: scenario evaluation, calibration, arbitration, severity, release gate, owner
- Avoid: treating an aggregate score as a release decision

## Route Escalation

Use [customer-world-problem-solving-map.md](customer-world-problem-solving-map.md) only when the problem crosses several lanes or the primary method lacks enough solution logic.

Search [external-ops-fulltext-index.md](external-ops-fulltext-index.md) only when benchmark evidence, external practice, or an uncommon detail is required. Read the selected article before using its claim.
