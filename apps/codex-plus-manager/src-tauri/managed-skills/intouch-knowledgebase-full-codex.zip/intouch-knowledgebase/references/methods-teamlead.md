# Team-Lead and Floor-Management Method

Use for team-lead capability, floor control, repeated firefighting, daily execution, exception handling, and KPI translation.

## Management Judgment

Treat the team lead as the translation layer between management intent and frontline behavior. When the floor stays chaotic despite visible effort, first judge whether the gap is routine, ownership, coaching, escalation, or closure—not attitude alone.

## Cause Structure

Classify the primary drag:

- routine: pre-shift, intraday, and end-of-day controls are missing or ceremonial
- ownership: repeated issues have no named owner or deadline
- capability: the lead reads results but cannot diagnose or coach behavior
- floor control: queue pressure, long cases, emotional risk, or schedule drift is detected too late
- coordination: QA, training, WFM, and operations work as separate queues
- closure: exceptions are handled once but not reviewed for recurrence
- role drift: administration, reporting, or firefighting displaces coaching, observation, and preventive floor control
- decision drift: unclear authority or fear of making the wrong call causes delay, hidden uncertainty, over-escalation, or rigid use of a flawed approach

## Action Mechanism

Build five linked routines:

1. pre-shift: state the day's risk, priority scenario, and expected behavior
2. intraday: monitor service pressure, attendance, abnormal states, long cases, and emotional signals
3. same-day correction: assign the issue, corrective action, and verification point
4. coaching: use one real case, one target behavior, and one follow-up check
5. weekly closure: review repeated problems, overdue actions, and cross-role dependencies

Protect a role-time portfolio for floor control, coaching, exception handling, analysis, and administration. Review drift when urgent work repeatedly consumes planned management time.

Define decision boundaries, escalation triggers, and a safe route for supervisors to ask for clarity. Inspect team-to-team variance as a possible supervisor-system signal before blaming individual style.

Stage team-lead capability:

- level 1: read indicators and execute routines
- level 2: diagnose exceptions and coach behavior
- level 3: manage team atmosphere and people risk
- level 4: close repeated problems across QA, training, WFM, and process owners

## Ownership

- team lead: daily control, first response, coaching, and action updates
- supervisor: routine quality, exception prioritization, and overdue closure
- OM: cross-team mechanism, resource conflict, and structural escalation
- QA/training/WFM/process owners: close domain-specific causes rather than returning them to the team lead

## Rhythm

- pre-shift: priority and risk briefing
- intraday: threshold-based intervention, not dashboard watching alone
- end of day: unresolved exception and owner check
- weekly: repeated-problem and team-lead capability review
- monthly: routine effectiveness and cross-role mechanism review

## Metrics and Signals

Use only relevant signals:

- action closure and overdue rate
- repeated-issue recurrence
- coaching completion and post-coaching recurrence
- planned versus actual supervisor time by management activity
- unresolved exception age and repeated firefighting share
- adherence, abnormal-state duration, and high-risk case response time
- team-level KPI variance and team-lead routine completion quality
- attrition, absenteeism, or complaint concentration by team

## Anti-Patterns

Avoid:

- passing target pressure downward without translating it into behavior
- managing only from dashboards
- rewarding visible busyness while coaching, observation, and preventive control disappear
- treating every team lead as the same capability level
- using meetings instead of owner-and-deadline closure
- asking the lead to solve process, system, or policy defects alone

## Output Contract

Provide the judgment, missing routine or capability, immediate correction, structural mechanism, owner, rhythm, and verification signal.
