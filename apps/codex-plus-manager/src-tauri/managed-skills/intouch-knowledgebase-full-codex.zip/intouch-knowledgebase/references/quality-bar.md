# Quality Bar

Use this reference as the final internal check before answering any BPO business question.

The goal is not to sound formal. The goal is to produce output that a project owner, OM, bid lead, or client manager could reuse with minimal editing.

## Output Acceptance Checklist

The answer is not ready unless most of the following are true:

1. starts with a conclusion, judgment, or recommended route
2. matches the user's likely scenario and business line
3. uses KPI, cause, action, and follow-up as a closed loop rather than isolated bullets
4. separates internal management wording from client-facing wording when that difference matters
5. gives at least one concrete action with owner, timing, or review point
6. avoids vague phrases that have no execution meaning
7. can be pasted into Word, PPT, or an internal memo without heavy rewriting

## Mandatory Fields By Output Type

### Reporting

Must include:

- overall conclusion
- KPI block or KPI table
- issue and cause
- corrective action
- next-stage focus

If there is metric underperformance, include:

- the gap
- the main driver
- the mitigation already started
- the next review checkpoint

### Operations / Management Plan

Must include:

- management objective
- current-state diagnosis
- action split by people, process, and mechanism where relevant
- owner and timing
- tracking rhythm

### Tender / Proposal

Must include:

- client perspective or project understanding
- delivery mechanism
- staffing or resource guarantee
- measurable KPI or SLA commitment
- risk response

### Event / Incident

Must include:

- immediate control action
- fact clarification path
- reporting or escalation path
- recovery action
- follow-up owner

## Empty Phrase Filter

Rewrite or delete lines that only say:

- strengthen management
- continue to optimize
- focus on improvement
- ensure implementation
- follow up closely
- improve efficiency

These phrases are acceptable only when followed by a concrete action, owner, and timing.

## Cause Analysis Rule

Do not describe a problem without classifying the likely cause.

Use one or more of these cause buckets:

- business fluctuation
- staffing mismatch
- capability gap
- process defect
- tool or system issue
- policy or upstream dependency

## Wording Calibration

### Internal wording

Prefer direct management language:

- the main drag on service level came from evening peak understaffing
- repeat contacts are concentrated in billing clarification and transfer scenarios
- current coaching is fixing symptoms faster than root causes

### Client-facing wording

Prefer accountable but calm language:

- service level pressure was mainly driven by concentrated evening traffic and temporary seat gap
- corrective actions have been launched around peak-hour coverage, escalation reduction, and scenario coaching
- current trend is controllable, and the next review point is set for next Monday

## Default Table Patterns

### KPI table

| KPI | Target | Actual | Gap | Trend | Main reason | Action |
| --- | --- | --- | --- | --- | --- | --- |

### Action table

| Topic | Action | Owner | Timing | Review point |
| --- | --- | --- | --- | --- |

## Final Self-Check Prompt

Before sending, silently ask:

"If this were pasted into a manager's weekly deck or sent to a client today, would it read like a real operating judgment with actions and ownership, or like a smart summary with no execution anchor?"
