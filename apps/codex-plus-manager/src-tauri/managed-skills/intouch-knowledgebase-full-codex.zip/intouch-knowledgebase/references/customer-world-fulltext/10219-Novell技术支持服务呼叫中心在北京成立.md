# Novell技术支持服务呼叫中心在北京成立

- source: Customer World
- url: http://www.ccmw.net/cjyj/10219.html
- published_at: 2026-05-17
- category: cjyj
- stream_note: 场景研究
- notes: priority: P-method; reason: method-heavy full-text: cjyj

## Full Text

日前，Novell公司正式宣布在北京设立呼叫中心，以满足不断扩大的中国市场需求，为客户带来高效的远程技术支持服务。继深圳呼叫中心之后，北京呼叫中心是Novell公司在中国设立的第二个呼叫中心，目前主要为讲华语地区的用户提供对SUSE Linux Enterprise服务器及桌面产品的售后技术支持。中心目前有10余名员工，但预计在不久的将来新呼叫中心的员工规模将达到50名。

 “能够在北京建立起Novell在中国的第二个呼叫中心，我们感到非常高兴。”Novell公司东亚区总裁张先民博士表示：“目前，Novell SUSE Linux Enterprise产品以逐步受到用户的青睐，但同时也对我们的技术支持规模和效率提出更高要求。基于Novell北京拥有强大的技术支持实力，并靠近Novell的核心研发和技术团队，Novell公司在北京设立的新呼叫中心将为广大用户提供更高效、便捷的远程技术支持服务。”

 据悉，新呼叫中心的发展将分为三个阶段。第一阶段以Linux的技术支持为主，针对讲华语地区的用户提供SUSE Linux Enterprise服务器及桌面产品的技术支持，目前该呼叫中心仍处于此阶段；第二阶段将引入对其他主流产品，如ZENworks及身份认证产品的支持，该阶段将于2008年启动；第三阶段是为整个东亚地区，及全球的一些Linux用户提供技术支持，此阶段计划于2008年底启动。三个阶段都将在2008年得以实现。
