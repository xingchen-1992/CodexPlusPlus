# 戴尔将采用Google+平台实现网上客服

- source: Customer World
- url: http://www.ccmw.net/cjyj/10351.html
- published_at: 2026-05-17
- category: cjyj
- stream_note: 场景研究
- notes: priority: P-method; reason: method-heavy full-text: cjyj

## Full Text

作为传统客户服务呼叫中心的替代品，戴尔可能很快就会采用Google+当中的的新视频聊天平台来搭建自己的客户服务，公司董事长兼首席执行官迈克尔·戴尔最近表示。戴尔是Google+首批进驻的企业客户，戴尔表示，视频服务可以带来更人性化的技术支持，并可加深与客户间的信任，同时也比传统的呼叫中心更为经济。

 不过戴尔目前最大的问题是Google+采用邀请制，很少会有客户有机会参与他们的网上视频客服中心。

 目前有很多不同类型的企业积极参加了Google+企业用户的申请，这其中有小企业、个人承包商还有世界级大品牌。比如福特汽车表现非常积极，尽管他们已经在Facebook上拥有企业账户，但是更希望能够在谷歌上与广大用户进行交流。
