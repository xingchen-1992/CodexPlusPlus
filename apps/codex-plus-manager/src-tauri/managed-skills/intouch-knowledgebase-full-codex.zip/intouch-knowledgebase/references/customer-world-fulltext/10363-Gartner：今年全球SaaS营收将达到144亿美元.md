# Gartner：今年全球SaaS营收将达到144亿美元

- source: Customer World
- url: http://www.ccmw.net/cjyj/10363.html
- published_at: 2026-05-17
- category: cjyj
- stream_note: 场景研究
- notes: priority: P-method; reason: method-heavy full-text: cjyj

## Full Text

3月29日消息，全球技术研究和咨询公司Gartner发布最新报告指出，今年全球SaaS（软件即服务）营收将达到144亿美元，比2011年的123亿美元增长17.9%。预计到2015年，全球SaaS营收将达到221亿美元。

 Gartner表示，SaaS主要是指企业资源计划（简称“ERP”）和客户关系管理（简称“CRM”）等软件的服务及管理方法。目前全球主要的ERP、CRM提供商包括甲骨文、SAP、微软、Salesforce等。

 Gartner研究主管沙龙·梅茨（Sharon Mertz）表示，由于企业越来越重视ERP、CRM等软件的服务及管理方法，SaaS的普及率也不断上升。梅茨说：“企业越来越重视ERP、CRM等软件的服务及管理方法，平台即服务（PaaS)开发者社区的发展，以及云计算的兴起让SaaS在过去10年中保持了高速增长。”

 Gartner预计，今年北美市场SaaS软件营收将达到91亿美元，比去年同期的78亿美元增长16.67%；西欧市场SaaS软件营收将达到32亿美元，比去年同期的27亿美元增长18.52%；东欧市场的SaaS软件营收将达到1.694亿美元，比去年同期的1.355亿美元增长25.02%。

 Gartner表示，SaaS软件营收在亚太地区和拉美市场同样保持高速增长。Gartner预计，今年亚太地区SaaS软件营收将达到9.341亿美元，比去年同期的7.309亿美元增长27.80%。其中日本市场SaaS软件营收为4.952亿美元，占整个亚太地区SaaS软件总营收的53.01%，去年日本市场SaaS软件营收为4.27亿美元。今年拉美市场SaaS软件营收预计为4.197亿美元，高于去年同期的3.311亿美元。
