# Operations Examples

Use these examples to calibrate practical management outputs.

Do not imitate the exact scenario only. Reuse the way the answer turns a vague problem into a manager-ready plan.

## Example 1: Low-Performance Team Diagnosis

### Management judgment

The current underperformance is mainly a capability-and-routine problem, not a simple effort problem. Team attendance is acceptable, but conversion remains unstable because script execution, objection handling, and supervisor review rhythm are not yet functioning as a closed loop.

### Current-state diagnosis

1. Conversion fluctuates sharply by team and day, which suggests unstable execution rather than pure market change.
2. Connect rate is within a reasonable range, so the largest gap is happening after agents enter the conversation.
3. Supervisor coaching currently focuses on result review, but not enough on call-level breakdown and repeat correction.

### KPI view

| KPI | Current state | Signal | Management meaning |
| --- | --- | --- | --- |
| Connect rate | Near target | Stable | Lead reachability is not the core problem |
| Conversion rate | Below target | Unstable | Script and objection handling are inconsistent |
| QA pass rate | Moderate | Flat | Basic compliance is present but selling rhythm is weak |
| Output per seat | Below target | Down | Process and coaching are limiting productivity |

### Root-cause split

- People: some agents do not control the objection-handling path well enough
- Process: callback discipline and lead follow-up rhythm are inconsistent
- Mechanism: supervisor review is not tied tightly enough to daily performance movement

### Action plan

| Topic | Action | Owner | Timing | Success signal |
| --- | --- | --- | --- | --- |
| Script consistency | Extract top-performer opening and objection script into a short standard version | Training lead | 2 days | Script variance narrows in call reviews |
| Supervisor routine | Add a daily 30-minute call review focused on 3 failed-conversion cases per team | Operations manager | Start tomorrow | Daily action log is completed |
| Callback discipline | Publish callback closure rule and track same-day completion | Team leaders | 3 days | Callback completion exceeds 95% |
| Bottom performers | Run one-on-one coaching for the lowest 20 percent of agents | Supervisors | Within 1 week | Conversion gap narrows by next review |

### Review rhythm

- daily: bottom KPI movement and failed-conversion review
- twice weekly: supervisor coaching quality check
- weekly: conversion and output-per-seat recovery review

## Example 2: Shift Optimization Proposal for Inbound Voice

### Management judgment

Current roster design does not match the real traffic curve. The service-level issue is structural at the scheduling layer, so temporary floor rescue can only relieve pressure, not solve it.

### Current-state diagnosis

1. Morning coverage is relatively sufficient, but the 18:00-21:00 band shows repeated queue pressure.
2. Break windows are concentrated in the same period, which enlarges the effective seat gap during peak traffic.
3. Overtime support is being used as a recovery tool too often, which is not sustainable.

### KPI view

| KPI | Current state | Signal | Management meaning |
| --- | --- | --- | --- |
| Service level | Below target in late band | Repeated drop | Roster mismatch is persistent |
| Abandon rate | Elevated in peak band | Up | Queue wait exceeds tolerance at certain hours |
| Attendance | Acceptable | Stable | Issue is not mainly no-show related |
| Overtime hours | High | Up | Temporary compensation is replacing design fix |

### Action plan

1. Shift two existing mid-shift seats into the 18:00-21:00 band for a 2-week trial.
2. Rebuild break windows so that no more than 12 percent of available seats are off-line in the same 30-minute interval.
3. Keep overtime as a backup only, not as a planned daily recovery mechanism.
4. Review intraday queue data after 3 and 10 days, then confirm whether the revised roster should be formalized.

### Owner and timeline

- WFM lead: roster redesign by Thursday
- Operations lead: floor validation during first 3 trial days
- Project owner: trial review at the end of week 2

### Review rhythm

- daily review of 18:00-21:00 service level and abandon rate
- weekly summary of roster effectiveness and overtime dependency
