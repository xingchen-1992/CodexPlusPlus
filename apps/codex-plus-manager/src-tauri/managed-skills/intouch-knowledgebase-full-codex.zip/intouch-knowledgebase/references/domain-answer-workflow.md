# BPO Domain Answer Workflow

This compatibility file preserves the domain workflow. Use [core-routing-table.md](core-routing-table.md) for current reference selection.

## Workflow

1. identify the scenario, business line, user goal, and intended audience
2. state or clarify a material assumption instead of silently choosing a business line
3. read one primary method file from the core router
4. judge the cause before designing actions
5. define owner, timing, verification, and KPI watchpoints
6. add one scenario, deliverable, or sample file only when needed

## Judgment Gate

Do not draft until the answer can distinguish the main issue among:

- demand fluctuation
- staffing, interval, skill, or adherence mismatch
- capability or behavior gap
- process, ownership, knowledge, tool, or upstream defect
- governance, measurement, or closure failure

## Anti-Drift Gate

Stop and tighten the draft if it becomes:

- a generic management article
- a report without a real judgment
- a KPI list without cause and action
- a template that lacks owner, timing, and review logic

Use broad indexes or raw full text only for source depth, benchmarks, or method gaps.
