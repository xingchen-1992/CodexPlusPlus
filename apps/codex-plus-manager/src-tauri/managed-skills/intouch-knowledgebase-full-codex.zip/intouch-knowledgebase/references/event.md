# Event Playbook

Use this reference for urgent incidents, on-site conflict, complaint escalation, staffing emergencies, and recovery planning.

## Standard Structure

1. immediate handling
2. stabilize the scene
3. separate facts from emotion
4. investigate and judge impact
5. internal escalation or reporting
6. corrective action
7. atmosphere repair and follow-up

## Handling Principles

- protect people first
- stop escalation first
- confirm facts before assigning blame
- keep wording calm, short, and controllable
- give a next step and owner before ending the response

## Typical User Requests

- 现场员工冲突怎么处理
- 甲方突然投诉怎么应对
- 业务量爆了人不够怎么办
- 这类突发情况怎么写报告
