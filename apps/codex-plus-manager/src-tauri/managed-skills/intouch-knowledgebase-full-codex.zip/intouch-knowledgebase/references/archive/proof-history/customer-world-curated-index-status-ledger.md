# Customer World Curated Index Status Ledger

Use this file as the first row-level status ledger for the curated 224-entry Customer World article index.

This ledger is heuristic, not final.
It currently uses the following logic:

- `direct_seed_match`: exact URL match found in `customer-world-master-seed.csv`
- `title_level_overlap_likely`: exact URL not found, but the same title appears in the master seed
- `legacy_curated_only`: neither exact URL nor exact title was found in the current master seed

## Current Status Counts

- `direct_seed_match`: `67`
- `title_level_overlap_likely`: `64`
- `legacy_curated_only`: `93`

## Duplicate-Title Note

This ledger also shows a strong duplicate-title pattern inside the curated index:

- duplicate-title groups: `34`
- rows involved in duplicate-title groups: `75`

Practical meaning:

1. some curated entries are repeated across legacy paths and newer category paths
2. completion proof cannot treat each repeated title as wholly new learning value
3. later human review should prioritize whether duplicates add distinct context or only path variation

## Working Note

This ledger is already more rigorous than theme-only coverage, but it is still not the final proof layer.

The most important future upgrade will be:

1. manually reviewing `title_level_overlap_likely`
2. confirming whether some `legacy_curated_only` entries are truly outside the current broad seed harvest or merely hidden behind title/path variation
3. adding a final human-reviewed status after heuristic classification

## Ledger TSV

```tsv
index_no	title	path_family	curated_status	url
1	TCL移动呼叫中心质量管理的五方面工作	article	legacy_curated_only	https://www.ccmw.net/article/10962.html
2	意见领袖：呼叫中心的质量管理	article	legacy_curated_only	https://www.ccmw.net/article/851.html
3	呼叫中心质量管理的目标与方法	article	title_level_overlap_likely	https://www.ccmw.net/article/1051.html
4	如何打造科学化的呼叫中心质量管理体系（下）	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/15804.html
5	呼叫中心质量管理— 从TQM到六西格玛	cjyj	legacy_curated_only	https://www.ccmw.net/cjyj/19952.html
6	热线平均处理时长的质量管理探讨	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=6927
7	关于客服中心培训转变的一些思考	article	legacy_curated_only	https://www.ccmw.net/article/123837.html
8	呼叫中心的培训管理	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=8758
9	雏鹰成长记——浅谈呼叫中心新员工培训管理	2016n12yk	legacy_curated_only	https://www.ccmw.net/2016n12yk/8031.html
10	注重员工培训打造一流呼叫中心运营团队	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=8609
11	如何评估培训的效果	2010n08yk	legacy_curated_only	https://www.ccmw.net/2010n08yk/9212.html
12	破解呼叫中心“用人慌”的思考	article	legacy_curated_only	https://www.ccmw.net/article/87243.html
13	如何降低外包员工流失	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=9245
14	呼叫中心招募留体系搭建及培训管理	hyxx	legacy_curated_only	https://www.ccmw.net/hyxx/10995.html
15	数据管理——呼叫中心运营管理的灵魂	hyhz	title_level_overlap_likely	https://www.ccmw.net/hyhz/14632.html
16	最小方差管理法在呼叫中心指标管理中的应用	2013n7yk	legacy_curated_only	https://www.ccmw.net/2013n7yk/8484.html
17	主要表现指针(KPI)在呼叫中心服务及效益管理中的应用	indexphp	title_level_overlap_likely	https://www.ccmw.net/index.php?c=show&id=15814
18	分级分类灵活进行指标调控	hyyw	legacy_curated_only	https://www.ccmw.net/hyyw/17488.html
19	呼叫中心- 理性管理	2013n4yk	legacy_curated_only	https://www.ccmw.net/2013n4yk/8422.html
20	客户服务高绩效管理体系对创建一流呼叫中心的启示	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/17790.html
21	可创造“奇迹”的呼叫中心排班管理	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=9977
22	呼叫中心的话量预测及人员排班	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/16057.html
23	呼叫中心排班前期分析	2008n12yk	legacy_curated_only	https://www.ccmw.net/2008n12yk/9748.html
24	利用“四率”，轻松做好呼叫中心现场管理	2008n02-03yhk	legacy_curated_only	https://www.ccmw.net/2008n02-03yhk/9562.html
25	人力不足，如何确定可达成目标	2006n07yk	legacy_curated_only	https://www.ccmw.net/2006n07yk/10069.html
26	呼叫中心运营管理的15个基本要素（下）	huiyuanxinxi	title_level_overlap_likely	https://www.ccmw.net/huiyuanxinxi/10922.html
27	呼叫中心，班组长的团队士气管理	huiyuanxinxi	legacy_curated_only	https://www.ccmw.net/huiyuanxinxi/13018.html
28	大型呼叫中心班组长该如何管理	2008n06yk	legacy_curated_only	https://www.ccmw.net/2008n06yk/9634.html
29	呼叫中心基层管理人员的日常管理	article	legacy_curated_only	https://www.ccmw.net/article/9636.html
30	呼叫中心班组长管理经验的总结和推广	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=8453
31	心理咨询技术在班组长管理沟通中的应用	2013n11yk	legacy_curated_only	https://www.ccmw.net/2013n11yk/8569.html
32	从投诉中找出绩效——浅谈客服中心投诉管理	article	legacy_curated_only	https://www.ccmw.net/article/116540.html
33	做一名优秀的救火员——如何处理升级投诉	article	title_level_overlap_likely	https://www.ccmw.net/article/16003.html
34	简析从投诉管理迈向投诉经营	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/15978.html
35	呼叫中心- 客户期望值管理	article	legacy_curated_only	https://www.ccmw.net/article/9337.html
36	服务数字化转型（六）如何正确认识和管理服务满意度	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=6963
37	围绕“六字”做好呼叫中心日常工作	article	legacy_curated_only	https://www.ccmw.net/article/7733.html
38	呼叫中心管理与客户期望和客户体验	ksyc	title_level_overlap_likely	https://www.ccmw.net/ksyc/18785.html
39	卓越的呼叫中心运营管理艺术与技巧	hyxx	title_level_overlap_likely	https://www.ccmw.net/hyxx/10980.html
40	呼叫中心变革管理实施案例	2013n11yk	legacy_curated_only	https://www.ccmw.net/2013n11yk/8583.html
41	TRS呼叫中心知识管理系统解决方案	article	legacy_curated_only	https://www.ccmw.net/article/15699.html
42	卓越的呼叫中心运营管理艺术与技巧	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/16056.html
43	呼叫中心运营管理系统Teleweb-OMS综述	hyxx	title_level_overlap_likely	https://www.ccmw.net/hyxx/10963.html
44	客服域人工智能训练师培训大纲	indexphp	title_level_overlap_likely	https://www.ccmw.net/index.php?c=show&id=10539
45	浅议呼叫中心，客服中心的管理创新	hyxx	title_level_overlap_likely	https://www.ccmw.net/hyxx/13017.html
46	社会化媒体时代呼叫中心的运营管理智慧	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=18889
47	居家办公和平台众包：服务外包运营创新经营模式探析	article	legacy_curated_only	https://www.ccmw.net/article/185498.html
48	客户服务高绩效管理体系对创建一流呼叫中心的启示	article	title_level_overlap_likely	https://www.ccmw.net/article/65146.html
49	立足中国，定位亚太，接轨世界	2008n07yk	legacy_curated_only	https://www.ccmw.net/2008n07yk/9642.html
50	客户服务高绩效管理体系对创建一流呼叫中心的启示	indexphp	title_level_overlap_likely	https://www.ccmw.net/index.php?c=show&id=8676
51	浅谈呼叫中心有效管理	article	title_level_overlap_likely	https://www.ccmw.net/article/16530.html
52	团队激励在呼叫中心的应用	article	legacy_curated_only	https://www.ccmw.net/article/65146.html
53	关于呼叫中心热线满意度提升的几点探索	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=8676
54	呼叫中心管理与客户期望和客户体验	ksyc	title_level_overlap_likely	https://www.ccmw.net/ksyc/18785.html
55	不可不知：呼叫中心管理的重大漏洞	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=9832
56	外包呼叫中心的核心优势	indexphp	title_level_overlap_likely	https://www.ccmw.net/index.php?c=show&id=16806
57	关注呼叫中心的“小群体”	2008n11yk	legacy_curated_only	https://www.ccmw.net/2008n11yk/9727.html
58	呼叫中心：从被动服务到主动营销	hyhz	title_level_overlap_likely	https://www.ccmw.net/hyhz/13324.html
59	一款用于呼叫中心质量管理的软件分析	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/15681.html
60	专家圆桌：客户体验管理	zjgd	title_level_overlap_likely	https://www.ccmw.net/zjgd/18578.html
61	浅谈客服中心的情绪管理	article	legacy_curated_only	https://www.ccmw.net/article/113909.html
62	呼叫中心员工情绪和压力管理四步法	hyxx	title_level_overlap_likely	https://www.ccmw.net/hyxx/11004.html
63	用心做“心”的工作	2010n08yk	legacy_curated_only	https://www.ccmw.net/2010n08yk/9206.html
64	呼叫中心员工现场情绪失控的处置技巧	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=8210
65	抓住缺勤率背后的手——浅析员工关怀之重	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=7931
66	用心聆听，用爱回应	2010n08yk	legacy_curated_only	https://www.ccmw.net/2010n08yk/9201.html
67	呼叫中心人员异动测算模型在HR管理中的应用	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=8539
68	抓好质量控制点提升服务有效性	2008n06yk	legacy_curated_only	https://www.ccmw.net/2008n06yk/9618.html
69	山西联通将建设24小时自助营业厅	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/20157.html
70	呼叫中心人力和通信成本的控制	2008n07yk	legacy_curated_only	https://www.ccmw.net/2008n07yk/9646.html
71	智能服务下，多渠道客服中心的运营之道	2017n8yk	legacy_curated_only	https://www.ccmw.net/2017n8yk/7688.html
72	关于多渠道客户中心服务优化管理的探索	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=7693
73	基于“互联网+”模式下的多媒体服务需求	2017n1-2yhk	legacy_curated_only	https://www.ccmw.net/2017n1-2yhk/7545.html
74	互联网+时代呼叫中心客服管理模式创新	article	legacy_curated_only	https://www.ccmw.net/article/126825.html
75	“互联网+服务”需要怎样的在线客服员工？	huiyuanxinxi	title_level_overlap_likely	https://www.ccmw.net/huiyuanxinxi/11011.html
76	在线客服效率提升的秘密	hyxx	title_level_overlap_likely	https://www.ccmw.net/hyxx/11146.html
77	呼叫中心：从被动服务到主动营销	hyhz	title_level_overlap_likely	https://www.ccmw.net/hyhz/13324.html
78	客户世界年会：关注客户互动新时代的营销服务	hyhd	legacy_curated_only	https://www.ccmw.net/hyhd/18824.html
79	服务外包振翅欲飞，明势企业因势而变	article	legacy_curated_only	https://www.ccmw.net/article/9848.html
80	知识采编业务落地步骤分解	article	title_level_overlap_likely	https://www.ccmw.net/article/12750.html
81	再谈呼叫中心管理的执行问题	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/16059.html
82	改善呼叫中心的质量管理	2008n06yk	legacy_curated_only	https://www.ccmw.net/2008n06yk/9626.html
83	关注细节，强化管控，快速提升服务水平	2013n8yk	legacy_curated_only	https://www.ccmw.net/2013n8yk/8515.html
84	呼叫中心基层管理者看运营	2013n4yk	legacy_curated_only	https://www.ccmw.net/2013n4yk/8420.html
85	呼叫中心内部的指导性沟通	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/16056.html
86	对外包呼叫中心平台建设的建议	cjyj	title_level_overlap_likely	https://www.ccmw.net/cjyj/20001.html
87	关于某保险行业续保续期业务数字运营方案	ksyc	title_level_overlap_likely	https://www.ccmw.net/ksyc/20260.html
88	服务的判断力：员工体验与客户体验如何联动	szyc	legacy_curated_only	https://www.ccmw.net/szyc/20253.html
89	客服域人工智能训练师培训大纲	indexphp	title_level_overlap_likely	https://www.ccmw.net/index.php?c=show&id=10539
90	不可不知：呼叫中心管理的重大漏洞	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=9832
91	客户世界年会：关注客户互动新时代的营销服务	hyhd	legacy_curated_only	https://www.ccmw.net/hyhd/18824.html
92	服务数字化转型（六）如何正确认识和管理服务满意度	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=6963
93	呼叫中心质量管理— 从TQM到六西格玛	cjyj	legacy_curated_only	https://www.ccmw.net/cjyj/19952.html
94	数据管理——呼叫中心运营管理的灵魂	hyhz	title_level_overlap_likely	https://www.ccmw.net/hyhz/14632.html
95	可创造“奇迹”的呼叫中心排班管理	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=9977
96	呼叫中心运营管理的15个基本要素（下）	huiyuanxinxi	title_level_overlap_likely	https://www.ccmw.net/huiyuanxinxi/10922.html
97	立足中国，定位亚太，接轨世界	2008n07yk	legacy_curated_only	https://www.ccmw.net/2008n07yk/9642.html
98	卓越的呼叫中心运营管理艺术与技巧	hyxx	title_level_overlap_likely	https://www.ccmw.net/hyxx/10980.html
99	客户服务高绩效管理体系对创建一流呼叫中心的启示	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/17790.html
100	一款用于呼叫中心质量管理的软件分析	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/15681.html
101	如何对呼叫中心的知识实施有效管理	indexphp	title_level_overlap_likely	https://www.ccmw.net/index.php?c=show&id=17846
102	质检：除了打分，还能干什么？	huiyuanxinxi	title_level_overlap_likely	https://www.ccmw.net/huiyuanxinxi/10999.html
103	打造优秀的“兵头将尾”	2008n02-03yhk	legacy_curated_only	https://www.ccmw.net/2008n02-03yhk/9565.html
104	全面质量管理：运营指标和客户体验的探戈	2007n07yk	legacy_curated_only	https://www.ccmw.net/2007n07yk/9861.html
105	呼叫中心实施人力资源优化软件后的管理变动	hyxx	legacy_curated_only	https://www.ccmw.net/hyxx/11204.html
106	中国移动江苏公司淮安呼叫中心在职培训体系心理解析	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/17760.html
107	呼叫中心运营管理的15个基本要素（上）	huiyuanxinxi	title_level_overlap_likely	https://www.ccmw.net/huiyuanxinxi/10921.html
108	再谈呼叫中心管理的执行问题	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/16059.html
109	呼叫中心基层管理者看运营	2013n4yk	legacy_curated_only	https://www.ccmw.net/2013n4yk/8420.html
110	呼叫中心内部的指导性沟通	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/16056.html
111	关注细节，强化管控，快速提升服务水平	2013n8yk	legacy_curated_only	https://www.ccmw.net/2013n8yk/8515.html
112	打造科学化的呼叫中心质量管理体系（下）	hyyw	legacy_curated_only	https://www.ccmw.net/hyyw/15804.html
113	关注呼叫中心的“小群体”	2008n11yk	legacy_curated_only	https://www.ccmw.net/2008n11yk/9727.html
114	心理咨询技术在班组长管理沟通中的应用	2013n11yk	legacy_curated_only	https://www.ccmw.net/2013n11yk/8569.html
115	人力不足，如何确定可达成目标	2006n07yk	legacy_curated_only	https://www.ccmw.net/2006n07yk/10069.html
116	围绕“六字”做好呼叫中心日常工作	article	legacy_curated_only	https://www.ccmw.net/article/7733.html
117	呼叫中心运营管理的15个基本要素（下）	huiyuanxinxi	title_level_overlap_likely	https://www.ccmw.net/huiyuanxinxi/10922.html
118	不可不知：呼叫中心管理的重大漏洞	2007n06yk	legacy_curated_only	https://www.ccmw.net/2007n06yk/9832.html
119	呼叫中心热线平均处理时长的质量管理探讨	2020n8yk	legacy_curated_only	https://www.ccmw.net/2020n8yk/6927.html
120	卓越的呼叫中心运营管理艺术与技巧	hyxx	title_level_overlap_likely	https://www.ccmw.net/hyxx/10980.html
121	标杆案例：政务服务3.0时代的热线品牌	huiyuanxinxi	title_level_overlap_likely	https://www.ccmw.net/huiyuanxinxi/13147.html
122	客户世界 新讲坛：政府与公共服务2020嘉宾介绍	article	legacy_curated_only	https://www.ccmw.net/article/15362.html
123	遗忘呼叫中心的时代	ksyc	title_level_overlap_likely	https://www.ccmw.net/ksyc/18724.html
124	社会化媒体时代呼叫中心的运营管理智慧	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=18889
125	《政务与公共服务热线运营与管理规范》团体标准发布	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/19389.html
126	抓住缺勤率背后的手——浅析员工关怀之重	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=7931
127	用心做“心”的工作	2010n08yk	legacy_curated_only	https://www.ccmw.net/2010n08yk/9206.html
128	呼叫中心员工情绪和压力管理四步法	hyxx	title_level_overlap_likely	https://www.ccmw.net/hyxx/11004.html
129	如何对呼叫中心的知识实施有效管理	indexphp	title_level_overlap_likely	https://www.ccmw.net/index.php?c=show&id=17846
130	服务的判断力：员工体验与客户体验如何联动	szyc	legacy_curated_only	https://www.ccmw.net/szyc/20253.html
131	对外包呼叫中心平台建设的建议	cjyj	title_level_overlap_likely	https://www.ccmw.net/cjyj/20001.html
132	环信大学最佳实践：如何帮助客服知识积累、提升效率、标准化服务！	hyxx	title_level_overlap_likely	https://www.ccmw.net/hyxx/13053.html
133	从体验流程到体验关系：服务组织的战略重构路径	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=20256
134	《全媒体客户中心管理》简介	article	legacy_curated_only	https://www.ccmw.net/article/5503.html
135	客户世界• 新讲坛：政府与公共服务2021嘉宾介绍	article	legacy_curated_only	https://www.ccmw.net/article/176791.html
136	服务数字化转型（六）如何正确认识和管理服务满意度	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=6963
137	“互联网+服务”需要怎样的在线客服员工？	huiyuanxinxi	title_level_overlap_likely	https://www.ccmw.net/huiyuanxinxi/11011.html
138	关于多渠道客户中心服务优化管理的探索	2017n8yk	legacy_curated_only	https://www.ccmw.net/2017n8yk/7693.html
139	佛山市政府12345热线荣获《客户世界》编辑推荐	huiyuanxinxi	legacy_curated_only	https://www.ccmw.net/huiyuanxinxi/13145.html
140	大数据| 服务外包| 呼叫中心标准	indexphp	legacy_curated_only	https://www.ccmw.net/index.php?c=show&id=19172
141	呼叫中心平台建设之预算篇	indexphp	title_level_overlap_likely	https://www.ccmw.net/index.php?c=show&id=17854
142	电子商务企业的呼叫中心该选择外包还是自建？	article	title_level_overlap_likely	https://www.ccmw.net/article/24308.html
143	上海12345市民服务热线荣获《客户世界》编辑推荐	cjyj	legacy_curated_only	https://www.ccmw.net/cjyj/10553.html
144	标杆案例：政务服务3.0时代的热线品牌	huiyuanxinxi	title_level_overlap_likely	https://www.ccmw.net/huiyuanxinxi/13147.html
145	标杆案例：精细化运营完善互通渠道	huiyuanxinxi	legacy_curated_only	https://www.ccmw.net/huiyuanxinxi/13150.html
146	《客户世界》2021年度编辑推荐：服务数字化最佳案例（金融行业）	hyyw	title_level_overlap_likely	https://www.ccmw.net/hyyw/18314.html
147	华为公司12345政府热线系统解决方案	hyxx	title_level_overlap_likely	https://www.ccmw.net/hyxx/12263.html
148	山东省人民政府办公厅关于印发山东省12345政务服务便民热线管理办法	cjyj	legacy_curated_only	https://www.ccmw.net/cjyj/10586.html
149	数字人才培养工程简介	hyxx	title_level_overlap_likely	https://www.ccmw.net/hyxx/10598.html
150	DO-CMM数字化运营能力成熟度模型（2024版）正式发布	hangyeyaowen	legacy_curated_only	https://www.ccmw.net/hangyeyaowen/18516.html
151	因为AI，CX团队的角色正在发生哪些变化？	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/20268.html
152	数字运营能力构建——如何将AI融入业务	ksyc	direct_seed_match	http://www.ccmw.net/ksyc/20275.html
153	人工智能，重构客服生产方式	ksyc	direct_seed_match	http://www.ccmw.net/ksyc/20274.html
154	客服中心 AI 排班系统的预测与调度优化机制分析及用AI排班智能调度背后的黑科技！	ksyc	direct_seed_match	http://www.ccmw.net/ksyc/20276.html
155	企业管理的是“数字员工”还是“智能体”？——辨析企业AI治理中的关键语义差异	szyc	direct_seed_match	http://www.ccmw.net/szyc/20272.html
156	《2025-2026年中国客户中心产业发展报告》正式发布	hyxx	direct_seed_match	http://www.ccmw.net/hyxx/18561.html
157	正德人力通过《呼叫中心服务质量和运营管理规范》标准认证	xyywtj	legacy_curated_only	http://www.ccmw.net/xyywtj/5588.html
158	《政务服务统一咨询服务工作规范》国标认证介绍	zjgd	legacy_curated_only	http://www.ccmw.net/zjgd/5474.html
159	CallCenter绩效数据的三类指标	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/17786.html
160	客户智能技术让呼叫中心业务走向智能化	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/17814.html
161	企业实施统一通信(UC)最佳五步骤	hyxx	direct_seed_match	http://www.ccmw.net/hyxx/12175.html
162	什么是客户智能 如何取得这种智能？	zjgd	direct_seed_match	http://www.ccmw.net/zjgd/18598.html
163	如何将商业智能(BI)与知识管理联系在一起?	zjgd	direct_seed_match	http://www.ccmw.net/zjgd/18596.html
164	呼叫中心平台建设之预算篇	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/17854.html
165	统一通信助推呼叫中心大升级	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/10242.html
166	从呼叫中心到客户联络中心的3大功能转变	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/10247.html
167	《人工智能训练师-初级》认证培训	hyhz	direct_seed_match	http://www.ccmw.net/hyhz/15374.html
168	《外包运营管理师-初/中级》认证培训	hyhz	direct_seed_match	http://www.ccmw.net/hyhz/15392.html
169	《全媒体运营师-初/中级》认证培训	hyhz	direct_seed_match	http://www.ccmw.net/hyhz/15378.html
170	金耳唛杯历届榜单	jrm	legacy_curated_only	http://www.ccmw.net/jrm/
171	负面的绩效面谈怎么做?	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/17655.html
172	呼叫中心标准化管理	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/17696.html
173	CRM与呼叫中心的融合趋势	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/17686.html
174	电话营销失败案例分析及应对策略	hyhz	direct_seed_match	http://www.ccmw.net/hyhz/15444.html
175	呼唤IVR设计的行业规范	hyxx	direct_seed_match	http://www.ccmw.net/hyxx/12046.html
176	一个商业银行的IVR的应用点滴	hyxx	direct_seed_match	http://www.ccmw.net/hyxx/12047.html
177	外包业务的甲乙双方应当成为真正的战略合作伙伴	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/17506.html
178	大中型呼叫中心的数字化管理	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/17512.html
179	“居家座席”促进疫情阻断、保障服务不断	hyxx	legacy_curated_only	http://www.ccmw.net/hyxx/15467.html
180	智能数据分析助力联络中心数智化运营	hyxx	title_level_overlap_likely	http://www.ccmw.net/hyxx/15500.html
181	客户服务中心的环境心理学建议	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/17500.html
182	大中型呼叫中心管理的三个要点	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/17519.html
183	质检：除了打分，还能干什么？	hyxx	title_level_overlap_likely	http://www.ccmw.net/hyxx/15517.html
184	智能化趋势下呼叫中心人员胜任力转型探索	hyxx	title_level_overlap_likely	http://www.ccmw.net/hyxx/15521.html
185	电话营销你应该做的准备	hyhz	title_level_overlap_likely	http://www.ccmw.net/hyhz/15486.html
186	别用电话吓跑客户——保险行业电话营销案例分析	hyhz	title_level_overlap_likely	http://www.ccmw.net/hyhz/15541.html
187	关注呼叫中心精益运营与管理能力提升	hyxx	direct_seed_match	http://www.ccmw.net/hyxx/10981.html
188	1分钟培训	hyxx	direct_seed_match	http://www.ccmw.net/hyxx/10916.html
189	绩效指标：一步迈错满盘皆输	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/16411.html
190	电话营销不仅要注重售前更要注重售后服务	hyhz	direct_seed_match	http://www.ccmw.net/hyhz/14025.html
191	呼叫中心内训体系的架构分析	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/15984.html
192	呼叫中心的执行体系建设	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/15988.html
193	自助服务也能提高ROI	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/15992.html
194	浅谈电话营销中心管理	hyhz	direct_seed_match	http://www.ccmw.net/hyhz/13580.html
195	滥用客户信息的"直复营销",请住手	hyhz	direct_seed_match	http://www.ccmw.net/hyhz/13575.html
196	呼叫中心对客户价值的追逐	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/15983.html
197	浅谈呼叫中心的规范化运营管理体系建设	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/16030.html
198	专业问答:如何开好质检会?	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/15461.html
199	呼叫中心质量管理的冲突与解决	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/15463.html
200	如何建立一个卓越的呼叫中心	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/15468.html
201	平衡计分卡(BSC) 不是只“卡”员工	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/15470.html
202	如何评估CRM系统的成熟度?	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/15587.html
203	业务外包：如何识别合适的提供商?	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/15592.html
204	电话保险市场亟待规范	hyhz	direct_seed_match	http://www.ccmw.net/hyhz/13227.html
205	刘耘专访：树品牌、立标杆，用心做好客服每件事	ftdh	direct_seed_match	http://www.ccmw.net/ftdh/5408.html
206	《CC-CMM客户中心能力成熟度模型》认证介绍	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/10621.html
207	用数据挖掘提升电信CRM能力	hyhz	direct_seed_match	http://www.ccmw.net/hyhz/13434.html
208	企业数据挖掘能力BI的价值	hyhz	direct_seed_match	http://www.ccmw.net/hyhz/13858.html
209	别让客户在数据仓库里迷失	hyhz	direct_seed_match	http://www.ccmw.net/hyhz/13776.html
210	国办：清理整合政务热线 实现“一号对外”	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/10451.html
211	以“好差评”优化政务服务	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/10461.html
212	《数字化转型成熟度模型与评估》国标认证介绍	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/10612.html
213	《政府热线服务规范》国标认证介绍	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/10620.html
214	数字人才培养工程	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/10606.html
215	专家圆桌：客户体验管理	zjgd	direct_seed_match	http://www.ccmw.net/zjgd/18578.html
216	呼叫中心知识管理需求问题及解决思路	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/16500.html
217	呼叫中心知识管理和咨询管理	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/16658.html
218	浅谈新浪网客服中心的知识库建设	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/16795.html
219	呼叫中心知识管理实战指南	hyyw	direct_seed_match	http://www.ccmw.net/hyyw/17111.html
220	来自服务的变革 细说方正新一代客户联络中心	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/10238.html
221	前川充留：业务流程外包将是发展趋势	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/19957.html
222	如何发展商务流程外包	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/19981.html
223	KPO（知识流程外包）：全球BPO的下一个前沿领域	cjyj	direct_seed_match	http://www.ccmw.net/cjyj/10694.html
224	你的联络中心该一体化吗？	hyxx	direct_seed_match	http://www.ccmw.net/hyxx/12259.html
```
