# Customer World Seed Disposition Ratio Model

Use this file as the first exclusive-disposition ratio model for the three largest seed clusters.

This model is not a final row-by-row human-reviewed ledger.
It is a title-based, ordered-classification layer that turns broad cluster evidence into auditable provisional ratios.

## Scope

Current ratio model covers:

- `hyyw` (`3441`)
- `hyxx` (`2408`)
- `hyhz` (`2264`)

Combined modeled rows: `8113`

## Classification Rule

Rows are assigned by ordered title matching into one exclusive label:

1. `public_service_governance`
2. `benchmark_ecosystem`
3. `outsourcing_platform`
4. `marketing_multichannel`
5. `platform_enablement`
6. `training_certification`
7. `method_dense_ops`
8. `low_increment_long_tail`
9. `residual_other`

Important meaning:

- this is a first-pass disposition model
- labels are exclusive because of ordering
- some rows in `residual_other` are still likely method-reinforcement rows that the current regex layer does not fully capture

## Ratio Model

### `hyyw` ratio view

| Label | Rows | Share |
| --- | ---: | ---: |
| `outsourcing_platform` | 989 | 28.7% |
| `residual_other` | 1277 | 37.1% |
| `platform_enablement` | 354 | 10.3% |
| `training_certification` | 208 | 6.0% |
| `benchmark_ecosystem` | 207 | 6.0% |
| `method_dense_ops` | 163 | 4.7% |
| `public_service_governance` | 150 | 4.4% |
| `marketing_multichannel` | 51 | 1.5% |
| `low_increment_long_tail` | 42 | 1.2% |

Current reading:

- `hyyw` is heavily shaped by outsourcing-platform archive plus a very large generic operational residue
- the residue is not necessarily unknown; sampled titles suggest many general management, service-brand, SLA, FCR, and quality-expression rows sit here

### `hyxx` ratio view

| Label | Rows | Share |
| --- | ---: | ---: |
| `residual_other` | 1256 | 52.2% |
| `platform_enablement` | 509 | 21.1% |
| `benchmark_ecosystem` | 217 | 9.0% |
| `public_service_governance` | 152 | 6.3% |
| `marketing_multichannel` | 80 | 3.3% |
| `low_increment_long_tail` | 77 | 3.2% |
| `method_dense_ops` | 66 | 2.7% |
| `training_certification` | 30 | 1.2% |
| `outsourcing_platform` | 21 | 0.9% |

Current reading:

- `hyxx` is the most institutionally mixed cluster
- a large platform/maturity block is explicit
- the large `residual_other` block is sampled as service-brand, capability, methodology, and benchmark-style content rather than random noise

### `hyhz` ratio view

| Label | Rows | Share |
| --- | ---: | ---: |
| `marketing_multichannel` | 1030 | 45.5% |
| `residual_other` | 793 | 35.0% |
| `platform_enablement` | 218 | 9.6% |
| `benchmark_ecosystem` | 161 | 7.1% |
| `method_dense_ops` | 19 | 0.8% |
| `outsourcing_platform` | 13 | 0.6% |
| `public_service_governance` | 13 | 0.6% |
| `training_certification` | 10 | 0.4% |
| `low_increment_long_tail` | 7 | 0.3% |

Current reading:

- `hyhz` is overwhelmingly a marketing/telesales/multichannel archive
- the `residual_other` block still appears to be largely generic sales, process, and service-commercial material, not an unexplained archive mass

## Residual-Other Interpretation

Current sampled `residual_other` examples include titles such as:

- 如何建立一个卓越的呼叫中心
- 认识标杆管理
- 浅谈噪音在呼叫中心中的危害性
- 呼叫中心运营管理的15个基本要素（上）
- 服务品牌是怎样“炼”成的
- Outbound项目的成本控制管理
- 了解电话销售的技巧

Practical meaning:

- `residual_other` should not be read as "unknown"
- it is better read as a mixed bucket of generic management, service-brand, operations, process, and commercial-practice archive rows
- the next refinement should break this bucket into sublabels rather than treat it as a blind spot

The dedicated second-level residual note now exists here:

- [customer-world-seed-residual-refinement.md](customer-world-seed-residual-refinement.md)

## What This Model Proves

This ratio model strengthens the seed-layer proof in four ways:

1. the three largest clusters now have exclusive provisional label shares
2. the largest archive mass is no longer only described qualitatively
3. the remaining uncertainty is now concentrated in the meaning of `residual_other`, not in the whole cluster landscape
4. completion work can now move from broad scanning to targeted refinement of the highest-uncertainty buckets

## Next Useful Move

The next stronger step should be:

1. split the remaining `generic_other` mass inside the residual refinement
2. increase sample density inside the largest residual blocks
3. then decide whether a staged seed-overlay ledger is needed for the broadest categories
