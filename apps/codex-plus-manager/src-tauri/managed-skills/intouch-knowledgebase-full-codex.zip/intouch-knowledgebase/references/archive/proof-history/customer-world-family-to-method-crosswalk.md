# Customer World Family-to-Method Crosswalk

Use this file as the bridge between seed-family learning and reusable management references.

This file answers a practical question:

- once a recurring article family is recognized, which methods reference should absorb it?

## Crosswalk Logic

The goal is not only to classify archive content.
The goal is to convert archive learning into reusable management output.

So each family should have a default landing place in the current methods library.

## Crosswalk Table

| Family | Main Landing Methods File | Secondary Landing |
| --- | --- | --- |
| `generic_management_and_quality` | `methods-quality.md` | `methods-performance.md`, `methods-teamlead.md` |
| `operations_design_and_governance` | `methods-metrics.md` | `methods-teamlead.md`, `methods-knowledge.md` |
| `management_framework_and_capability` | `methods-training.md` | `methods-teamlead.md`, `methods-performance.md` |
| `customer_management_and_commercial_practice` | `methods-multichannel.md` | `methods-experience.md`, `methods-performance.md` |
| `technology_application_and_architecture` | `methods-tech-enablement.md` | `methods-selfservice.md`, `methods-service-innovation.md` |
| `industry_context_and_regulation` | `methods-complaints.md` | `methods-experience.md`, `methods-multichannel.md` |

## Current Priority Conversion

Based on the current generic-family reading, the first landing priorities should be:

1. quality and balanced-management themes into `methods-quality.md`
2. KPI / process / execution themes into `methods-metrics.md`
3. data, CRM, IVR, virtual-center, and platform-control themes into `methods-tech-enablement.md`
4. customer segmentation, order handling, and commercial-practice themes into `methods-experience.md` and `methods-multichannel.md`

## Current Turn Conversion Status

This crosswalk now exists so future archive-learning turns can be judged by a stricter standard:

- not only "did we interpret the articles"
- but also "did the interpretation land in the right reusable method file"
