# Archive

This folder stores older proof-chain, audit, seed-sampling, and historical conversion files that are no longer part of the main skill routing.

These files are kept for traceability only.

Archived subfolders currently include:

- `proof-history`: old proof-chain, audit, seed-sampling, and reconciliation files
- `data-seeds`: inactive broad-stream seed exports
- `redundant-expression-packs`: older expression-heavy packs that overlapped with the active reporting, solution, and sample-library routes

The active skill should prefer the current working layers in the parent `references/` folder:

- methods files
- sample libraries
- problem-solving and solution packs
- topic routing files
- BPO cluster routing files
- full-text readme and index
- acceptance checklist
