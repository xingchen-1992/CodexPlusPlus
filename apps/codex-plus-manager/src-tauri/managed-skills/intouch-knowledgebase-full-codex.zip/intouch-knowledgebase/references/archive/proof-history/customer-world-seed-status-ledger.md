# Customer World Seed Status Ledger

Use this file as the first durable ledger layer above `customer-world-master-seed.csv`.

This file does not replace the raw seed table.
It explains how seed-level completion should be tracked and records the first status layer now available from current evidence.

## Why This File Exists

The raw seed table currently proves harvesting.
It does not yet prove learning status.

`customer-world-master-seed.csv` currently has only:

- `category`
- `page`
- `path`
- `title`
- `url`

That means a separate ledger layer is needed for any serious completion claim.

## Phase 1 Ledger Goal

The current phase does not yet track all 9516 rows one by one.

Instead, it establishes:

1. the tracking model
2. category-level status evidence
3. the main reconciliation issue between raw seeds and curated index

## Current Reconciliation Finding

Current measured evidence shows:

- curated index links: `224`
- links directly matched inside `customer-world-master-seed.csv`: `67`

This does not mean the index is wrong.

It means the curated index contains many historically important articles from legacy paths outside the currently harvested broad-category seed table, such as:

- old yearbook-like paths
- `index.php?c=show&id=...`
- legacy section names outside the current broad category harvest

Practical meaning:

- the seed ledger must support both:
  - broad harvested current-category rows
  - hand-curated legacy or historically important index articles

For the first curated-index proof layer built on top of this finding, also read:

- [customer-world-curated-index-reconciliation.md](customer-world-curated-index-reconciliation.md)
- [customer-world-curated-index-status-ledger.md](customer-world-curated-index-status-ledger.md)
- [customer-world-curated-review-priority.md](customer-world-curated-review-priority.md)

## Recommended Future Ledger Fields

When building the next stronger ledger layer, use fields like:

- `url`
- `path`
- `category`
- `seed_presence_status`
- `review_status`
- `disposition`
- `mapped_theme`
- `coverage_asset`
- `coverage_reference`
- `notes`

Recommended status values:

### `seed_presence_status`

- `in_master_seed`
- `legacy_curated_only`

### `review_status`

- `unreviewed`
- `theme-covered`
- `indexed`
- `converted`

### `disposition`

- `high_value_converted`
- `covered_by_existing_theme`
- `duplicate_or_low_increment`
- `pending_review`

### `coverage_asset`

- `index`
- `methods`
- `sample_library`
- `multiple`

## Phase 1 Category Ledger

This first ledger layer is category-based rather than row-based.

| Category | Harvested Rows | Visible Harvest Boundary | Harvest Status | Theme Conversion Status | Archive-Proof Status | Notes |
| --- | ---: | --- | --- | --- | --- | --- |
| `cjyj` | 966 | `1-49` | strong | strong | unproven | high reuse value for scenario, service case, and public-service management |
| `ftdh` | 151 | `1-8` | strong | medium-strong | unproven | useful for benchmark and interview language |
| `hyhz` | 2264 | `1-114` | strong | strong | unproven | strong conference, certification, and ecosystem value |
| `hyxx` | 2408 | `1-121` | strong | strong | unproven | strong for capability models, maturity, and ecosystem updates |
| `hyyw` | 3441 | `1-173` | strong | strong | unproven | broad and noisy; valuable for standards, outsourcing, and industry context |
| `jrm` | 11 | `1-1` | strong | strong | unproven | small archive, mostly award and benchmark language |
| `ksyc` | 179 | `1-9` | strong | strong | unproven | first-hand management essays; high value for methodology tone |
| `szyc` | 35 | `1-2` | strong | medium-strong | unproven | strategic and executive-style AI/service transformation language |
| `zjgd` | 61 | `1-4` | strong | strong | unproven | dense viewpoints and standards interpretation |

## What Phase 1 Proves

Phase 1 proves:

1. the broad harvested archive has a stable status baseline
2. the major categories have a named learning-conversion view
3. the main mismatch between current seeds and curated index is identified instead of ignored

## What Phase 1 Still Does Not Prove

Phase 1 still does not prove:

1. row-by-row review of all 9516 seed entries
2. final disposition for each harvested article
3. exact mapping from every seed row to index, methods, or sample coverage

## Next Ledger Upgrade

The next stronger step should be a row-level overlay, likely starting with:

1. legacy curated index links not present in the master seed
2. highest-value categories such as `ksyc`, `szyc`, `zjgd`, and selected `cjyj`
3. disposition marking for whether an article is:
   - directly indexed
   - already covered by theme extraction
   - pending review
   - low incremental value

That next-pass ordering now has a first explicit queue here:

- [customer-world-curated-review-priority.md](customer-world-curated-review-priority.md)

Until that layer exists, the goal remains advanced but not fully proven.
