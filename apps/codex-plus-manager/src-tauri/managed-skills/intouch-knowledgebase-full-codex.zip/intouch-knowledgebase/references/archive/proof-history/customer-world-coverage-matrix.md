# Customer World Coverage Matrix

Use this file as a practical checkpoint for whether a Customer World theme has moved through the three intended learning layers:

1. index coverage
2. methods extraction
3. Chinese reusable sample phrasing

This is not a full article list. It is a progress-control matrix for the skill.

## Current Matrix

| Theme | Index Coverage | Methods File | Sample Library | Current State |
| --- | --- | --- | --- | --- |
| quality management | sections 1-6, 183, 198-199 | `methods-quality.md` | `sample-library-ops-review-cn.md`, `sample-library-teamlead-cn.md` | strong |
| training and capability | sections 7-11, 188, 191 | `methods-training.md` | `sample-library-improvement-cn.md`, `sample-library-ai-training-cn.md` | strong |
| attrition and retention | sections 12-14 | `methods-retention.md` | `sample-library-improvement-cn.md` | strong |
| KPI and variance control | sections 15-20, 159, 189, 201 | `methods-metrics.md` | `sample-library-reporting-cn.md` | strong |
| WFM and floor control | sections 21-26, 154 | `methods-teamlead.md`, `methods-metrics.md` | `sample-library-teamlead-cn.md`, `sample-library-improvement-cn.md` | strong |
| complaints and expectation | sections 32-36 | `methods-complaints.md`, `methods-experience.md` | `sample-library-client-cn.md`, `sample-library-reporting-cn.md` | strong |
| team-lead and execution | sections 27-31, 81-85, 192 | `methods-teamlead.md` | `sample-library-teamlead-cn.md`, `sample-library-improvement-cn.md` | strong |
| knowledge governance | sections 41, 101, 129, 163, 216-219 | `methods-knowledge.md` | `sample-library-ops-review-cn.md` | strong |
| experience and satisfaction | sections 53, 60, 88, 130, 215 | `methods-experience.md` | `sample-library-reporting-cn.md` | strong |
| multichannel and service-marketing | sections 71-80, 174, 194-195, 204 | `methods-multichannel.md` | `sample-library-service-innovation-cn.md`, `sample-library-client-cn.md` | strong |
| self-service and human-machine collaboration | sections 69, 132, 175-176, 193 | `methods-selfservice.md` | `sample-library-service-innovation-cn.md`, `sample-library-improvement-cn.md` | strong |
| hotline and public-service governance | sections 121, 125, 139, 143, 148, 158, 210-213 | `methods-hotline.md` | `sample-library-hotline-cn.md` | strong |
| digital governance and maturity | sections 146, 149-155, 178, 212-214 | `methods-digital-governance.md` | `sample-library-service-innovation-cn.md` | strong |
| CRM, BI, customer intelligence | sections 160-165, 173, 202, 207-209 | `methods-tech-enablement.md` | `sample-library-client-cn.md` | strong |
| outsourcing platform and delivery architecture | sections 131, 142, 177, 203, 221-223 | `methods-outsourcing-platform.md` | `sample-library-outsourcing-cn.md` | strong |
| contact-center evolution and service innovation | sections 123-124, 133-138, 166, 220, 224 | `methods-service-innovation.md` | `sample-library-service-innovation-cn.md` | strong |
| benchmark, certification, ecosystem language | sections 139, 143, 146, 157-170, 205-206 | `customer-world-conference-stream-themes.md` | `sample-library-client-cn.md`, `sample-library-outsourcing-cn.md`, `sample-library-hotline-cn.md` | strong |
| performance and incentive | sections 48-52, 171, 201 | `methods-performance.md` | `sample-library-improvement-cn.md`, `sample-library-teamlead-cn.md` | strong |
| AI annotation | dedicated AI entries + AI sources | `methods-ai-annotation.md` | `sample-library-ai-annotation-cn.md` | strong |
| LLM data production and evaluation | dedicated AI entries + AI sources | `methods-llm-ops.md`, `methods-model-eval.md` | `sample-library-ai-training-cn.md` | strong |
| embodied training operations | dedicated AI sources | `methods-embodied-ops.md` | `sample-library-ai-training-cn.md` | strong |

## Main Remaining Gaps

At the current stage, the most notable remaining gaps are not article collection gaps.

There is no single major closure-depth gap left in the current matrix.

## Working Rule

When choosing the next Customer World learning step, prefer:

1. themes with article coverage and methods but thinner sample phrasing
2. themes that appear often in client reports, tenders, and executive summaries
3. themes where the current skill still sounds correct but not yet industry-native
