# Customer World Title Overlap Reviewed

Use this file as the first human-review strengthening layer for curated entries previously marked `title_level_overlap_likely`.

This file upgrades the archive proof beyond heuristic wording.
It confirms that these curated rows do have exact-title matches inside `customer-world-master-seed.csv`.

## Review Scope

Reviewed source bucket:

- curated rows previously labeled `title_level_overlap_likely`: `64`

## Review Result Summary

Current exact-title review confirms:

- reviewed curated rows: `64`
- rows with at least one exact-title match in master seed: `64`
- rows with a single exact-title match: `61`
- rows with multiple exact-title matches: `3`
- rows whose first exact-title match stays in the same family: `40`
- rows whose first exact-title match lands in a cross-family or legacy path: `24`

## What This Proves

This review strengthens the archive proof in three ways:

1. the `title_level_overlap_likely` bucket is no longer just a guess
2. all `64` rows in that bucket now have confirmed exact-title overlap inside the master seed
3. the remaining uncertainty shifts from "is there overlap?" to "is the overlap same-content, duplicate-path, or edition-variant?"

## Multi-Match Rows Needing Final Human Disposition

Only three reviewed rows currently show more than one exact-title match in the master seed:

| Curated Index No. | Title | Exact Match Count | Seed Paths |
| --- | --- | ---: | --- |
| 86 | 对外包呼叫中心平台建设的建议 | 2 | `/cjyj/20001.html`, `/hyyw/16846.html` |
| 131 | 对外包呼叫中心平台建设的建议 | 2 | `/cjyj/20001.html`, `/hyyw/16846.html` |
| 142 | 电子商务企业的呼叫中心该选择外包还是自建？ | 2 | `/hyyw/16926.html`, `/zjgd/18604.html` |

These should be treated as final-disposition candidates rather than unresolved overlap candidates.

## Reviewed TSV

```tsv
index_no	title	curated_family	exact_title_match_count	seed_category	first_seed_path	first_seed_url	family_relation	review_note
3	呼叫中心质量管理的目标与方法	article	1	hyyw	/hyyw/15528.html	http://www.ccmw.net/hyyw/15528.html	cross_family_or_legacy	single_exact_title_match
4	如何打造科学化的呼叫中心质量管理体系（下）	hyyw	1	hyyw	/hyyw/15804.html	http://www.ccmw.net/hyyw/15804.html	same_family	single_exact_title_match
15	数据管理——呼叫中心运营管理的灵魂	hyhz	1	hyhz	/hyhz/14632.html	http://www.ccmw.net/hyhz/14632.html	same_family	single_exact_title_match
17	主要表现指针(KPI)在呼叫中心服务及效益管理中的应用	indexphp	1	hyyw	/hyyw/15814.html	http://www.ccmw.net/hyyw/15814.html	cross_family_or_legacy	single_exact_title_match
20	客户服务高绩效管理体系对创建一流呼叫中心的启示	hyyw	1	hyyw	/hyyw/17790.html	http://www.ccmw.net/hyyw/17790.html	same_family	single_exact_title_match
22	呼叫中心的话量预测及人员排班	hyyw	1	hyyw	/hyyw/16057.html	http://www.ccmw.net/hyyw/16057.html	same_family	single_exact_title_match
26	呼叫中心运营管理的15个基本要素（下）	huiyuanxinxi	1	hyxx	/hyxx/10922.html	http://www.ccmw.net/hyxx/10922.html	cross_family_or_legacy	single_exact_title_match
33	做一名优秀的救火员——如何处理升级投诉	article	1	hyyw	/hyyw/16003.html	http://www.ccmw.net/hyyw/16003.html	cross_family_or_legacy	single_exact_title_match
34	简析从投诉管理迈向投诉经营	hyyw	1	hyyw	/hyyw/15978.html	http://www.ccmw.net/hyyw/15978.html	same_family	single_exact_title_match
38	呼叫中心管理与客户期望和客户体验	ksyc	1	ksyc	/ksyc/18785.html	http://www.ccmw.net/ksyc/18785.html	same_family	single_exact_title_match
39	卓越的呼叫中心运营管理艺术与技巧	hyxx	1	hyxx	/hyxx/10980.html	http://www.ccmw.net/hyxx/10980.html	same_family	single_exact_title_match
42	卓越的呼叫中心运营管理艺术与技巧	hyyw	1	hyxx	/hyxx/10980.html	http://www.ccmw.net/hyxx/10980.html	cross_family_or_legacy	single_exact_title_match
43	呼叫中心运营管理系统Teleweb-OMS综述	hyxx	1	hyxx	/hyxx/10963.html	http://www.ccmw.net/hyxx/10963.html	same_family	single_exact_title_match
44	客服域人工智能训练师培训大纲	indexphp	1	cjyj	/cjyj/10539.html	http://www.ccmw.net/cjyj/10539.html	cross_family_or_legacy	single_exact_title_match
45	浅议呼叫中心，客服中心的管理创新	hyxx	1	hyxx	/hyxx/13017.html	http://www.ccmw.net/hyxx/13017.html	same_family	single_exact_title_match
48	客户服务高绩效管理体系对创建一流呼叫中心的启示	article	1	hyyw	/hyyw/17790.html	http://www.ccmw.net/hyyw/17790.html	cross_family_or_legacy	single_exact_title_match
50	客户服务高绩效管理体系对创建一流呼叫中心的启示	indexphp	1	hyyw	/hyyw/17790.html	http://www.ccmw.net/hyyw/17790.html	cross_family_or_legacy	single_exact_title_match
51	浅谈呼叫中心有效管理	article	1	hyyw	/hyyw/16530.html	http://www.ccmw.net/hyyw/16530.html	cross_family_or_legacy	single_exact_title_match
54	呼叫中心管理与客户期望和客户体验	ksyc	1	ksyc	/ksyc/18785.html	http://www.ccmw.net/ksyc/18785.html	same_family	single_exact_title_match
56	外包呼叫中心的核心优势	indexphp	1	hyyw	/hyyw/16806.html	http://www.ccmw.net/hyyw/16806.html	cross_family_or_legacy	single_exact_title_match
58	呼叫中心：从被动服务到主动营销	hyhz	1	hyhz	/hyhz/13324.html	http://www.ccmw.net/hyhz/13324.html	same_family	single_exact_title_match
59	一款用于呼叫中心质量管理的软件分析	hyyw	1	hyyw	/hyyw/15681.html	http://www.ccmw.net/hyyw/15681.html	same_family	single_exact_title_match
60	专家圆桌：客户体验管理	zjgd	1	zjgd	/zjgd/18578.html	http://www.ccmw.net/zjgd/18578.html	same_family	single_exact_title_match
62	呼叫中心员工情绪和压力管理四步法	hyxx	1	hyxx	/hyxx/11004.html	http://www.ccmw.net/hyxx/11004.html	same_family	single_exact_title_match
75	“互联网+服务”需要怎样的在线客服员工？	huiyuanxinxi	1	hyxx	/hyxx/11011.html	http://www.ccmw.net/hyxx/11011.html	cross_family_or_legacy	single_exact_title_match
76	在线客服效率提升的秘密	hyxx	1	hyxx	/hyxx/11146.html	http://www.ccmw.net/hyxx/11146.html	same_family	single_exact_title_match
77	呼叫中心：从被动服务到主动营销	hyhz	1	hyhz	/hyhz/13324.html	http://www.ccmw.net/hyhz/13324.html	same_family	single_exact_title_match
80	知识采编业务落地步骤分解	article	1	hyxx	/hyxx/12750.html	http://www.ccmw.net/hyxx/12750.html	cross_family_or_legacy	single_exact_title_match
81	再谈呼叫中心管理的执行问题	hyyw	1	hyyw	/hyyw/16059.html	http://www.ccmw.net/hyyw/16059.html	same_family	single_exact_title_match
85	呼叫中心内部的指导性沟通	hyyw	1	hyyw	/hyyw/16056.html	http://www.ccmw.net/hyyw/16056.html	same_family	single_exact_title_match
86	对外包呼叫中心平台建设的建议	cjyj	2	cjyj	/cjyj/20001.html	http://www.ccmw.net/cjyj/20001.html	same_family	multiple_exact_title_matches
87	关于某保险行业续保续期业务数字运营方案	ksyc	1	ksyc	/ksyc/20260.html	http://www.ccmw.net/ksyc/20260.html	same_family	single_exact_title_match
89	客服域人工智能训练师培训大纲	indexphp	1	cjyj	/cjyj/10539.html	http://www.ccmw.net/cjyj/10539.html	cross_family_or_legacy	single_exact_title_match
94	数据管理——呼叫中心运营管理的灵魂	hyhz	1	hyhz	/hyhz/14632.html	http://www.ccmw.net/hyhz/14632.html	same_family	single_exact_title_match
96	呼叫中心运营管理的15个基本要素（下）	huiyuanxinxi	1	hyxx	/hyxx/10922.html	http://www.ccmw.net/hyxx/10922.html	cross_family_or_legacy	single_exact_title_match
98	卓越的呼叫中心运营管理艺术与技巧	hyxx	1	hyxx	/hyxx/10980.html	http://www.ccmw.net/hyxx/10980.html	same_family	single_exact_title_match
99	客户服务高绩效管理体系对创建一流呼叫中心的启示	hyyw	1	hyyw	/hyyw/17790.html	http://www.ccmw.net/hyyw/17790.html	same_family	single_exact_title_match
100	一款用于呼叫中心质量管理的软件分析	hyyw	1	hyyw	/hyyw/15681.html	http://www.ccmw.net/hyyw/15681.html	same_family	single_exact_title_match
101	如何对呼叫中心的知识实施有效管理	indexphp	1	hyyw	/hyyw/17846.html	http://www.ccmw.net/hyyw/17846.html	cross_family_or_legacy	single_exact_title_match
102	质检：除了打分，还能干什么？	huiyuanxinxi	1	hyxx	/hyxx/10999.html	http://www.ccmw.net/hyxx/10999.html	cross_family_or_legacy	single_exact_title_match
106	中国移动江苏公司淮安呼叫中心在职培训体系心理解析	hyyw	1	hyyw	/hyyw/17760.html	http://www.ccmw.net/hyyw/17760.html	same_family	single_exact_title_match
107	呼叫中心运营管理的15个基本要素（上）	huiyuanxinxi	1	hyxx	/hyxx/10921.html	http://www.ccmw.net/hyxx/10921.html	cross_family_or_legacy	single_exact_title_match
108	再谈呼叫中心管理的执行问题	hyyw	1	hyyw	/hyyw/16059.html	http://www.ccmw.net/hyyw/16059.html	same_family	single_exact_title_match
110	呼叫中心内部的指导性沟通	hyyw	1	hyyw	/hyyw/16056.html	http://www.ccmw.net/hyyw/16056.html	same_family	single_exact_title_match
117	呼叫中心运营管理的15个基本要素（下）	huiyuanxinxi	1	hyxx	/hyxx/10922.html	http://www.ccmw.net/hyxx/10922.html	cross_family_or_legacy	single_exact_title_match
120	卓越的呼叫中心运营管理艺术与技巧	hyxx	1	hyxx	/hyxx/10980.html	http://www.ccmw.net/hyxx/10980.html	same_family	single_exact_title_match
121	标杆案例：政务服务3.0时代的热线品牌	huiyuanxinxi	1	hyxx	/hyxx/13147.html	http://www.ccmw.net/hyxx/13147.html	cross_family_or_legacy	single_exact_title_match
123	遗忘呼叫中心的时代	ksyc	1	ksyc	/ksyc/18724.html	http://www.ccmw.net/ksyc/18724.html	same_family	single_exact_title_match
128	呼叫中心员工情绪和压力管理四步法	hyxx	1	hyxx	/hyxx/11004.html	http://www.ccmw.net/hyxx/11004.html	same_family	single_exact_title_match
129	如何对呼叫中心的知识实施有效管理	indexphp	1	hyyw	/hyyw/17846.html	http://www.ccmw.net/hyyw/17846.html	cross_family_or_legacy	single_exact_title_match
131	对外包呼叫中心平台建设的建议	cjyj	2	cjyj	/cjyj/20001.html	http://www.ccmw.net/cjyj/20001.html	same_family	multiple_exact_title_matches
132	环信大学最佳实践：如何帮助客服知识积累、提升效率、标准化服务！	hyxx	1	hyxx	/hyxx/13053.html	http://www.ccmw.net/hyxx/13053.html	same_family	single_exact_title_match
137	“互联网+服务”需要怎样的在线客服员工？	huiyuanxinxi	1	hyxx	/hyxx/11011.html	http://www.ccmw.net/hyxx/11011.html	cross_family_or_legacy	single_exact_title_match
141	呼叫中心平台建设之预算篇	indexphp	1	hyyw	/hyyw/17854.html	http://www.ccmw.net/hyyw/17854.html	cross_family_or_legacy	single_exact_title_match
142	电子商务企业的呼叫中心该选择外包还是自建？	article	2	hyyw	/hyyw/16926.html	http://www.ccmw.net/hyyw/16926.html	cross_family_or_legacy	multiple_exact_title_matches
144	标杆案例：政务服务3.0时代的热线品牌	huiyuanxinxi	1	hyxx	/hyxx/13147.html	http://www.ccmw.net/hyxx/13147.html	cross_family_or_legacy	single_exact_title_match
146	《客户世界》2021年度编辑推荐：服务数字化最佳案例（金融行业）	hyyw	1	hyyw	/hyyw/18314.html	http://www.ccmw.net/hyyw/18314.html	same_family	single_exact_title_match
147	华为公司12345政府热线系统解决方案	hyxx	1	hyxx	/hyxx/12263.html	http://www.ccmw.net/hyxx/12263.html	same_family	single_exact_title_match
149	数字人才培养工程简介	hyxx	1	hyxx	/hyxx/10598.html	http://www.ccmw.net/hyxx/10598.html	same_family	single_exact_title_match
180	智能数据分析助力联络中心数智化运营	hyxx	1	hyxx	/hyxx/11231.html	http://www.ccmw.net/hyxx/11231.html	same_family	single_exact_title_match
183	质检：除了打分，还能干什么？	hyxx	1	hyxx	/hyxx/10999.html	http://www.ccmw.net/hyxx/10999.html	same_family	single_exact_title_match
184	智能化趋势下呼叫中心人员胜任力转型探索	hyxx	1	hyxx	/hyxx/11003.html	http://www.ccmw.net/hyxx/11003.html	same_family	single_exact_title_match
185	电话营销你应该做的准备	hyhz	1	hyhz	/hyhz/14373.html	http://www.ccmw.net/hyhz/14373.html	same_family	single_exact_title_match
186	别用电话吓跑客户——保险行业电话营销案例分析	hyhz	1	hyhz	/hyhz/14215.html	http://www.ccmw.net/hyhz/14215.html	same_family	single_exact_title_match
```
