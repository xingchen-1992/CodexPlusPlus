# Customer World Seed Sampling Targets

Use this file as the staged sampling-target ledger for proving broader seed-layer learning completion.

This file does not replace row-by-row review.
It defines a practical sampling path so that later work can accumulate evidence in a controlled way instead of adding scattered examples.

## Why Sampling Targets Are Needed

Current proof is already strong at:

- site harvesting
- curated 224-entry reconciliation
- original and conference stream theme conversion
- three major cluster disposition and residual refinement

The remaining gap is not whether the archive exists.
The remaining gap is whether the broad seed archive has enough structured review density to justify stronger completion language.

That requires explicit sampling targets.

## Sampling Design Principle

Sampling should serve three goals at once:

1. verify that cluster-level reading still holds at row level
2. keep pressure on the largest uncertainty buckets first
3. produce material that can later be converted into methods files and sample-library assets

## Current Priority Order

Sampling priority should follow archive uncertainty, not only archive size.

1. `hyyw` `generic_other`
2. `hyxx` `generic_other`
3. `hyhz` `generic_other`
4. `hyyw` residual families outside `generic_other`
5. `hyxx` residual families outside `generic_other`
6. `hyhz` residual families outside `generic_other`
7. lower-density seed categories (`ftdh`, `zjgd`, `ksyc`, `szyc`, `jrm`, `cjyj`)

## Stage Targets

### Stage 1: major-cluster residual confirmation

Goal:

- validate the current residual-family reading across the three largest clusters

Target:

- `hyyw`: `30` additional reviewed titles
- `hyxx`: `30` additional reviewed titles
- `hyhz`: `20` additional reviewed titles

Stage-1 total: `80`

Reading rule:

- prioritize `generic_other`
- ensure each third-level family gets at least a minimal visible sample

### Stage 2: major-cluster generic-mass deepening

Goal:

- test whether `generic_other` can be split more formally into third-level rule groups

Target:

- `hyyw`: `40` additional reviewed titles
- `hyxx`: `40` additional reviewed titles
- `hyhz`: `25` additional reviewed titles

Stage-2 total: `105`

Reading rule:

- oversample the largest hidden families:
  - generic management and quality
  - operations design and governance
  - management framework and capability
  - customer management and commercial practice

### Stage 3: lower-density category anchoring

Goal:

- prevent the remaining smaller categories from staying as weakly interpreted long-tail territory

Target:

- `ftdh`: `10`
- `zjgd`: `10`
- `ksyc`: `10`
- `szyc`: `10`
- `jrm`: `5`
- `cjyj`: `15`

Stage-3 total: `60`

Reading rule:

- prefer titles that either:
  - anchor a distinct theme
  - connect directly to an existing methods file
  - or fill a category that currently has sparse narrative explanation

## Minimum Evidence Thresholds

Before claiming stronger seed-layer completion, the following minimum thresholds should exist:

1. each major cluster has at least one explicit third-level family note with representative titles
2. each major cluster has staged review evidence beyond ad hoc examples
3. lower-density categories each have a visible anchor sample set
4. newly reviewed samples are traceable back into:
   - topic interpretation
   - methods extraction
   - or sample-library drafting

## Current Completion Reading Against These Targets

At current state:

- cluster-level theme reading: present
- ratio model: present
- residual refinement: present
- generic-other family hypothesis: present
- formal staged sampling ledger: now present
- first executed sampling batch: now present
- staged sampling execution against fixed targets: started, not yet complete

This means the proof system is now more complete than before, but the execution count against the target ledger is still unfinished.

## Execution Progress

Current executed batch evidence:

- [customer-world-seed-sampling-batch-01.md](customer-world-seed-sampling-batch-01.md)
- [customer-world-seed-sampling-batch-02.md](customer-world-seed-sampling-batch-02.md)
- [customer-world-seed-sampling-batch-03.md](customer-world-seed-sampling-batch-03.md)
- [customer-world-seed-sampling-batch-04.md](customer-world-seed-sampling-batch-04.md)
- [customer-world-seed-sampling-batch-05.md](customer-world-seed-sampling-batch-05.md)
- [customer-world-seed-sampling-batch-06.md](customer-world-seed-sampling-batch-06.md)
- [customer-world-low-density-anchor-batch-01.md](customer-world-low-density-anchor-batch-01.md)
- [customer-world-low-density-anchor-batch-02.md](customer-world-low-density-anchor-batch-02.md)

Current progress against Stage 1 target:

- Stage 1 target: `80`
- completed so far: `80`
- remaining Stage 1 target: `0`

Low-density anchor progress:

- first and second anchor batches: started
- anchored categories so far:
  - `cjyj`
  - `ftdh`
  - `jrm`
  - `ksyc`
  - `szyc`
  - `zjgd`

## Recommended Execution Rhythm

For future learning turns:

1. review `10-15` additional titles per turn
2. update the relevant family note or methods note immediately
3. only then raise the completion judgment for that cluster

This keeps the archive-learning claim tied to visible evidence instead of broad narrative confidence.
