# Customer World Curated Index Reconciliation

Use this file when reconciling the curated 224-entry article index against the broad harvested seed table.

This file is the first curated-index proof layer above the seed-status ledger.

## Why This File Matters

The current archive proof cannot rely on URL matching alone.

Customer World content appears across:

- currently harvested broad categories
- older legacy section paths
- `index.php?c=show&id=...` style links
- yearbook-like historical paths

So this reconciliation file explains why the curated index and the broad seed table only partially align at URL level.

## Measured Reconciliation Snapshot

Current measured results:

- curated index entries: `224`
- direct URL matches inside `customer-world-master-seed.csv`: `67`
- title matches inside `customer-world-master-seed.csv`: `127`

Practical meaning:

1. a direct-URL-only audit would undercount true overlap
2. some curated articles likely exist in the harvested archive under changed paths or mirrored titles
3. archive completion needs both URL-level and title/theme-level reconciliation

## Reconciliation Interpretation

The gap between `67` URL matches and `127` title matches suggests several different cases:

1. true direct overlap:
   - same article
   - same URL
2. likely legacy-path overlap:
   - same or equivalent title
   - different URL family
3. curated-only historical references:
   - important article retained in the curated index
   - not present in the current broad-category seed set

## URL-Family Findings For Unmatched Curated Entries

The largest unmatched URL families are:

| Path Family | Unmatched Count | Interpretation |
| --- | ---: | --- |
| `indexphp` | 30 | old dynamic links, likely outside the current broad-category path harvest |
| `article` | 24 | legacy article pages not all represented in the current broad-category seed table |
| `hyxx` | 17 | member-information family has partial path mismatch or legacy variants |
| `hyyw` | 16 | industry-news family has some unmatched historical links |
| `huiyuanxinxi` | 12 | legacy member-information path family |
| `hyhz` | 6 | conference-family mismatch or legacy variants |
| `cjyj` | 6 | scenario-research mismatch or legacy variants |
| other smaller families | 43 | old yearbook-like paths, niche historical sections, or isolated legacy links |

## What This Proves

This reconciliation already proves:

1. the curated index is not simply a subset of the current master seed URLs
2. the current broad harvest and the curated historical index are overlapping but non-identical layers
3. the completion proof must support `legacy_curated_only` as a legitimate status, not treat it as an error

## First Curated Status Model

For curated-index tracking, use these interpretation states:

- `direct_seed_match`
- `title_level_overlap_likely`
- `legacy_curated_only`

The first full heuristic row-level ledger now exists here:

- [customer-world-curated-index-status-ledger.md](customer-world-curated-index-status-ledger.md)
- [customer-world-title-overlap-reviewed.md](customer-world-title-overlap-reviewed.md)

Current full-ledger counts:

- `direct_seed_match`: `67`
- `title_level_overlap_likely`: `64`
- `legacy_curated_only`: `93`

Current reviewed strengthening:

- all `64` `title_level_overlap_likely` rows now have exact-title confirmation in the master seed
- `61` are single-match confirmations
- `3` are multi-match rows requiring final disposition

## First Batch of Clearly Unmatched Curated Examples

The following examples are currently unmatched by direct URL inside `customer-world-master-seed.csv` and should be treated as curated reconciliation candidates:

| Index No. | Title | Path Family | Suggested Curated Status |
| --- | --- | --- | --- |
| 1 | TCL移动呼叫中心质量管理的五方面工作 | `article` | `legacy_curated_only` |
| 2 | 意见领袖：呼叫中心的质量管理 | `article` | `legacy_curated_only` |
| 3 | 呼叫中心质量管理的目标与方法 | `article` | `legacy_curated_only` |
| 6 | 热线平均处理时长的质量管理探讨 | `indexphp` | `legacy_curated_only` |
| 8 | 呼叫中心的培训管理 | `indexphp` | `legacy_curated_only` |
| 9 | 雏鹰成长记——浅谈呼叫中心新员工培训管理 | `2016n12yk` | `legacy_curated_only` |
| 10 | 注重员工培训打造一流呼叫中心运营团队 | `indexphp` | `legacy_curated_only` |
| 11 | 如何评估培训的效果 | `2010n08yk` | `legacy_curated_only` |
| 12 | 破解呼叫中心“用人慌”的思考 | `article` | `legacy_curated_only` |
| 13 | 如何降低外包员工流失 | `indexphp` | `legacy_curated_only` |
| 16 | 最小方差管理法在呼叫中心指标管理中的应用 | `2013n7yk` | `legacy_curated_only` |
| 17 | 主要表现指针(KPI)在呼叫中心服务及效益管理中的应用 | `indexphp` | `legacy_curated_only` |
| 19 | 呼叫中心- 理性管理 | `2013n4yk` | `legacy_curated_only` |
| 21 | 可创造“奇迹”的呼叫中心排班管理 | `indexphp` | `legacy_curated_only` |
| 24 | 利用“四率”，轻松做好呼叫中心现场管理 | `2008n02-03yhk` | `legacy_curated_only` |

## What Still Needs To Happen

This file is still only a first reconciliation pass.

It now has a full heuristic row-level companion ledger for all `224` curated entries.
What is still missing is not first-pass assignment, but stronger human-reviewed confirmation.

The next useful move is:

1. manually review the `64` `title_level_overlap_likely` rows
2. sort the `93` `legacy_curated_only` rows by priority family and management value
3. separate duplicate-title path variants from genuinely distinct historical knowledge
4. add a final reviewed status after heuristic classification

For the next-pass review order, also read:

- [customer-world-curated-review-priority.md](customer-world-curated-review-priority.md)

Until then, archive-level completion remains better evidenced than before, but still not fully proven.
