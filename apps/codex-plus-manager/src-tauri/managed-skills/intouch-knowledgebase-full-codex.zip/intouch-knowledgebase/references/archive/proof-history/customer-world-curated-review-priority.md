# Customer World Curated Review Priority

Use this file as the next-pass queue after the heuristic 224-entry curated status ledger.

This file does not replace the ledger.
It tells the next reviewer where the highest-value unresolved work is.

## Why A Priority Queue Is Needed

The curated index now has a full heuristic ledger:

- `direct_seed_match`: `67`
- `title_level_overlap_likely`: `64`
- `legacy_curated_only`: `93`

But these unresolved rows are not equal in value.
Some are likely only path variants or duplicate-title echoes.
Others are important historical management articles that should still shape the knowledge base.

## Priority Principle

Review in this order:

1. items that could change archive-level proof quickly
2. items with strong management-method value
3. items likely to be duplicate-title or path-variant noise

## Priority Queue

### Priority A: `title_level_overlap_likely`

Count: `64`

Why first:

1. these rows are most likely to convert from heuristic overlap to confirmed coverage
2. confirming them will narrow the gap between curated history and harvested seeds fastest
3. many are already close to existing methods and sample coverage

Recommended action:

- manually confirm whether the same title truly points to equivalent content
- mark whether the item is:
  - confirmed seed overlap
  - duplicate-title path variant
  - still requires curated-only retention

Current progress:

- all `64` rows now have exact-title confirmation inside the master seed
- see [customer-world-title-overlap-reviewed.md](customer-world-title-overlap-reviewed.md)
- the remaining work in this bucket is final disposition, not basic overlap validation

### Priority B: high-volume `legacy_curated_only` families

Count: `93` total, with the largest families:

| Family | Legacy Curated Only Count | Why It Matters |
| --- | ---: | --- |
| `indexphp` | 22 | large volume of old dynamic links; likely high mismatch but also high historical value |
| `article` | 18 | legacy editorial pages; many management classics likely live here |
| `cjyj` | 4 | scenario and research value; often reusable in management-method language |
| `2010n08yk` | 4 | yearbook-style historical content; likely useful for people-management and emotion themes |
| `huiyuanxinxi` | 3 | member-information legacy path; may hide management-method overlaps |
| `hyxx` | 3 | capability and ecosystem path; useful for standards and digitalization context |

Recommended action:

- review `indexphp` and `article` before smaller families
- separate true historical high-value classics from low-increment archive residue

Current progress:

- the first manual legacy batch now exists here:
  - [customer-world-legacy-curated-review-batch-01.md](customer-world-legacy-curated-review-batch-01.md)
- that batch reviews `24` high-value `legacy_curated_only` rows
- `20` are already strong `high_value_converted` candidates
- `4` are currently best read as `covered_by_existing_theme`
- the second manual legacy batch now exists here:
  - [customer-world-legacy-curated-review-batch-02.md](customer-world-legacy-curated-review-batch-02.md)
- that batch reviews `20` additional `legacy_curated_only` rows
- `16` are already strong `high_value_converted` candidates
- `4` are currently best read as `covered_by_existing_theme`
- the third manual legacy batch now exists here:
  - [customer-world-legacy-curated-review-batch-03.md](customer-world-legacy-curated-review-batch-03.md)
- that batch reviews `19` additional `legacy_curated_only` rows
- `13` are already strong `high_value_converted` candidates
- `6` are currently best read as `covered_by_existing_theme`
- the fourth manual legacy batch now exists here:
  - [customer-world-legacy-curated-review-batch-04.md](customer-world-legacy-curated-review-batch-04.md)
- that batch reviews the remaining `29` `legacy_curated_only` rows
- after batch 04, the `legacy_curated_only` bucket is fully batch-dispositioned at current evidence level
- cumulative reviewed summary now exists here:
  - [customer-world-curated-reviewed-summary.md](customer-world-curated-reviewed-summary.md)

### Priority C: duplicate-title groups

Current duplication signal:

- duplicate-title groups: `34`
- rows involved: `75`

Why this matters:

1. duplicate titles can inflate the apparent remaining workload
2. some repeated titles are likely path migration rather than new knowledge
3. completion proof needs a disposition for duplicate-title rows, not only coverage counts

Examples of the heaviest duplicate groups:

| Title | Duplicate Rows |
| --- | ---: |
| 客户服务高绩效管理体系对创建一流呼叫中心的启示 | 4 |
| 卓越的呼叫中心运营管理艺术与技巧 | 4 |
| 不可不知：呼叫中心管理的重大漏洞 | 3 |
| 服务数字化转型（六）如何正确认识和管理服务满意度 | 3 |
| 呼叫中心运营管理的15个基本要素（下） | 3 |

Recommended action:

- decide whether each duplicate group represents:
  - same knowledge, different path
  - same title, different edition
  - genuinely distinct content worth separate retention

## Practical Next Step

The most efficient next review wave is:

1. clear `title_level_overlap_likely`
2. clear high-volume `indexphp` and `article` legacy rows
3. then collapse duplicate-title groups into reviewed dispositions

This will improve completion proof faster than scanning low-value long-tail rows first.
