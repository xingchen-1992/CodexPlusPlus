# Customer World Multi-Match Disposition

Use this file for the small set of curated rows that already passed exact-title confirmation but still match more than one seed row.

This file is the next proof layer after [customer-world-title-overlap-reviewed.md](customer-world-title-overlap-reviewed.md).

## Review Scope

Current multi-match rows from the reviewed overlap bucket:

- total rows: `3`
- distinct titles involved: `2`

## Disposition Rule

When one curated row maps to multiple exact-title seed rows, do not send it back to the unresolved overlap bucket.

Instead, classify it as one of:

1. cross-category duplicate-title overlap
2. same-title different-edition candidate
3. distinct-content candidate requiring later content comparison

## Current Disposition

| Curated Index No. | Title | Seed Match Count | Seed Paths | Current Best Disposition | Reason |
| --- | --- | ---: | --- | --- | --- |
| 86 | 对外包呼叫中心平台建设的建议 | 2 | `/cjyj/20001.html`, `/hyyw/16846.html` | `cross_category_duplicate_title_overlap` | same title appears in both scenario-research and industry-news families, which is more consistent with archive-path migration or cross-posting than with unresolved absence |
| 131 | 对外包呼叫中心平台建设的建议 | 2 | `/cjyj/20001.html`, `/hyyw/16846.html` | `cross_category_duplicate_title_overlap` | same duplicate-title condition as row 86; should be collapsed into one reviewed overlap pattern rather than treated as two unresolved gaps |
| 142 | 电子商务企业的呼叫中心该选择外包还是自建？ | 2 | `/hyyw/16926.html`, `/zjgd/18604.html` | `cross_category_duplicate_title_overlap` | same title appears in industry-news and expert-view families, indicating the archive already contains the title in more than one context |

## What This Proves

This file reduces uncertainty in the reviewed overlap bucket:

1. the three multi-match rows are no longer unresolved title-overlap cases
2. they are better treated as duplicate-title overlap patterns already present in the archive
3. any remaining future work is content-level comparison, not archive-presence validation

## Practical Effect On Completion Proof

After this disposition:

- the `64` reviewed title-overlap rows no longer contain archive-presence uncertainty
- the remaining proof gap moves further toward:
  - `legacy_curated_only` historical classics
  - duplicate-title collapse logic
  - broader seed-level disposition at scale
