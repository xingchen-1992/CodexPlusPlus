# Customer World Curated Reviewed Summary

Use this file as the current cumulative status page for the curated 224-entry Customer World index.

This file does not replace the detailed ledgers.
It summarizes how much of the curated layer has moved from rough classification toward stronger proof.

## Current Curated Structure

The curated 224-entry index is currently split into three main buckets:

- `direct_seed_match`: `67`
- `title_level_overlap_likely`: `64`
- `legacy_curated_only`: `93`

## Current Reviewed Progress

As of the current workspace state:

- direct URL-confirmed curated rows: `67`
- exact-title-reviewed overlap rows: `64`
- legacy-curated rows manually reviewed in batches:
  - batch 01: `25`
  - batch 02: `20`
  - batch 03: `19`
  - batch 04: `29`
- total manually reviewed legacy-curated rows: `93`

## Strengthened-Evidence Total

Current strengthened-evidence curated rows:

- `67` direct URL matches
- `64` reviewed exact-title overlaps
- `93` manually reviewed legacy-curated rows

Total strengthened-evidence curated rows: `224`

## Remaining Curated Gap

Current remaining curated rows without batch-level strengthened proof:

- remaining `legacy_curated_only` rows after four manual batches: `0`

Practical meaning:

1. the curated layer is no longer mostly heuristic
2. a large majority of curated entries now have either direct seed proof, reviewed title proof, or manual legacy-conversion proof
3. the curated 224-entry layer is now fully batch-dispositioned at current evidence level

## Current Legacy-Batch Totals

| Batch | Reviewed Rows | `high_value_converted` | `covered_by_existing_theme` |
| --- | ---: | ---: | ---: |
| batch 01 | 25 | 20 | 5 |
| batch 02 | 20 | 16 | 4 |
| batch 03 | 19 | 13 | 6 |
| batch 04 | 29 | 10 | 19 |
| total | 93 | 59 | 34 |

## What This Means For The Goal

This summary strengthens the completion path in an important way:

1. the curated 224-entry layer is now fully dispositioned at current evidence level
2. the main unfinished proof gap is now shifting much more clearly away from curated ambiguity and toward the broader 9516-row seed-level disposition problem
3. the next completion milestone should be a stronger bridge from curated proof into seed-level cluster proof
