# WFM, Scheduling, and Service-Level Method

Use for forecasting, staffing, scheduling, service level, attendance, shrinkage, adherence, interval mismatch, and real-time management.

## Management Judgment

Do not equate service pressure with total headcount shortage. Separate planned capacity from effective interval capacity and distinguish a forecast problem, schedule-design problem, attendance loss, skill mismatch, or real-time control failure.

Treat service level as a stability and cost-discipline problem, not only a month-end attainment problem. A recovered monthly number can still hide weak interval control, expensive over-service, or fragile recovery behavior.

## Cause Structure

Trace the capacity chain:

1. demand forecast: volume, arrival pattern, handling time, work type, and uncertainty
2. required workload: interval demand converted into workload or staffing need
3. schedule fit: shifts, breaks, training, meetings, and skill coverage against the curve
4. attendance and adherence: scheduled staff versus actual presence and state compliance
5. shrinkage: paid time not available for productive handling
6. effective online capacity: logged-in, ready, correctly skilled, and able to handle demand
7. real-time response: threshold, owner, intervention, and recovery speed

For multiskill or digital work, also separate nominal headcount from skill-qualified capacity, concurrency assumptions, asynchronous backlog, and channel-switch cost.

For digital work, define the conversation lifecycle: active handling, customer-wait state, timeout, reopen, wrap-up, and deferred work. Forecasting is unreliable when these states are collapsed into voice-style handle time.

## Diagnostic Views

Use interval-level data whenever available. Compare:

- forecast volume versus actual volume
- required staffing versus scheduled staffing
- scheduled staffing versus actual attendance
- actual attendance versus logged-in staff
- logged-in staff versus effective productive capacity
- skill demand versus skill supply
- service level, abandonment, backlog, AHT/handling time, ACW, and auxiliary states
- schedule variance by cause: demand, absence, adherence, skill mismatch, offline activity, or planning change
- consistency by day, interval, or prime business window instead of relying on one aggregate attainment number

For non-voice work, replace calls and service level with the appropriate workload, response-time, backlog, concurrency, TAT, or batch-capacity measures.

## Action Mechanism

- immediate: adjust breaks, pause nonessential offline activity, activate cross-skill support, control abnormal states, and prioritize high-risk queues
- short cycle: redesign peak coverage, skill mix, leave/training windows, and backup roster
- maintain an exception calendar that records promotions, incidents, weather, releases, and other recurring demand or capacity shocks for future forecasts
- protect planned coaching and training as explicit shrinkage; repeated cancellation is a capacity-design defect, not a free recovery action
- use flex, voluntary, cross-skilled, or non-scheduled capacity for defined peaks only after availability, quality, and cost boundaries are clear
- include coaching access, skill maintenance, and communication rhythm in any flex-pool design; flexible availability must not create a second-class workforce
- structural: improve forecast inputs, shrinkage assumptions, schedule rules, adherence governance, and real-time decision thresholds
- use a defined trial period before concluding that permanent headcount is required

## Ownership

- WFM: forecast, requirement, schedule design, gap forecast, and intraday signal
- operations supervisor: attendance, adherence, intervention, and support deployment
- team lead: state control, exception confirmation, and frontline communication
- HR/training/process/system owners: absence, offline demand, process friction, or system-capacity causes

## Rhythm

- before day: demand and gap outlook
- before peak: readiness and backup confirmation
- intraday: interval monitoring and threshold action
- end of day: forecast, capacity, and recovery review
- weekly: trial result and recurring mismatch review
- monthly: forecast model, shrinkage, schedule policy, and skill strategy
- avoid using monthly reviews as the first place where repeated short-cycle instability becomes visible

## Metrics and Signals

Use relevant measures:

- forecast accuracy or error
- staffing requirement gap
- schedule fit by interval
- attendance and adherence
- shrinkage and effective online rate
- service level or response-time attainment
- abandonment, backlog age, occupancy/utilization, ACW, and recovery time
- cross-skill support response and effectiveness
- schedule variance by cause and recovery time
- forecast error by channel and skill, plus digital concurrency and timeout assumption accuracy

## Anti-Patterns

Avoid:

- using daily totals to explain an interval failure
- adding people before locating capacity leakage
- confusing attendance with adherence
- using high occupancy as proof of healthy productivity
- forcing voice-center metrics onto text, annotation, or batch operations
- chronically cancelling training or coaching to protect the current interval
- applying voice Erlang assumptions directly to asynchronous or concurrent digital work
- using real-time queue alarms so aggressively that agents experience constant interruption or avoidable stress

## Output Contract

Give the capacity-chain judgment, interval evidence needed, immediate containment, trial adjustment, structural action, owners, and recheck date.
