# Reference Layer Map

This compatibility file explains the three knowledge layers. Use [core-routing-table.md](core-routing-table.md) as the live routing source of truth.

## Layer 1: Method

Use one matching `methods-*.md` file to form the diagnosis, cause structure, and management mechanism.

## Layer 2: Scenario

Add one of the following only when the business context or deliverable requires it:

- `business-lines.md` for business-line differences
- `operations.md` for an internal action plan
- `reporting.md` for a review or client report
- `tender.md` for proposals, RFPs, or SLA design
- `event.md` for incidents and urgent escalation
- `metrics-dictionary.md` for KPI definitions and formulas

## Layer 3: Sample

Add one matching sample library only when the user wants directly reusable wording. Samples support expression and do not replace judgment.

## Default Sequence

1. primary method
2. optional scenario or deliverable file
3. optional sample
4. targeted full text only for evidence or uncommon detail

Do not make `customer-world-problem-solving-map.md`, a broad topic index, or a full-text index mandatory for every question.
