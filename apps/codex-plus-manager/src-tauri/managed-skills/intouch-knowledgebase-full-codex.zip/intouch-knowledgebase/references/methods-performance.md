# Performance and Incentive Methods

Use this reference when the user asks about performance management, incentive design, team versus individual KPI, morale-linked rewards, or how to make assessment drive the right behavior.

This file reflects customer-world style management thinking: performance management should not create local optimization that damages the wider operation.

## Core View

Performance management should do three things at the same time:

1. clarify expectations
2. guide behavior
3. align individual action with team and center goals

If incentives only push personal output, cross-team cooperation and long-term service quality can degrade.

## Common Performance Design Errors

Watch for:

- everyone only cares about personal KPI
- support behavior is punished because it hurts local metrics
- short-term speed is rewarded more than stable quality
- supervisors are judged on numbers but not on management routines
- scorecards become complicated but behavior still does not improve

## Team and Individual Balance Rule

Useful design pattern:

- frontline staff: center or team result + personal result
- supervisors: center result + team result + personal management result

Management meaning:

- some performance weight should reward collective success
- otherwise sudden support, cross-skill cooperation, and shared accountability will collapse

## Incentive Design Principles

Good incentives should be:

- visible
- understandable
- timely
- behavior-shaping
- balanced between short-term drive and long-term fairness

Use both:

- individual recognition for strong execution
- team recognition for joint delivery and mutual support

## Supervisor Performance Rule

Do not score supervisors only on final KPI.

Also review:

- coaching completion
- team stability
- talent development
- exception handling quality
- management routine execution

## Short-Term and Long-Term Balance Rule

Performance design should separate short-cycle push from long-cycle health.

Useful pattern:

- short cycle: output, response speed, conversion, or daily execution
- mid cycle: quality stability, rework, complaint control, or attendance discipline
- long cycle: team stability, talent growth, knowledge reuse, and sustainable service quality

Management meaning:

- a scorecard becomes risky when monthly short-term output overwhelms the indicators that protect long-term delivery health

## Early-Warning Incentive Rule

Incentives should not begin only after the result is already lost.

Build earlier signals into the mechanism, such as:

- trend deterioration before final KPI miss
- repeated weak process behavior
- rising complaint or repeat-contact risk
- unstable new-hire adaptation
- abnormal pressure or morale signs in a team

Management meaning:

- earlier management triggers make incentives and accountability corrective, not merely retrospective

## Fairness-and-Transparency Rule

Employees accept pressure more easily when the performance logic feels understandable and fair.

Check whether the mechanism is:

- clearly explained
- stable across similar cases
- not overly dependent on manager preference
- auditable when disputes happen
- transparent about exceptional adjustments

Management meaning:

- even a strong incentive loses effect when employees believe scoring is opaque or inconsistent

## Team-Support Protection Rule

Performance design should protect necessary support behavior instead of penalizing it.

Typical protected behaviors include:

- cross-team support during peaks
- mentoring new hires
- helping resolve difficult or complaint-risk cases
- knowledge contribution and process improvement suggestions
- temporary coverage for unstable teams or special tasks

Management meaning:

- when support work always damages personal scores, the organization quietly trains people to avoid the very behaviors the operation needs most

## Manager Accountability Rule

Management accountability should connect results with the management actions that caused them.

Review not only final outcomes but also whether the manager:

- identified risk early
- used coaching and follow-up in time
- escalated structural issues
- improved recurring weak points
- maintained team discipline without damaging morale unnecessarily

Management meaning:

- accountability is stronger when managers are judged on whether they managed the process well, not only whether they were lucky in the result period

## Good Management Expression

- performance management should reward the right behavior, not only the final number
- a center that over-rewards individual results may unintentionally weaken collaboration
- team incentives are useful when operations depend on fast mutual support across projects or groups
- a healthy scorecard should balance short-term results with long-term delivery stability
- good incentive mechanisms become more persuasive when employees can understand, verify, and trust the rules
