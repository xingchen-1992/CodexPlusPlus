# Knowledge and Rule-Governance Method

Use for knowledge-base design, SOP drift, rule updates, frontline consultation, search failure, version control, and one-time-resolution support.

## Management Judgment

Treat the knowledge base as an operating judgment system, not a document archive. If frontline staff still ask people despite frequent updates, diagnose whether they cannot find, understand, trust, apply, or distinguish the current version.

## Cause Structure

Classify the gap:

- findability: weak naming, indexing, synonym coverage, or search results
- readability: long policy text without a decision path
- trust: conflicting entries, unclear authority, or outdated content
- applicability: no scenario, condition, action, exception, or escalation boundary
- version: updates lack owner, effective date, change summary, or retirement control
- feedback: consultations, defects, and failed searches do not feed content improvement
- adoption: supervisors and training do not reinforce use in real work

## Knowledge Lifecycle

Use this loop:

1. capture demand from searches, consultations, defects, complaints, and rule changes
2. draft a scenario-based entry
3. validate business accuracy and operational usability
4. approve, publish, and communicate the change
5. apply and observe usage
6. review effectiveness, update, merge, or retire

Operate three connected layers:

- content layer: accurate, concise, scenario-based answers and decision rules
- governance layer: owner, approval, version, effective date, permissions, and retirement
- intelligence layer: search, retrieval, recommendation, feedback, and AI assistance validated against governed content

A usable entry should include:

- applicable scenario and trigger
- judgment conditions
- handling steps
- exception and escalation boundary
- customer or client wording when relevant
- owner, version, effective date, and expiry or review date
- explicit linkage to the journey stage or operating node where the rule is applied when that context affects handling

## Action Mechanism

- map the top consultation and failed-search reasons
- rewrite high-frequency entries around scenarios rather than departments
- title entries with the action users are trying to complete and include frontline or customer wording, not only policy-owner terminology
- co-design high-use entries with the people who search for and apply them
- create positive, negative, and boundary examples for ambiguous rules
- remove duplicate and expired content
- reduce platform and departmental silos so one governed answer is discoverable across the relevant service path
- convert repeated second-line answers into governed entries
- use no-result searches, repeated searches, long search time, ticket recurrence, transfer, and workaround behavior to identify gaps
- require AI-generated or retrieved answers to preserve source, version, applicability, and escalation boundaries
- review whether usage reduces support demand and operating defects
- align major knowledge changes with quality calibration, routing logic, and supervisor communication so governed content and governed execution do not drift apart

## Ownership

- business or policy owner: rule correctness
- knowledge manager: structure, version, publication, and retirement
- training: change understanding and reinforcement
- team lead: frontline use and feedback quality
- QA/operations: defect and effect evidence

## Rhythm

- daily or weekly: urgent rule change and high-risk correction
- weekly: top failed searches and repeated consultation
- monthly: stale, duplicate, low-use, and high-impact content review
- after major change: targeted comprehension and use-effect check

## Metrics and Signals

- search success and no-result rate
- knowledge hit and helpfulness rate
- time to usable answer, repeated-query rate, stale-content exposure, and answer-source traceability
- repeated second-line consultation
- outdated or conflicting entry count
- time to publish critical updates
- knowledge-linked QA defects, AHT/TAT, FCR, repeat contact, or rework
- consistency between AI-delivered guidance, search results, and governed source content

## Anti-Patterns

Avoid:

- measuring maturity by article count
- copying full policies without operational translation
- publishing updates without retiring the old rule
- forcing agents to infer exception boundaries
- collecting consultation data without converting it into knowledge
- adding AI retrieval on top of unowned, stale, or contradictory content and calling it knowledge transformation

## Output Contract

State the usability failure, evidence to inspect, priority entries to rebuild, lifecycle owners, review rhythm, and operating-effect indicators.
