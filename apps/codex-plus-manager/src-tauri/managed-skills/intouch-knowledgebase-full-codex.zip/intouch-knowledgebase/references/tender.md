# Tender Playbook

Use this reference for bids, RFP responses, service proposals, staffing models, SLA design, risk control sections, and client Q&A preparation.

For standards-based governance design, supplier-selection discipline, SLA control logic, or COPC-style outsourcing governance, also read [copc-rfp-sla-governance.md](copc-rfp-sla-governance.md). When the output is in Chinese and needs stronger management phrasing for讲标、答辩或方案写法, also read [copc-management-principles-cn.md](copc-management-principles-cn.md).

## Standard Structure

1. client perspective
2. response strategy
3. service process
4. team and staffing model
5. SLA and quality assurance
6. risk control and emergency plan
7. highlights
8. Q&A

## Writing Guidance

- answer in a client-facing tone
- show operability, not empty claims
- where possible, connect service design to measurable control points
- distinguish service commitment, process mechanism, and resource guarantee
- when the user wants a stronger governance backbone, show review cadence, owner logic, escalation rules, and corrective-action verification rather than only service promises

## Typical Draft Blocks

- project understanding
- organization structure
- staffing plan
- KPI and SLA design
- QA system
- training and onboarding
- continuity and emergency response
- implementation milestones

## Typical User Requests

- 这个标书怎么答
- 帮我写RFP响应
- 人员配置怎么测算
- SLA怎么设计更稳
- 给我一版讲标Q&A
