# Business Line Deep Rules

Use this reference when the user has clearly indicated a business line, or when KPI choice, management action, reporting focus, or tender wording should change by business model.

For each business line, think through five layers:

1. core KPI
2. common management actions
3. typical risk points
4. reporting focus
5. tender wording differences

## 1. Inbound Voice Customer Service

### Core KPI

- service level
- AHT
- FCR
- CSAT
- complaint rate
- attendance and shrinkage

### Common Management Actions

- optimize scheduling by intraday traffic pattern and shrinkage
- strengthen call flow consistency and key-node probing
- review transfer and escalation reasons by agent group
- run QA plus coaching on long calls, repeat calls, and complaint-prone calls
- separate efficiency issues from process or policy issues before assigning action

### Typical Risk Points

- traffic spikes causing service level drop
- long-call accumulation dragging queue recovery
- repeat contact due to weak one-time resolution
- emotional calls escalating into complaints
- roster mismatch between peaks and actual seat availability

### Reporting Focus

- whether service level and customer experience were both protected
- whether volume fluctuation was absorbed through scheduling and floor management
- which drivers explain AHT or complaint changes
- what corrective actions are already underway

### Tender Wording Differences

- emphasize queue control, service continuity, and customer experience balance
- show call-flow control, knowledge support, and escalation management mechanisms
- describe staffing with traffic forecast, peak coverage, and shrinkage assumptions
- use language around stable delivery, customer satisfaction, and risk containment

## 2. Outbound Telesales

### Core KPI

- connect rate
- reach-to-conversation rate
- conversion rate
- output per seat
- attendance
- QA pass rate

### Common Management Actions

- segment low performance by leads, script, skill, and attendance
- optimize calling rhythm by time slot and customer segment
- strengthen objection handling and closing talk tracks
- link incentives to conversion quality, not only raw volume
- review follow-up discipline and callback closure

### Typical Risk Points

- poor lead quality being misread as execution weakness
- heavy pursuit of call volume causing low-quality conversion
- inconsistent sales scripts causing unstable performance
- compliance or wording risk in aggressive calls
- incentive design that drives short-term volume but not sustainable output

### Reporting Focus

- whether conversion moved because of lead quality, execution quality, or both
- which team or segment has the best script replication value
- whether productivity gains are sustainable or only activity inflation
- how QA and compliance are controlled while chasing output

### Tender Wording Differences

- emphasize conversion management, script governance, and sales productivity model
- show lead stratification, dialing strategy, and coaching loop
- describe performance management with clear KPI decomposition and incentives
- use language around compliant growth, conversion efficiency, and revenue support

## 3. Text Customer Service

### Core KPI

- first response timeliness
- average response time
- one-time resolution
- satisfaction
- backlog
- concurrency efficiency

### Common Management Actions

- balance queues across skills, channels, and time bands
- tune SOP, macro usage, and scenario-based response templates
- manage concurrency according to skill maturity, not uniform targets
- monitor backlog aging and unresolved tickets separately
- strengthen difficult-case escalation and cross-team handoff

### Typical Risk Points

- slow first response during peaks
- agents focusing on speed while resolution quality drops
- backlog hidden in low-priority queues
- inconsistent wording causing satisfaction swings
- excessive concurrency reducing judgment quality

### Reporting Focus

- whether timeliness and resolution are balanced
- whether backlog is structural or short-term
- how macros, SOP, or routing improved handling efficiency
- which scenarios are driving dissatisfaction or escalation

### Tender Wording Differences

- emphasize response timeliness, consistency, and channel coordination
- show routing rules, knowledge base support, and layered escalation
- describe flexible staffing for peak-hour message surges
- use language around fast response, stable experience, and process standardization

## 4. Ecommerce Customer Service

### Core KPI

- response timeliness
- order or ticket closure timeliness
- satisfaction
- refund or dispute rate
- escalation rate
- peak-period service stability

### Common Management Actions

- manage peaks around promotions, logistics events, and campaign nodes
- split scenarios by pre-sale, order status, refund, logistics, and complaints
- tighten coordination with warehouse, logistics, and platform-rule owners
- build standard responses for sensitive issues like refund and delivery delays
- monitor high-risk conversations that can trigger bad reviews or platform penalties

### Typical Risk Points

- promotion peaks overwhelming staffing and backlog control
- refund or logistics complaints rapidly damaging satisfaction
- inconsistent policy explanation creating repeated disputes
- public-platform negative feedback amplifying small failures
- cross-department dependency slowing problem closure

### Reporting Focus

- whether service held steady through peaks and campaign nodes
- how logistics, refund, and complaint cases were controlled
- whether customer sentiment risk is rising even if volume looks normal
- what cross-functional fixes are needed beyond the service team

### Tender Wording Differences

- emphasize peak assurance, order-journey support, and complaint-risk control
- show scenario-based SOPs for pre-sale, after-sale, logistics, and refund cases
- describe flexible staffing for promotions and sudden volume surges
- use language around transaction protection, brand reputation, and service resilience

## 5. AI Data Annotation

### Core KPI

- output volume
- accuracy
- rework rate
- turnaround time
- calibration pass rate
- attendance stability

### Common Management Actions

- separate productivity issues from rule-understanding issues
- run frequent calibration and edge-case clarification
- monitor rework by task type, not only by person
- strengthen sampling, review, and double-check logic
- align staffing with task complexity and deadline pressure

### Typical Risk Points

- rules changing faster than team understanding
- quality drift between shifts or reviewer groups
- high volume push causing hidden accuracy decline
- weak edge-case governance creating unstable labels
- rework consuming capacity and distorting apparent output

### Reporting Focus

- whether quality is stable enough to trust volume
- whether rework is being reduced at source rather than absorbed later
- how calibration, sampling, and reviewer consistency are functioning
- which task types create the highest quality or cycle-time risk

### Tender Wording Differences

- emphasize quality governance, calibration mechanism, and version control
- show sampling, review layers, and exception handling process
- describe staffing by complexity tier and turnaround commitment
- use language around data quality, consistency, traceability, and secure delivery

## Quick Selection Rule

When the user does not specify the business line:

- do not silently default to inbound voice customer service when the choice would change KPI, staffing, risk, or recommended action
- state a reasonable working assumption when the answer remains broadly valid
- ask one key clarification question when business-line differences materially change the solution
- switch to ecommerce support when the request centers on orders, refunds, logistics, or platform complaints
- switch to text support when the request centers on message timeliness, backlog, or concurrent handling
- switch to outbound telesales when the request centers on leads, conversion, sales scripts, or incentives
- switch to AI data annotation when the request centers on labeling rules, accuracy, rework, or calibration
