# BPO Answer Sample Validation Run 2026-07-10

> Historical baseline notice: this run was authored before the 2026-07-10 routing and high-frequency-method refactor. Its “Required route” lines describe the old validation setup and are not current live-routing requirements. Use `core-routing-table.md` for the current route. No new behavior test has been run for the refactored version.

Purpose: verify whether the skill can convert learned BPO, Customer World, contact-center, and AI-data-operations references into professional judgment and executable solutions.

Validation baseline:

- Customer World full-text articles: 1392
- External operations / AI training full-text articles: 308
- Total clean learnable articles: 1700
- Required scoring matrix: `bpo-capability-validation-matrix-cn.md`

Scoring dimensions: route, diagnosis, action, metrics, wording, source use. Each dimension is scored 0 to 2.

Pass threshold: 10 to 12. Risk: 7 to 9. Fail: 0 to 6.

## Summary Result

| Lane | Score | Result | Main Evidence |
| --- | ---: | --- | --- |
| WFM and service level | 12 | pass | separates headcount, interval fit, adherence, shrinkage, skill mix |
| QA calibration and scorecard | 12 | pass | treats calibration as governance before blaming agents |
| coaching and repeated defects | 12 | pass | converts training failure into behavior coaching and recheck loop |
| KPI review and operating rhythm | 12 | pass | moves from number reporting to variance/action closure |
| attrition and morale | 11 | pass | separates preventable loss, early-tenure risk, emotion signals |
| knowledge governance | 12 | pass | treats knowledge base as operating system, not document archive |
| client weekly report | 12 | pass | client-facing, accountable, KPI-cause-action-next checkpoint |
| RFP / service solution | 12 | pass | service model, SLA, staffing, QA, WFM, risk response |
| AI annotation quality operations | 12 | pass | separates rule clarity, reviewer consistency, task complexity, rework |
| model evaluation and benchmark governance | 12 | pass | separates benchmark score from scenario reliability and release gate |

Overall result: pass for the required 10-lane acceptance gate.

Residual caution: this validates core answer capability, not every possible BPO niche. Future improvement should continue through real user questions and weak-case capture.

## 1. WFM and Service Level

Prompt: 人不少但晚高峰服务水平扛不住，怎么判断是排班还是现场问题？

Required route: `operations.md` + `methods-metrics.md` + `external-ops-fulltext-index.md`.

Sample answer:

当前不应先判断为“人不够”，而要先拆成三个问题：总人力是否够、关键时段是否匹配、现场有效在线人力是否被折损。晚高峰服务水平扛不住，常见原因不是全天人力不足，而是来量曲线、休息窗口、技能组覆盖、缺勤和实时调度没有对齐。

建议按一周数据做排查：第一，拉出半小时粒度的来量、接通、服务水平、在线人力和排班人力，确认缺口集中在哪些时段；第二，对比排班人数、实际登录人数、有效接话人数，拆出缺勤、迟到、培训、会议、后处理和小休造成的 shrinkage；第三，检查晚高峰是否有技能错配，比如会接普通咨询的人多、能处理投诉或复杂账单的人少；第四，复盘现场 RTM 规则，确认排队超过阈值时是否有延迟支援、暂停非必要离席、跨技能支援和班组长现场干预。

一周试运行动作可以这样定：WFM 负责人每天 17:00 前发布晚高峰预测和座席缺口，运营主管负责调整休息窗口和支援名单，班组长在高峰期间每 30 分钟检查在线、排队、ACW 和异常状态。复盘指标看服务水平、放弃率、实际在线率、排班遵从率、ACW 占比和跨技能支援响应时间。

Score:

| Dimension | Score | Note |
| --- | ---: | --- |
| route | 2 | correct WFM / service-level lane |
| diagnosis | 2 | separates total headcount, interval mismatch, shrinkage, skill mix |
| action | 2 | gives owner, time band, trial rhythm |
| metrics | 2 | service level, abandonment, adherence, shrinkage, ACW |
| wording | 2 | reusable management wording |
| source use | 2 | combines operations, metrics, and WFM benchmark layer |

Result: pass, 12/12.

## 2. QA Calibration and Scorecard

Prompt: 质检分下滑，质检员之间评分也不一致，怎么拉稳？

Required route: `methods-quality.md` + `external-ops-fulltext-index.md`.

Sample answer:

这个问题要先拉稳质检机制，再谈一线改进。质检分下降同时伴随评分员差异，说明当前风险不只是坐席服务问题，还包括标准理解、样本选择、扣分尺度和争议处理不一致。

建议先做三件事：第一，抽取近两周争议样本、低分样本和边界样本，由质检主管组织校准会，统一“必须扣分、可提醒、不扣分”的边界；第二，缩短评分卡，保留服务态度、流程合规、业务准确、沟通技巧和风险控制五类核心项，减少低价值细碎扣分；第三，建立争议案例库，所有校准结论必须转成规则说明和正反例，次日同步到质检员与班组长。

后续节奏：每周固定一次校准会，每月复盘评分员偏差；对坐席侧不要只发布扣分结果，要把缺陷拆成流程、话术、系统、个人能力四类，分别给到流程 owner、培训 owner、系统支持和班组长。看板指标包括评分员一致率、争议率、复核改判率、重复缺陷率和辅导后复发率。

Score:

| Dimension | Score | Note |
| --- | ---: | --- |
| route | 2 | QA calibration lane |
| diagnosis | 2 | identifies calibration failure before agent blame |
| action | 2 | calibration, scorecard simplification, dispute library, ownership |
| metrics | 2 | consistency, dispute, overturn, repeated defect |
| wording | 2 | document-ready |
| source use | 2 | quality-method plus external QA calibration layer |

Result: pass, 12/12.

## 3. Coaching and Repeated Defects

Prompt: 培训做了但错误还是反复，主管辅导怎么改？

Required route: `methods-quality.md` + coaching entries in `external-ops-fulltext-index.md`.

Sample answer:

培训做了但错误反复，通常说明问题已经从“知不知道”进入“会不会用、有没有被追踪、现场有没有纠偏”的阶段。主管辅导要从讲课式转成行为转化式。

建议把反复错误先按人、场景、规则、流程分组。对个人短板，主管用一对一辅导：选一通典型录音或工单，先让员工复盘自己在哪一步判断错，再明确一个下周只抓的行为目标。对团队共性问题，用班前 10 分钟做场景演练，不再重复整套制度。对流程或知识缺陷，由主管把问题提交给知识库或流程 owner，不能让一线靠记忆补系统缺口。

辅导闭环要有三次检查：当天确认员工理解，三天后抽样复听或复查，两周后看重复缺陷率是否下降。指标看重复缺陷率、辅导完成率、辅导后复发率、对应场景 QA 分、客户二次来电或返工率。

Score:

| Dimension | Score | Note |
| --- | ---: | --- |
| route | 2 | coaching linked to QA |
| diagnosis | 2 | distinguishes training input from behavior conversion |
| action | 2 | one-on-one, team refresh, process escalation, recheck |
| metrics | 2 | repeated defects and post-coaching recurrence |
| wording | 2 | practical supervisor language |
| source use | 2 | quality/coaching benchmark used |

Result: pass, 12/12.

## 4. KPI Review and Operating Rhythm

Prompt: 经营会总是报数，没有改进，怎么重构？

Required route: `methods-metrics.md` + `customer-world-topic-solution-index.md` + `external-ops-fulltext-index.md`.

Sample answer:

经营会没有改进，核心不是会开得不够，而是会议停在结果展示，没有完成“变化-原因-动作-闭环”的管理链路。建议把经营会从报表会改成运营决策会。

会议结构改为四段：第一，先看本周最重要的 3 个指标变化，不铺满全部指标；第二，每个异常指标必须说明是短期波动还是结构性问题，并拆到时段、班组、场景或流程；第三，每个问题只允许带一个主 owner、一个动作、一个截止日；第四，下次会议先检查上次动作是否关闭，再看新问题。

建议用一张行动台账替代表格堆砌：指标、异常信号、主因判断、责任人、动作、完成时间、验证指标。运营节奏上，排队和服务水平做日内看，投诉和满意度做周复盘，流失、知识库、流程问题做月度机制复盘。

Score:

| Dimension | Score | Note |
| --- | ---: | --- |
| route | 2 | KPI review and operating rhythm |
| diagnosis | 2 | identifies variance interpretation and closure gap |
| action | 2 | meeting redesign, owner/action/deadline, action ledger |
| metrics | 2 | matched intraday/daily/weekly/monthly rhythms |
| wording | 2 | management-ready |
| source use | 2 | metrics and topic-routing logic used |

Result: pass, 12/12.

## 5. Attrition and Morale

Prompt: 流失高士气差，先抓离职还是情绪？

Required route: `methods-retention.md` + `methods-emotion.md` + `external-ops-fulltext-index.md`.

Sample answer:

不要把“离职”和“情绪”拆成两个孤立项目。正确顺序是先分层识别流失风险，再用情绪管理处理可逆风险。流失率高要先判断是健康流动、早期流失、关键员工流失，还是某个班组集中流失。

第一步拉 30/60/90 天员工清单，看新员工、熟练员工、骨干员工的流失分布；第二步看早期信号，包括迟到、请假、排班抵触、辅导沉默、情绪事件、质检波动；第三步由主管做 stay interview，不是泛泛关怀，而是问清工作预期、排班压力、主管沟通、客户负面情绪和成长路径。

动作上，HR 负责校准招聘画像和真实岗位预览；培训负责新员工上线前后的跟带；主管负责高风险员工周触达；OM 负责排班公平性、强压指标和班组长管理差异。指标看新员工 90 天留存率、关键员工流失率、异常出勤、排班投诉、班组间流失差异和 stay interview 完成率。

Score:

| Dimension | Score | Note |
| --- | ---: | --- |
| route | 2 | attrition and emotion route |
| diagnosis | 2 | separates attrition types and emotion signals |
| action | 2 | HR/training/supervisor/OM owner split |
| metrics | 2 | retention, attendance, schedule complaint, team variance |
| wording | 2 | usable internally |
| source use | 1 | method layer is strong; benchmark layer is less explicit in answer |

Result: pass, 11/12.

## 6. Knowledge Governance

Prompt: 知识库一直更新但一线还老问人，说明什么？

Required route: `methods-knowledge.md` + `customer-world-topic-solution-index.md`.

Sample answer:

这通常不是“知识库内容不够”，而是知识没有转成可在现场使用的判断入口。一直更新但一线还问人，说明知识库可能存在找不到、看不懂、不敢信、不会用或版本不一致的问题。

建议先查四类数据：一线高频咨询问题、知识库搜索无结果词、二线重复支持场景、因知识错误导致的 QA 扣分或重复来电。然后把知识按场景重构，而不是按部门文件堆放。每条高频知识至少要有适用场景、判断条件、处理步骤、升级边界、客户口径和失效日期。

治理机制要明确 owner：业务方负责规则有效性，知识管理员负责结构和版本，培训负责同步，班组长负责使用检查。每周复盘 Top 20 咨询原因，能沉淀的必须转成知识条目，已过期或重复的必须清理。指标看知识命中率、搜索无结果率、二线咨询重复率、FCR、AHT 和知识导致的质检缺陷。

Score:

| Dimension | Score | Note |
| --- | ---: | --- |
| route | 2 | knowledge governance |
| diagnosis | 2 | usability/search/trust/version/scenario-entry split |
| action | 2 | top question map, owner, scenario rewrite, lifecycle |
| metrics | 2 | hit rate, search miss, consultation repeat, FCR, AHT |
| wording | 2 | strong operating language |
| source use | 2 | knowledge method and topic-routing logic used |

Result: pass, 12/12.

## 7. Client Weekly Report

Prompt: 写一段甲方周报，解释满意度波动和下周动作。

Required route: `reporting.md` + `sample-library-reporting-cn.md` + relevant methods.

Sample answer:

本周项目整体服务运行保持稳定，满意度出现小幅波动，主要集中在晚高峰等待、复杂问题解释一致性及部分升级场景反馈时效三个方面。项目组已启动针对性整改：一是对高峰时段排班与休息窗口进行微调，提升关键时段承接能力；二是抽取低满意度样本开展场景复盘，统一复杂问题解释口径；三是强化班组长对升级工单的日清检查，确保客户反馈有进度、有结论、有闭环。

下周将重点跟踪满意度恢复趋势、投诉及重复来电变化、复杂场景一次解决率和升级工单处理时效。当前波动处于可控范围，项目组将于下周例会同步整改进展和首轮效果数据。

Score:

| Dimension | Score | Note |
| --- | ---: | --- |
| route | 2 | reporting and client-facing sample route |
| diagnosis | 2 | connects satisfaction to wait, explanation, escalation response |
| action | 2 | current action and next-week focus |
| metrics | 2 | satisfaction, complaints, repeat contact, FCR, escalation timeliness |
| wording | 2 | client-facing and accountable |
| source use | 2 | reporting playbook plus sample language |

Result: pass, 12/12.

## 8. RFP / Service Solution

Prompt: 客服项目投标，怎么写得像专业BPO服务商？

Required route: `tender.md` + `sample-library-client-cn.md` + relevant methods.

Sample answer:

投标不能只写“我方经验丰富、团队稳定”，要让甲方看到服务如何被组织、控制和持续改进。建议方案主线写成：项目理解、交付模型、人员配置、SLA 与质量机制、风险保障、持续优化。

可用表述：基于贵方业务的咨询量波动、客户体验要求及风险控制需求，我方将建立以稳定承接、质量闭环和持续优化为核心的服务交付体系。组织上设置项目经理、运营主管、质检培训、WFM、班组长和一线坐席的分层管理架构；流程上覆盖预测排班、上线培训、现场管理、质检校准、投诉升级、周月度复盘；指标上围绕服务水平、接通率、AHT、FCR、满意度、投诉率、质检通过率和人员稳定性建立 SLA 与预警阈值。

风险部分要写清高峰来量、系统异常、关键人员异动、投诉集中升级的分级响应机制。亮点不要堆荣誉，而要落到“指标可预警、过程可追踪、质量可复核、问题可闭环”。

Score:

| Dimension | Score | Note |
| --- | ---: | --- |
| route | 2 | proposal/RFP lane |
| diagnosis | 2 | shifts from generic capability to service mechanism |
| action | 2 | service model, staffing, QA, WFM, reporting, risk response |
| metrics | 2 | SLA and management indicators |
| wording | 2 | client-facing proposal wording |
| source use | 2 | tender and client sample layer used |

Result: pass, 12/12.

## 9. AI Annotation Quality Operations

Prompt: 标注返工率高，怎么做运营闭环？

Required route: `methods-ai-annotation.md` + `external-ops-fulltext-index.md`.

Sample answer:

标注返工率高，不能直接归因于标注员不认真。要先拆成规则、任务、人员、审核和工具五类原因：规则是否模糊，边界案例是否缺样例，任务难度是否变化，审核员是否一致，平台是否造成误操作或漏标。

建议建立返工闭环：第一，返工原因必须标签化，至少分为规则理解、漏标错标、边界判断、审核口径、工具问题、任务设计问题；第二，每个批次上线前做 gold sample 和小样本校准，校准不过不放量；第三，审核员每周做一致性校准，争议样本进入仲裁库；第四，返工超过阈值的批次暂停扩大生产，先完成规则澄清和样例补充；第五，返工复盘结果反哺 guideline 版本更新。

看板指标包括返工率、一次验收通过率、审核员一致率、gold sample 通过率、争议率、TAT、返工工时占比和批次验收通过率。

Score:

| Dimension | Score | Note |
| --- | ---: | --- |
| route | 2 | AI annotation operations lane |
| diagnosis | 2 | rule/task/people/reviewer/tool cause split |
| action | 2 | calibration, gold samples, arbitration, batch gate, guideline versioning |
| metrics | 2 | rework, acceptance, consistency, TAT, rework hours |
| wording | 2 | practical operations language |
| source use | 2 | annotation method and external data-quality layer used |

Result: pass, 12/12.

## 10. Model Evaluation and Benchmark Governance

Prompt: benchmark分数好但业务场景不稳，怎么汇报？

Required route: `methods-model-eval.md` + `external-ops-fulltext-index.md`.

Sample answer:

汇报时不要简单说 benchmark 不可靠，而要说明 benchmark 证明的是基础能力，业务场景稳定性需要另一个评测层来验证。当前判断应表述为：模型在通用或指定基准上表现较好，但在真实业务流程中的可靠性、边界处理和回归风险仍需专项验证。

建议汇报分三层：第一，benchmark 结果说明模型具备基础能力参考价值；第二，业务场景测试显示不稳的场景类型，比如多轮约束、复杂政策解释、工具调用、长上下文或敏感拒答；第三，下一步建立场景化评测集和发布门禁，包括人工复核、失败案例归因、回归监控和 blocking issue 清单。

管理动作上，由评测负责人维护场景 eval set，业务 SME 负责样本真实性和判分口径，模型或产品 owner 负责回归修复。指标看场景通过率、关键场景失败率、人工复核一致率、严重缺陷数、回归问题数和发布阻断项关闭率。

Score:

| Dimension | Score | Note |
| --- | ---: | --- |
| route | 2 | model evaluation governance lane |
| diagnosis | 2 | separates benchmark score from scenario reliability |
| action | 2 | scenario eval, human review, release gate, regression closure |
| metrics | 2 | scenario pass, severe defects, regression, blocking closure |
| wording | 2 | executive-ready risk wording |
| source use | 2 | model-eval method and benchmark governance layer used |

Result: pass, 12/12.

## Acceptance Judgment

The skill passes the required 10-lane sample validation gate because every lane scored at least 10 out of 12 and no lane has a route, diagnosis, or action score of 0.

What this proves:

- The skill can route common BPO, reporting, RFP, AI annotation, and model evaluation questions to the right knowledge layer.
- It can produce management-grade cause splits instead of generic advice.
- It can give owners, rhythms, KPIs, and reusable Chinese business wording.

What this does not prove:

- It does not prove every niche industry scenario is already mature.
- It does not replace future validation on real user tasks.
- It does not mean the corpus should never be improved.

Next operating rule:

- Treat the skill as usable for BPO professional-answer production.
- Continue capturing weak real-world prompts into future validation runs.
