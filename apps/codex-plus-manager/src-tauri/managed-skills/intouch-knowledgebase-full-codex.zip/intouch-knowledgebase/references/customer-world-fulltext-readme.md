# Customer World Full-Text Layer

This folder-level workflow adds a higher-value learning layer on top of the existing title-level seed tables, methods files, and sample libraries.

## Why this exists

The current broad harvest mainly proves:

- page-level discovery
- title-level indexing
- topic conversion into methods and samples

It does not yet provide a stable local body-text layer for the most valuable Customer World articles.

This full-text layer is meant to fix that for the highest-value sources first.

## Current strategy

Do not try to dump the whole site into the skill at once.
The goal is not whole-site completeness. The goal is stronger operations-management judgment across both classic BPO and AI data-production delivery scenarios.

Start with method-heavy and judgment-heavy full text from:

1. `ksyc` 客世原创
2. `szyc` CEO原创
3. `zjgd` 专家观点
4. `cjyj` 场景研究
5. `ftdh` 访谈对话

These are the best sources for:

- first-hand management judgment
- executive-style reasoning
- complaint, KPI, quality, and operating-rhythm methodology
- stronger industry-language grounding
- benchmark cases and transformation interviews

Do not expand the main learning layer into `hyxx`, `hyhz`, `hyyw`, or similar broad streams for now.
Those lanes are excluded from the active learning scope because they add noise faster than they improve operational judgment.

This does not mean AI-related management topics are low priority.
Keep learning and using AI data annotation, LLM data production, model-evaluation operations, and embodied-data project management whenever the question is about delivery control, quality, staffing, training, productivity, or acceptance.

## Seed list

The older first-stage curated seed file has now been superseded and may be archived for traceability:

- `customer-world-high-value-fulltext-seeds.csv`

The broader method-heavy seed file is:

- `customer-world-method-heavy-fulltext-seeds.csv`

The priority-stream seed file is:

- `customer-world-priority-stream-fulltext-seeds.csv`

The current full-text library now covers:

- `cjyj`: 966
- `ftdh`: 151
- `ksyc`: 179
- `szyc`: 35
- `zjgd`: 61
- total full-text articles: 1392

This means the local body-text layer is no longer only a small first batch.
It already contains the main method-heavy streams most likely to improve BPO judgment quality.

The current seed logic prioritizes content across:

- complaints and escalation
- management rhythm and analysis meetings
- attrition and team stability
- quality, AHT, and customer interaction quality
- WFM, complexity, and operating design
- AI collaboration, standards, and future BPO form
- experience and customer-success framing

For routing, also read:

- `customer-world-fulltext-index.md`

## Fetch tool

Use:

- `tools/fetch-customer-world-fulltext.ps1`

This script stores each article as:

- one `.md` file for human reading
- one `.json` file for structured reuse

under:

- `references/customer-world-fulltext/`

## Working rule

Use the full-text layer when:

- the answer needs stronger first-hand Customer World grounding
- the skill is learning a new high-value topic
- a method file needs to be deepened from original source language

Do not require full text for every answer.
Use it as a quality-upgrade layer, not as the only usable knowledge form.

## Next expansion rule

If the skill continues expanding, keep going deeper inside the existing method-heavy streams first:

1. better coverage conversion for operations-management topics from `cjyj`
2. stronger first-hand judgment extraction from `ksyc` and `szyc`
3. denser benchmark and management interview extraction from `ftdh` and `zjgd`

Do not reopen `hyxx`, `hyhz`, or `hyyw` as active download targets unless the learning goal itself changes.
