# Customer World Harvest Progress

Use this file to track concrete harvesting progress toward broader Customer World coverage.

This is a collection-progress note, not a management-method file.

Current practical rule:

- the skill actively learns in depth from `cjyj`, `ftdh`, `ksyc`, `szyc`, and `zjgd`
- `hyxx`, `hyhz`, `hyyw`, and `jrm` remain exported seed lanes or context lanes
- they are not the current main full-text learning target

## Current Exported Seeds

The active learning path no longer relies on every exported category slice equally.

Current status:

- active method-heavy learning lanes: `cjyj`, `ftdh`, `ksyc`, `szyc`, `zjgd`
- archived or context-only seed lanes: `hyxx`, `hyhz`, `hyyw`, `jrm`

The following category slices have already been exported into CSV seed lists under `references/`:

- `customer-world-zjgd-p1-p4.csv`
  - scope: expert viewpoints pages 1-4
  - exported rows: 61
- `customer-world-ftdh-p1-p5.csv`
  - scope: interview dialogue pages 1-5
  - exported rows: 100
- `customer-world-ftdh-p6-p8.csv`
  - scope: interview dialogue pages 6-8
  - exported rows: 51
- `customer-world-cjyj-p1-p5.csv`
  - scope: scenario research pages 1-5
  - exported rows: 100
- `customer-world-cjyj-p6-p15.csv`
  - scope: scenario research pages 6-15
  - exported rows: 200
- `customer-world-cjyj-p16-p25.csv`
  - scope: scenario research pages 16-25
  - exported rows: 200
- `customer-world-cjyj-p26-p35.csv`
  - scope: scenario research pages 26-35
  - exported rows: 200
- `customer-world-cjyj-p36-p45.csv`
  - scope: scenario research pages 36-45
  - exported rows: 200
- `customer-world-cjyj-p46-p49.csv`
  - scope: scenario research pages 46-49
  - exported rows: 66
- `customer-world-hyxx-p1-p5.csv`
  - scope: member information pages 1-5
  - exported rows: 100
- `customer-world-hyxx-p6-p15.csv`
  - scope: member information pages 6-15
  - exported rows: 200
- `customer-world-hyxx-p16-p25.csv`
  - scope: member information pages 16-25
  - exported rows: 200
- `customer-world-hyxx-p26-p35.csv`
  - scope: member information pages 26-35
  - exported rows: 200
- `customer-world-hyxx-p36-p45.csv`
  - scope: member information pages 36-45
  - exported rows: 200
- `customer-world-hyxx-p46-p55.csv`
  - scope: member information pages 46-55
  - exported rows: 200
- `customer-world-hyxx-p56-p65.csv`
  - scope: member information pages 56-65
  - exported rows: 200
- `customer-world-hyxx-p66-p75.csv`
  - scope: member information pages 66-75
  - exported rows: 200
- `customer-world-hyxx-p76-p85.csv`
  - scope: member information pages 76-85
  - exported rows: 200
- `customer-world-hyxx-p86-p95.csv`
  - scope: member information pages 86-95
  - exported rows: 200
- `customer-world-hyxx-p96-p105.csv`
  - scope: member information pages 96-105
  - exported rows: 200
- `customer-world-hyxx-p106-p115.csv`
  - scope: member information pages 106-115
  - exported rows: 200
- `customer-world-hyxx-p116-p121.csv`
  - scope: member information pages 116-121
  - exported rows: 108
- `customer-world-hyhz-p1-p5.csv`
  - scope: conferences and exhibitions pages 1-5
  - exported rows: 100
- `customer-world-hyhz-p6-p15.csv`
  - scope: conferences and exhibitions pages 6-15
  - exported rows: 200
- `customer-world-hyhz-p16-p25.csv`
  - scope: conferences and exhibitions pages 16-25
  - exported rows: 200
- `customer-world-hyhz-p26-p35.csv`
  - scope: conferences and exhibitions pages 26-35
  - exported rows: 200
- `customer-world-hyhz-p36-p45.csv`
  - scope: conferences and exhibitions pages 36-45
  - exported rows: 200
- `customer-world-hyhz-p46-p55.csv`
  - scope: conferences and exhibitions pages 46-55
  - exported rows: 200
- `customer-world-hyhz-p56-p65.csv`
  - scope: conferences and exhibitions pages 56-65
  - exported rows: 200
- `customer-world-hyhz-p66-p75.csv`
  - scope: conferences and exhibitions pages 66-75
  - exported rows: 200
- `customer-world-hyhz-p76-p85.csv`
  - scope: conferences and exhibitions pages 76-85
  - exported rows: 200
- `customer-world-hyhz-p86-p95.csv`
  - scope: conferences and exhibitions pages 86-95
  - exported rows: 200
- `customer-world-hyhz-p96-p105.csv`
  - scope: conferences and exhibitions pages 96-105
  - exported rows: 200
- `customer-world-hyhz-p106-p114.csv`
  - scope: conferences and exhibitions pages 106-114
  - exported rows: 164
- `customer-world-hyyw-p1-p5.csv`
  - scope: industry news pages 1-5
  - exported rows: 100
- `customer-world-hyyw-p6-p15.csv`
  - scope: industry news pages 6-15
  - exported rows: 200
- `customer-world-hyyw-p16-p25.csv`
  - scope: industry news pages 16-25
  - exported rows: 200
- `customer-world-hyyw-p26-p35.csv`
  - scope: industry news pages 26-35
  - exported rows: 200
- `customer-world-hyyw-p36-p45.csv`
  - scope: industry news pages 36-45
  - exported rows: 200
- `customer-world-hyyw-p46-p55.csv`
  - scope: industry news pages 46-55
  - exported rows: 200
- `customer-world-hyyw-p56-p65.csv`
  - scope: industry news pages 56-65
  - exported rows: 200
- `customer-world-hyyw-p66-p75.csv`
  - scope: industry news pages 66-75
  - exported rows: 200
- `customer-world-hyyw-p76-p85.csv`
  - scope: industry news pages 76-85
  - exported rows: 200
- `customer-world-hyyw-p86-p95.csv`
  - scope: industry news pages 86-95
  - exported rows: 200
- `customer-world-hyyw-p96-p105.csv`
  - scope: industry news pages 96-105
  - exported rows: 200
- `customer-world-hyyw-p106-p115.csv`
  - scope: industry news pages 106-115
  - exported rows: 200
- `customer-world-hyyw-p116-p125.csv`
  - scope: industry news pages 116-125
  - exported rows: 200
- `customer-world-hyyw-p126-p135.csv`
  - scope: industry news pages 126-135
  - exported rows: 200
- `customer-world-hyyw-p136-p145.csv`
  - scope: industry news pages 136-145
  - exported rows: 200
- `customer-world-hyyw-p146-p155.csv`
  - scope: industry news pages 146-155
  - exported rows: 200
- `customer-world-hyyw-p156-p165.csv`
  - scope: industry news pages 156-165
  - exported rows: 200
- `customer-world-hyyw-p166-p173.csv`
  - scope: industry news pages 166-173
  - exported rows: 141
- `customer-world-jrm-p1-p1.csv`
  - scope: Golden Headset related content page 1
  - exported rows: 11
- `customer-world-ksyc-p1-p9.csv`
  - scope: customer world original-article stream pages 1-9
  - exported rows: 179
- `customer-world-szyc-p1-p2.csv`
  - scope: CEO original-article stream pages 1-2
  - exported rows: 35

## Combined Seed Table

A combined deduplicated seed table has already been generated:

- `customer-world-master-seed.csv`
- current unique rows observed: 9516

This seed table is useful for:

- spotting high-value article clusters
- avoiding duplicate manual indexing
- deciding which categories to deepen next

If archived later for cleanup, it should be treated as a historical data asset rather than an active routing file.

## Current Full-Text Learning Boundary

The main method-heavy full-text learning set now covers:

- `cjyj`: 966
- `ftdh`: 151
- `ksyc`: 179
- `szyc`: 35
- `zjgd`: 61
- total full-text articles: 1392

Supporting seed files:

- `customer-world-priority-stream-fulltext-seeds.csv`
- `customer-world-method-heavy-fulltext-seeds.csv`

## What This Means

The skill is no longer relying only on hand-added articles or title-level indexing.

It now has:

1. a topic index for reusable management learning
2. a site map for category discovery
3. a seed-table layer for broader article harvesting
4. a method-heavy full-text layer for direct learning and problem handling

At this point:

- `ftdh` has been harvested through its visible last page range `1-8`
- `zjgd` has been harvested through its currently visible range `1-4`
- `cjyj` has been harvested through its visible last page range `1-49`
- `hyxx` has been harvested through its visible last page range `1-121`
- `hyyw` has been harvested through its visible last page range `1-173`
- `hyhz` has been harvested through its visible last page range `1-114`
- `jrm` has been harvested through its visible last page range `1-1`
- `ksyc` has been harvested through its visible last page range `1-9`
- `szyc` has been harvested through its visible range `1-2`

## Recommended Next Harvest Order

Under the current skill strategy, do not expand broad full-text harvesting by default.

The higher-value next steps are:

1. continue converting the 1392-article method-heavy full-text set into stronger methods, solution packs, and route wording
2. deepen weaker practical lanes such as service innovation, multichannel, and some AI-era transformation sub-scenarios
3. improve short-question routing and acceptance testing
4. only expand new full-text lanes if they clearly improve BPO judgment quality rather than just increasing collection size

## Working Rule

Do not try to fully absorb all harvested rows in one pass.

A better pattern is:

1. export a category slice
2. identify high-value management articles
3. convert those into index entries, methods, or sample phrasing
4. repeat
