# Knowledge Governance Summary

Use this summary for corpus maintenance. Do not load the full manifest for routine BPO answers.

- generated_at: 2026-07-10T18:37:55+08:00
- total_records: 1700
- customer_world_records: 1392
- external_records: 308
- load_errors: 0
- missing_urls: 0
- duplicate_url_records: 0
- manifest: `knowledge-governance-manifest.csv`

The classifications are deterministic triage labels. They support maintenance and retrieval, but they do not replace manual review before promoting an article into a `methods-*.md` file.

Customer World publication dates concentrated in 2026 are marked with low confidence and should be verified against the source page before date-sensitive use.

## Governance Observations

- Source concentration: Customer World contributes 1392 records (81.9%); use external or official corroboration when a claim should not depend on one ecosystem.
- Date review queue: 1299 records (76.4%) have low-confidence or missing publication dates.
- Topic review queue: 104 records (6.1%) remain in general BPO context and need manual topic review only when they become operationally relevant.
- Vendor-controlled content: 80 records (4.7%) are explicitly marked as vendor viewpoints and require corroboration.
- Method-promotion queue: 149 records (8.8%) are high-priority candidates for manual extraction into the method layer.

## Source Levels

| Value | Count |
| --- | ---: |
| B | 1547 |
| C | 80 |
| A | 73 |

## Sources

| Value | Count |
| --- | ---: |
| Customer World | 1392 |
| 51callcenter | 112 |
| nda | 73 |
| appen | 31 |
| callcentrehelper | 22 |
| superannotate | 21 |
| icmi | 21 |
| surge | 13 |
| scale | 11 |
| aliyun | 3 |
| labelbox | 1 |

## Content Types

| Value | Count |
| --- | ---: |
| scene_research_or_case | 966 |
| professional_method | 366 |
| interview_or_case | 151 |
| vendor_method_or_viewpoint | 79 |
| expert_opinion | 61 |
| official_case | 49 |
| official_guidance | 24 |
| professional_case | 3 |
| vendor_case | 1 |

## Freshness Classes

| Value | Count |
| --- | ---: |
| review_periodically | 1308 |
| stable_method | 381 |
| verify_current | 11 |

## Date Confidence

| Value | Count |
| --- | ---: |
| low | 1245 |
| high | 359 |
| missing | 54 |
| medium | 42 |

## Primary Topics

| Value | Count |
| --- | ---: |
| BPO外包与交付 | 293 |
| 满意度与客户体验 | 273 |
| 投诉与升级治理 | 228 |
| 技术平台与数字化 | 134 |
| 通用BPO背景 | 104 |
| AI标注与数据生产 | 95 |
| 培训与辅导 | 93 |
| 流失情绪与稳定 | 82 |
| KPI与经营分析 | 80 |
| WFM排班与人力 | 70 |
| 知识与流程治理 | 63 |
| 政务热线与公共服务 | 41 |
| 质检与质量管理 | 38 |
| 班组长与现场管理 | 37 |
| 多渠道与智能客服 | 36 |
| 模型评测运营 | 22 |
| LLM数据生产 | 11 |

## Business Lines

| Value | Count |
| --- | ---: |
| cross_bpo_or_unspecified | 908 |
| inbound_voice | 558 |
| ai_annotation | 104 |
| outbound_telesales | 71 |
| public_hotline | 69 |
| model_evaluation | 30 |
| text_support | 26 |
| ecommerce_support | 18 |
| llm_data_production | 18 |
| embodied_data | 3 |

## Vendor Stance

| Value | Count |
| --- | ---: |
| possible | 1117 |
| no | 503 |
| yes | 80 |

## Promotion Candidates

| Value | Count |
| --- | ---: |
| low | 970 |
| medium | 581 |
| high | 149 |

## Manual Review Reasons

| Value | Count |
| --- | ---: |
| date_needs_check | 1299 |
| possible_commercial_context | 1117 |
| none | 232 |
| topic_unclassified | 104 |
| vendor_corroboration | 28 |
