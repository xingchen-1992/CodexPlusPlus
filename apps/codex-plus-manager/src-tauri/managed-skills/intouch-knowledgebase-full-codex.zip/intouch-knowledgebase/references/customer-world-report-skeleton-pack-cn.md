# Customer World Report Skeleton Pack CN

Use this file when the user wants:

- 一整套月报骨架
- 一整套复盘骨架
- 一整套专项方案目录
- Word/PPT的完整结构框架

This file is for full report skeletons and deck/page outlines.

## How To Use

Recommended use:

1. identify the deliverable type
2. choose the matching skeleton
3. fill each section with the related packs already built

Typical asks:

- 给我一个月报结构
- 做一套复盘汇报骨架
- 专项方案目录怎么搭
- 给我整套PPT提纲

## Skeleton 1: 月度经营汇报骨架

1. 项目整体运行结论
2. 核心KPI表现与趋势
3. 本月亮点与积极变化
4. 主要问题与原因判断
5. 重点专项推进情况
6. 风险提示与关键关注点
7. 下月重点动作与节点安排

### 适配说明

- 适合内部管理层月报
- 也适合做成7页左右PPT

## Skeleton 2: 周度运营复盘骨架

1. 本周运行总体判断
2. 重点指标波动情况
3. 本周异常问题与原因拆解
4. 已启动改善动作
5. 未关闭风险与下周重点

### 适配说明

- 适合周会、经营分析会、班子会
- 也适合做成3至5页简版材料

## Skeleton 3: 甲方月度汇报骨架

1. 项目整体运行情况
2. 核心服务指标表现
3. 本月重点工作推进
4. 阶段性波动项与应对动作
5. 风险控制与服务保障
6. 下阶段重点优化方向

### 适配说明

- 口径偏稳、偏正式
- 适合客户月会或例行汇报

## Skeleton 4: 质量与投诉专项复盘骨架

1. 专项背景与当前表现
2. 问题集中场景分析
3. 根因判断与共因识别
4. 已采取措施与当前进展
5. 后续专项动作与复核节点
6. 预期效果与观察指标

### 适配说明

- 适合投诉压降、质检提升、服务感知修复专题

## Skeleton 5: 人员稳定性专项骨架

1. 稳定性现状与风险判断
2. 流失/出勤/情绪结构分析
3. 主要原因与关键断点
4. 阶段目标与改善主线
5. 重点动作与责任分工
6. 推进节奏与观察指标

### 适配说明

- 适合流失专项、班组稳定专项、招聘承接专项

## Skeleton 6: 班组长能力提升专项骨架

1. 能力现状与问题判断
2. 核心短板识别
3. 能力建设目标
4. 带教路径与训练动作
5. 过程跟踪与阶段评估
6. 预期成果与落地要求

### 适配说明

- 适合班组长训练营、主管带教、基层管理升级

## Skeleton 7: 转型/数字化复盘骨架

1. 建设进展与阶段结论
2. 当前价值释放情况
3. 主要短板与阻滞点
4. 收益归因与经营解释
5. 机制固化与长期治理安排
6. 下阶段关键推进方向

### 适配说明

- 适合AI、数字化、CRM、智能排班、服务创新等主题

## Skeleton 8: 专项整改方案骨架

1. 项目背景
2. 当前问题与风险判断
3. 根因分析
4. 整改目标
5. 整改主线与重点动作
6. 推进节奏与责任分工
7. 观察指标与复核机制

### 适配说明

- 适合大多数专题方案
- 是最通用的一套交付型结构

## Fill Guidance

### 标题怎么补

Use:

- `customer-world-weekly-monthly-conclusion-pack-cn.md`
- `customer-world-executive-report-pack-cn.md`

### 结论怎么补

Use:

- `customer-world-weekly-monthly-conclusion-pack-cn.md`
- `customer-world-client-review-pack-cn.md`

### 原因怎么补

Use:

- `customer-world-root-cause-judgment-pack-cn.md`

### 正文怎么补

Use:

- `customer-world-solution-playbook-cn.md`
- `customer-world-special-plan-pack-cn.md`

### 单页怎么补

Use:

- `sample-library-reporting-cn.md`
- `customer-world-kpi-commentary-pack-cn.md`

## Final Rule

When the user wants a complete deck or document structure, use this file before designing a fresh outline.
