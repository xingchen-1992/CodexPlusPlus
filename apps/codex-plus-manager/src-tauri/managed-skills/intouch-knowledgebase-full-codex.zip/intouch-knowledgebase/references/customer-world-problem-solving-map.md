# Customer World Problem-Solving Map

Use this file when the real goal is not to prove archive coverage, but to turn Customer World learning into direct management action, solution writing, and report output.

This is the practical bridge from "learned content" to "problem handling."

## Core Use

When a user raises a management problem, do not answer from article accumulation logic.

Answer from this chain:

1. identify the problem type
2. choose the matching method lens
3. convert it into management action
4. express it in a document-ready way

For a direct Chinese draft package, also read:

- [customer-world-solution-playbook-cn.md](customer-world-solution-playbook-cn.md)
- [customer-world-solution-variants-cn.md](customer-world-solution-variants-cn.md)

## High-Frequency Problem Map

| Problem Scenario | Main Method Lens | Core Management Judgment | First Action Set | Best Output Form |
| --- | --- | --- | --- | --- |
| team attrition is high | `methods-retention.md`, `methods-emotion.md`, `methods-teamlead.md`, `methods-performance.md` | attrition is usually a system problem across hiring, onboarding, supervisor, scheduling, and incentive design | split healthy vs preventable attrition, focus on first-90-day loss, build high-risk roster, tighten supervisor retention action | retention improvement plan, monthly review, team diagnosis |
| new hires leave quickly | `methods-retention.md`, `methods-training.md` | early loss usually means selection mismatch or onboarding failure | review job preview, pilot nesting success, coach first-line leaders, add tenure checkpoints | onboarding improvement plan, training review |
| QA score drops or complaints rise | `methods-quality.md`, `methods-complaints.md`, `methods-knowledge.md` | quality problems must be split into rule, process, tool, and people causes | run defect classification, calibration, coaching route split, root-cause closure | quality improvement plan, QA review PPT |
| KPI is unstable and managers say execution is weak | `methods-metrics.md`, `methods-teamlead.md` | execution weakness usually means target translation and follow-up rhythm are weak | break KPI into daily action, assign owner, build intraday check and weekly close-loop | operations recovery plan, weekly management report |
| schedule pressure causes morale and service risk | `methods-metrics.md`, `methods-emotion.md`, `methods-teamlead.md` | WFM cannot be managed only as occupancy; people tolerance and fairness matter | check shrinkage, shift fairness, peak coverage, relief actions, emotional watchlist | staffing adjustment plan, shift review |
| customer satisfaction is flat but productivity pressure is high | `methods-experience.md`, `methods-quality.md`, `methods-performance.md` | one-number management usually creates hidden service loss | rebalance score priorities, identify perception gaps, add experience checkpoints | service improvement proposal, client summary |
| team leads are weak | `methods-teamlead.md`, `methods-training.md`, `methods-performance.md` | frontline leaders are the translation layer between KPI and behavior | split capability stages, define daily routines, strengthen one-to-one coaching and exception closure | team-lead enablement plan, supervisor bootcamp |
| knowledge updates are not landing | `methods-knowledge.md`, `methods-quality.md`, `methods-training.md` | knowledge failure is often a governance and adoption problem, not only a document problem | tighten versioning, scenario indexing, release rhythm, post-release QA checks | knowledge governance plan, SOP refresh report |
| complaint escalation repeats | `methods-complaints.md`, `methods-quality.md`, `methods-experience.md` | repeated complaints often reflect expectation mismatch and closure weakness | classify root cause, define sensitive scenarios, tighten callback and closure wording | complaint reduction plan, escalation review |
| complaint governance needs to move from passive handling to active prevention | `methods-complaints.md`, `methods-experience.md`, `methods-knowledge.md` | complaint spikes usually show repeated defects in expectation-setting, closure, or trust-boundary governance | build complaint classification, high-risk scenario warning, proactive closure and repeat-problem review | complaint governance plan, monthly review, client update |
| knowledge base is large but frontline still cannot use it well | `methods-knowledge.md`, `methods-quality.md`, `methods-training.md` | knowledge problems are usually governance and usability problems rather than content-count problems | extract high-frequency consultations, rebuild scenario entries, tighten version ownership, review usage results | knowledge governance plan, SOP refresh, ops review |
| public hotline closure quality is weak or repeated appeals stay high | `methods-hotline.md`, `methods-complaints.md`, `methods-digital-governance.md` | hotline value depends on closure quality, coordination, and public trust rather than intake speed alone | tighten unified intake, routing discipline,督办 follow-up, feedback credibility | hotline governance plan, closure-quality review, public-service report |
| hotline faces a sudden hotspot, public-opinion spike, or high-impact issue cluster | `methods-hotline.md`, `methods-digital-governance.md`, `methods-complaints.md` | special-event handling requires faster escalation, unified wording, and governance-grade coordination rather than normal case-flow logic | identify hotspot early, trigger special supervision, align wording, prioritize callback and high-risk follow-up | emergency hotline response plan, special-supervision report, public-trust stabilization brief |
| hotline must coordinate across regions or prepare for major-event drills | `methods-hotline.md`, `methods-digital-governance.md` | resilience comes from unified standards, linked escalation paths, and repeated drill closure rather than ad hoc heroics | unify intake rules, define regional linkage, drill graded events, close drill gaps into SOP | cross-region coordination plan, drill mechanism, resilience review |
| digital transformation looks busy but management effect is weak | `methods-digital-governance.md`, `methods-tech-enablement.md`, `methods-service-innovation.md` | system launch without rule redesign or action linkage is false transformation | diagnose maturity stage, reconnect data to actions, clarify operating ownership, verify real gains | maturity assessment, governance roadmap, transformation review |
| service innovation sounds good but is hard to prove | `methods-service-innovation.md`, `methods-selfservice.md`, `methods-tech-enablement.md` | innovation matters only when it simplifies customer path and improves controllable delivery | redesign path, unify cross-channel rules, improve human takeover, prove repeatable value | innovation proposal, transformation roadmap, executive review |
| one transformation story must fit very different industries | `methods-service-innovation.md`, `methods-selfservice.md`, `methods-tech-enablement.md`, `methods-multichannel.md` | transformation only becomes practical after the industry-specific pain point and risk logic are made explicit | split industry pattern, identify primary scene, redesign role and control point, prove value with industry KPIs | industry-specific transformation plan, scenario roadmap, executive review |
| transformation keeps moving but leaders ask whether it is really worth it | `methods-service-innovation.md`, `methods-tech-enablement.md`, `methods-digital-governance.md` | value proof requires baseline, benefit classification, and long-cycle governance rather than launch stories alone | build benefit ledger, split experience/efficiency/risk gains, verify by stage, institutionalize review rhythm | transformation value review, ROI-style proof pack, long-cycle governance plan |
| need a better client-facing service solution | `methods-service-innovation.md`, `methods-tech-enablement.md`, `methods-multichannel.md` | a good solution must show mechanism, resource guarantee, and measurable control | define service model, SLA, governance rhythm, tech support, risk handling | proposal, RFP response, client PPT |
| AI annotation quality is unstable | `methods-ai-annotation.md`, `methods-model-eval.md`, `methods-training.md` | annotation delivery is a calibration and rework-control business, not just labor supply | clarify guideline, run pilot, sample, arbitration, and error-family tracking | quality improvement plan, delivery review |
| large-model training data quality is unstable | `methods-llm-ops.md`, `methods-model-eval.md` | LLM data ops is a versioned pipeline, not a volume-only labeling job | split data type, tighten rubric, agreement, arbitration, and feedback loop | LLM data operations plan, training quality review |
| embodied-robotics training delivery is hard to stabilize | `methods-embodied-ops.md`, `methods-model-eval.md`, `methods-training.md` | embodied training depends on scenario coverage, trajectory quality, and replayable standards | define scenario pack, data-collection standard, QA gate, exception replay, version traceability | embodied training operations plan, capability build roadmap |

## Problem-to-Action Translation Rules

### 1. Do not answer only at concept level

Each problem answer should include:

- cause split
- action owner
- time rhythm
- indicator watchpoints
- follow-up output

### 2. Prefer "mechanism plus action" over "point suggestions"

Weak answer:

- care more about employees
- strengthen management
- improve training

Stronger answer:

- build first-30-day and first-90-day attrition checkpoints
- assign team leads a weekly stay-interview roster
- separate new-hire attrition, key-performer attrition, and avoidable attrition in review

### 3. Convert article knowledge into reusable management modules

The most reusable modules are:

- diagnosis framework
- action package
- KPI watchpoint set
- report wording
- proposal wording
- coaching script
- full-scenario solution package

## Standard Output Conversion

When using Customer World knowledge, prefer converting it into one of these output types:

### 1. Management diagnosis

Use when the user asks:

- why is this happening
- what is the root cause
- where should we start

Standard structure:

1. problem definition
2. likely cause split
3. current risk
4. priority action
5. tracking indicators

### 2. Improvement plan

Use when the user asks:

- how to solve it
- give me a plan
- how to reduce attrition / complaints / QA issues

Standard structure:

1. target
2. root-cause diagnosis
3. action by module
4. owner and timeline
5. KPI and review rhythm

### 3. Reporting wording

Use when the user asks:

- write for weekly report
- monthly review
- client update

Standard structure:

1. current status
2. trend
3. issue and cause
4. corrective action
5. next-step plan

### 4. Proposal or solution wording

Use when the user asks:

- write a solution
- make it more professional
- use it in bidding or client communication

Standard structure:

1. client pain point
2. service model
3. control mechanism
4. KPI/SLA
5. risk response
6. differentiated value

## Priority Scenarios For This Knowledge Base

Based on the current learning depth, the strongest practical problem lanes now are:

1. attrition and stability management
2. quality and complaint improvement
3. frontline execution and team-lead management
4. KPI variance and operating rhythm
5. customer experience and service perception
6. knowledge governance and rule frontloading
7. public hotline closure and public-trust governance
8. digital maturity and transformation governance
9. service innovation and contact-center evolution
10. AI annotation delivery management
11. LLM data production and evaluation operations
12. embodied-training operations management

## Working Rule

If the user says only one sentence such as:

- our attrition is high
- quality is getting worse
- team leads are weak
- data labeling quality is unstable

do not respond with abstract theory.

Default to:

1. diagnosis
2. action package
3. tracking indicators
4. document-ready wording

That is the real value of Customer World learning.
