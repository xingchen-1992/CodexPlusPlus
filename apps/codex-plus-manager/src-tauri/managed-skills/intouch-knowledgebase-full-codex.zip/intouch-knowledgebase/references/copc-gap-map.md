# COPC Gap Map for Intouch

Use this file when adapting COPC to the current Intouch method library or when deciding where COPC should strengthen existing methods.

## Mapping Rule

Do not create a parallel COPC method set. Map COPC ideas into the smallest existing method surface that already owns the topic.

## Coverage Map

| COPC theme | Current Intouch coverage | Judgment |
| --- | --- | --- |
| KPI portfolio, variance, target review | `methods-metrics.md` | strong base, needed stronger scorecard-governance logic |
| QA, calibration, defect closure | `methods-quality.md` | strong base, needed tighter link to customer drivers and output-versus-reason design |
| WFM, staffing, interval control | `methods-wfm.md` | already strong, no major COPC-only gap for now |
| Knowledge and governed answers | `methods-knowledge.md` | already strong, COPC mainly reinforces rather than changes it |
| Coaching and capability transfer | `methods-training.md` | strong base, already close to COPC intent |
| Satisfaction and customer experience | `methods-experience.md` | good base, needed stronger service-journey and key-driver framing |
| AI, self-service, technology governance | `methods-selfservice.md`, `methods-tech-enablement.md`, AI methods | partially covered, COPC can later strengthen unified human-plus-AI governance |
| Whole-operation standards framework | no dedicated file | clear gap; add `copc-core.md` |

## Net-New Additions Worth Keeping

These are the COPC ideas that materially improve Intouch and are worth preserving:

- one unified management framework across people, channels, and technology
- service-journey design as an operating control, not only a mapping exercise
- program-level scorecard versus agent-level coaching scorecard distinction
- root-cause analysis prepared before the formal review meeting
- common scorecard architecture across sites or programs with local targets inside it
- corrective action as a governed loop with verification, not only an action list

## Ideas To Avoid Overloading

Do not expand Intouch with these unless the user explicitly asks:

- certification mechanics and exam-oriented terminology
- clause-by-clause standard summaries
- long definitions that do not change operating judgment
- duplicate topic files when an existing `methods-*.md` file already owns the issue

## Current Update Decision

For the current COPC absorption pass:

1. add `copc-core.md`
2. route COPC questions through `core-routing-table.md`
3. strengthen `methods-metrics.md`
4. strengthen `methods-quality.md`
5. strengthen `methods-experience.md`
6. leave other methods unchanged unless a later real-use gap appears
