# AI Annotation Operations Method

Use for annotation staffing, productivity, quality, calibration, reviewer consistency, rework, batch acceptance, guideline governance, and client reporting.

## Management Judgment

Manage annotation as a quality-throughput-delivery system. Before blaming annotators, determine whether the loss comes from guideline clarity, task design, edge cases, reviewer consistency, tooling, skill, or unrealistic production pressure.

## Cause Structure

Classify issues across:

- guideline: ambiguity, missing boundaries, weak examples, or uncontrolled version change
- task design: mixed difficulty, poor decomposition, unclear unit, or unsuitable workflow
- workforce: skill mismatch, learning curve, fatigue, attendance, or coaching gap
- reviewer: inconsistent judgment, weak evidence, or slow arbitration
- tool: interface, latency, shortcut, data rendering, or submission defect
- production mechanism: volume target conflicts with quality or acceptance gate
- source data: low quality, missing context, or unrepresentative distribution

## Delivery-Control Chain

Use this sequence:

1. define task unit, acceptance rule, severity, and batch gate
2. version the guideline and publish changed boundary examples
3. run training, gold-sample, and small-batch calibration
4. segment work by complexity and capability
5. sample in process using risk-based rules
6. review, arbitrate, and record disputed cases
7. tag rework reasons and feed them into guideline, task, reviewer, tool, or staffing correction
8. accept or stop the batch using explicit criteria

## Immediate and Structural Actions

- immediate: pause expansion of a failing batch, isolate cause, clarify boundaries, recalibrate reviewers, and protect delivery dates
- structural: improve task design, capability tiers, reviewer standards, arbitration library, tool controls, and batch acceptance rules

Do not hide capacity consumed by rework. Report accepted output and rework hours separately from gross production.

## Ownership

- project/operations owner: delivery balance, priority, staffing, and client communication
- guideline or SME owner: rule accuracy and edge-case decisions
- training/calibration owner: readiness and change reinforcement
- reviewer/QA owner: sampling, consistency, evidence, and arbitration
- tool/data owner: platform and source-data defects
- team lead: daily productivity, behavior, and first-level coaching

## Rhythm

- before batch: guideline, sample, readiness, and acceptance confirmation
- intraday/daily: output, quality signal, backlog, rework, and risk review
- weekly: reviewer consistency, dispute taxonomy, and structural causes
- after version change: mandatory recalibration before normal scale resumes
- batch close: acceptance, rework, capacity, and lesson review

## Metrics and Signals

- gross output and accepted output
- first-pass yield or acceptance rate
- accuracy with definition and sampling method
- rework rate and rework hours
- reviewer consistency, dispute, and overturn rate
- gold-sample and calibration pass
- TAT, backlog, and batch-gate attainment
- quality and productivity by complexity tier

## Anti-Patterns

Avoid:

- using a single accuracy number without sampling and severity context
- blaming annotators before checking guideline and reviewer drift
- measuring productivity from gross output while hiding rework
- changing rules without version, effective date, and examples
- scaling a batch before calibration and acceptance criteria are stable

## Output Contract

State the quality-throughput judgment, cause layer, immediate batch action, structural control, owner, rhythm, and accepted-output plus rework indicators.
