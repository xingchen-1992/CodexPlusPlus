# Prompt compiler

Convert the user's request and the selected layout blueprint into a concise, executable CRS IMAGE production brief. Match the visual-quality class of ChatGPT web image output without changing the user's meaning or inventing claims. Do not interpret “web” as website or UI design.

## Compilation order

1. Use case, audience, and page thesis
2. Exact approved content
3. Primary visual and image treatment
4. Layout blueprint and visual hierarchy
5. Reading path and spatial layers
6. Color, light, material, and typography
7. Constraints and explicit avoid list

## Prompt scaffold

```text
Use case: <image-PPT page, infographic, poster, cover, etc.>
Audience and purpose: <who sees it and what they should understand>
Page thesis: <one conclusion the image must communicate>
Canvas: <ratio, resolution intent, outer safe area>

Exact approved content:
- Title: "<verbatim>"
- Key statement: "<verbatim>"
- Labels and data: "<verbatim items>"
- No other text is allowed unless explicitly listed.

Primary visual:
- Subject or scene: <what carries the main narrative>
- Position and area: <for example, right 60% of canvas or full-bleed lower two-thirds>
- Crop and viewpoint: <wide, close, elevated, edge crop, subject direction>
- Narrative role: <what the image proves or communicates>

Layout blueprint:
- First focal point: <dominant image, conclusion, or number>
- Second focal point: <supporting evidence or statement>
- Title and text safe zone: <position, width, contrast protection>
- Key-data position: <anchored relationship to primary visual>
- Visual weights: <dominant/support/detail proportions; never equal by default>
- Reading order: <first -> second -> third>
- Primary whitespace: <where it remains and what it protects>

Spatial layers:
- Foreground: <purposeful element or empty framing>
- Midground: <main subject and information relationship>
- Background: <environment, depth, or quiet field>

Visual language:
- Palette and contrast: <limited colors and hierarchy logic>
- Light and atmosphere: <direction, softness, realism, depth>
- Materials and texture: <specific, meaningful surfaces>
- Typography: <font character, weight contrast, placement, legibility>

Constraints:
- Preserve every listed fact and exact string.
- Keep title, key data, and major Chinese copy sharp, legible, and unclipped.
- Maintain one clear visual center and intentional whitespace.
- Images and visual elements must carry the main expression, not act only as decoration.
- No watermark, unapproved logo, filler text, mockup frame, or unrelated object.

Avoid:
- nine-grid, equal three- or four-column, average split, and automatic card-grid layouts;
- full-screen rounded cards, equal-size modules, dense dashboards, and equal visual weights;
- blurred-photo-only backgrounds, meaningless icon clusters, random gradients, and decorative lines;
- crowded edges, tiny copy, arbitrary filling of whitespace, and stock-template appearance.
```

## Compilation rules

- Preserve the semantic contract and exact copy; add only visual decisions that clarify it.
- Translate “高级、大气、科技感、有设计感” and similar abstractions into explicit scale, position, contrast, crop, depth, lighting, material, and whitespace instructions.
- Describe proportions and relationships instead of relying on style adjectives.
- Keep exact copy separate from visual prose. Shorten copy only with permission.
- If the user's prompt is already detailed, normalize it and fill only missing executable layout details.
- Do not infer a card count from the number of content sections.
- For Chinese image-PPT pages, favor concise viewpoint-style titles and short labels; warn when raster generation is being asked to typeset long paragraphs.
- When the user explicitly requests two to five styles, compositions, or options, generate exactly that number. Establish a distinct layout blueprint and compile an independent, complete prompt for each output, then call CRS IMAGE once per output. Never use one prompt with the `-n` parameter to produce several random near-duplicates.
- Make every pair of requested outputs visibly different in overall composition and in at least one additional dimension: image treatment, spatial depth, color, material, lighting, or typographic relationships.
- Preserve a required unified brand palette; never change brand colors merely to manufacture variation. Keep all user-required formal copy, data, and facts identical across outputs.
- Use option names only in filenames or external delivery notes. Never place `方案一/二/三`, `风格一/二/三`, `方案 A/B`, `版本一/二`, `Option 1`, `Style 1`, `Version A`, or similar distinguishing text inside the artwork.
- Only when the user requests multiple styles, compositions, or option sets, include this exact sentence in every corresponding prompt: `画面中不得出现方案编号、风格编号、版本编号或任何用于区分不同方案的额外文字。`
- For a single image whose approved content does not contain words such as “方案”, “风格”, or “版本”, omit that sentence.

## Reference-image instructions

When a reference image is supplied, state which features to inherit: composition ratio, focal center, image share, title position, reading path, whitespace, crop, foreground/midground/background, color, and lighting. Do not reduce reference matching to color imitation.

Explicitly exclude unrelated reference text, data, logos, marks, and objects. Treat a user-approved ChatGPT web image as the main visual-quality benchmark while preserving the new page's approved content.

## Public-guidance basis

This compiler paraphrases public image-generation guidance about purpose, subject, setting, composition, framing, dimensions, lighting, colors, materials, exact text, information hierarchy, constraints, and reference roles. It does not contain or claim access to unpublished ChatGPT web system prompts.
