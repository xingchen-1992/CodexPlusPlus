# Lightweight visual check

Inspect each generated image once. The purpose is to catch obvious usability failures, not to score subjective taste or trigger repeated paid generations.

## One-pass checklist

1. Confirm that the requested content and aspect ratio are present.
2. Confirm one clear visual center and no obvious compositional collapse or severe imbalance.
3. Check for serious card stacking, equal-column repetition, equal-weight modules, overcrowding, or destroyed whitespace.
4. Check the title, key data, and major Chinese copy for obvious errors, severe garbling, clipping, or illegibility.
5. Check for unrelated text, logos, watermarks, filler copy, scheme labels, style labels, version labels, or other unapproved content.

## Regeneration threshold

Prepare a targeted regeneration only when an issue materially prevents use:

- core content is wrong or missing;
- key text is severely garbled or unreadable;
- composition clearly fails or has no usable focal center;
- the main content is cropped or outside the safe area;
- the aspect ratio is wrong;
- an explicitly forbidden element appears, including an option/style/version identifier.

Minor differences in decoration, texture, balance, or subjective aesthetics do not automatically justify regeneration. Do not assign a numeric score, calculate a threshold, or run a complex multi-stage review.

## Targeted revision

Name the single highest-impact defect, preserve the successful composition and assets, and rewrite only the relevant spatial or hierarchy instruction. If another CRS IMAGE call may incur cost, follow the existing cost-confirmation rule unless the user has already authorized automatic refinement.
