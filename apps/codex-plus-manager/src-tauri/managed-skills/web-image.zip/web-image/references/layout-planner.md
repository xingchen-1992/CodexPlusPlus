# Layout planner

Use this planner internally before compiling the CRS IMAGE prompt. Do not expose candidates or comparisons unless the user asks.

## Candidate decision

Create two or three visibly different candidate layouts. Consider immersive hero imagery, asymmetric image-and-text, timeline or milestone path, map and spatial distribution, big-number narrative, directional process chain, strategic path, or conclusion-plus-evidence composition.

Compare candidates by asking:

1. Which layout best emphasizes the page thesis?
2. Which creates the clearest first visual focal point?
3. Which matches the content's time, space, flow, contrast, progression, or hierarchy?
4. Can imagery carry the main narrative rather than merely decorate it?
5. Is the reading path natural and the whitespace protected?
6. Does it avoid card stacking, average columns, and equal visual weights?
7. Does it have the freer, content-led composition associated with strong ChatGPT web image output?

Select one candidate and discard the others before prompt compilation.

## Content-relationship routing

| Content relationship | Prefer |
|---|---|
| Time development | Continuous timeline or milestone path |
| Geographic or spatial | Map, connected locations, and real-site photography |
| Process or causality | Directional process chain with a clear start and outcome |
| Strategic progression | Steps, pathway, or spatial depth |
| Core achievements | Dominant numbers supported by real scenes |
| Workplace or site introduction | Immersive real-site hero image with concise key information |
| Core conclusion and evidence | Conclusion-led focal composition with data and image evidence |
| Comparison | Asymmetric contrast with explicit primary and secondary sides |

Do not create several identical cards merely because the content contains several parts.

## Layout blueprint

Before prompt compilation, define:

- first focal point;
- second focal point;
- main-image position, area share, crop, and viewpoint;
- title and body-copy safe zones;
- key-data position;
- reading order;
- primary whitespace area;
- foreground, midground, and background roles;
- dominant, supporting, and detail visual weights.

Never assign all modules the same size, color, or visual weight.

## Anti-template guardrails

Unless explicitly requested, reject candidates based on nine-grid layouts, equal three- or four-column layouts, average splits, full-screen rounded cards, equal-size adjacent modules, dense dashboards, blurred-photo-only backgrounds, meaningless small icons, random gradients, decorative lines, filled whitespace, or equal-weight content.

Every accepted blueprint must contain one unmistakable primary visual center, and its image or visual structure must perform a narrative function.
