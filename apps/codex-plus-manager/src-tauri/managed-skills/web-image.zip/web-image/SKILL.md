---
name: web-image
description: Create layout-heavy bitmap visuals with autonomous, content-led composition, typography, spacing, hierarchy, and finish benchmarked against images generated from the same prompt in ChatGPT on the web. Render through CRS IMAGE and optionally package accepted page images as an image-based PPTX only when the user explicitly requests a PPTX or presentation file. Use when the user invokes WEB IMAGE or asks for image PPT pages, business slides, infographics, posters, report covers, dashboards, or other design-led images.
---

# WEB IMAGE

Treat "WEB" as the visual-quality benchmark of ChatGPT web image generation, not as website, HTML, UI, or browser design. Preserve the user's facts, exact copy, assets, references, and constraints. Improve only the executable visual specification.

Target a finished image with a decisive visual center, intentional composition, controlled whitespace, clear hierarchy, meaningful image use, and coherent typography. Do not claim access to unpublished ChatGPT web system prompts, identical seeds, or pixel-identical results.

## Required references

For every layout-heavy request, read and apply these files in order:

1. `references/layout-planner.md` before choosing a composition.
2. `references/prompt-compiler.md` before writing the final CRS prompt.
3. `references/layout-rubric.md` once after generation for a lightweight visual check.

## Workflow

1. Extract the semantic contract:
   - intended use, audience, and page thesis;
   - exact text, facts, numbers, labels, logos, and supplied assets;
   - desired mood, palette, aspect ratio, and reference-image roles;
   - required and forbidden elements;
   - the original prompt verbatim for comparison.
2. Determine the delivery branch before generation:
   - If the user says “只要提示词” or otherwise asks for prompts only, plan and compile the prompt, then stop without generating an image or PPTX.
   - If the user says “逐页确认” or otherwise requests page-by-page confirmation, output only the current page's compiled prompt and wait for confirmation before generating it.
   - Otherwise continue to layout planning and CRS generation.
3. For a single output, internally create two or three clearly different candidate layouts using `references/layout-planner.md`, compare them against the content relationship, and select the strongest one. For an explicit request for two to five styles or options, follow `Multiple-style outputs` and establish a separate blueprint for every requested output. Do not show candidates or comparisons unless the user asks.
4. Form an internal layout blueprint for the selected composition. Define the first and second focal points, main-image position and share, title and text safe zones, key-data position, reading order, primary whitespace, foreground/midground/background, and unequal visual weights.
5. Compile the final prompt with `references/prompt-compiler.md`. Preserve the semantic contract while converting abstract style language into explicit spatial, proportional, lighting, material, and hierarchy instructions.
6. Run a preflight check before generation:
   - one clear page thesis and primary visual center;
   - explicit zones, proportions, image crop, reading path, and whitespace;
   - exact copy isolated from descriptive prose;
   - no equal-weight modules, automatic card grid, or conflicting style directions;
   - no unapproved text, logos, watermarks, or scheme/style/version labels.
7. Render with the local `crs-image` command. Use a prompt file for long or multiline prompts. Do not change the CRS IMAGE generation method.
   - For a 16:9 image-PPT page, use 4K and high quality unless the user chooses another size or a faster/cheaper draft.
   - For a fast draft, use 16:9 2K or the user's requested size.
   - For a non-presentation image without a specified aspect ratio, ask once before generation.
8. Inspect the generated image once using `references/layout-rubric.md`. Do not use numeric scoring or repeatedly regenerate for minor aesthetic differences.
9. Prepare a targeted regeneration only for a clear usability defect: missing or wrong core content, severely garbled key text, failed composition, cropped main content, wrong ratio, or an explicitly forbidden element. Preserve successful elements and change the highest-impact cause only. If another CRS call may add cost, follow the existing CRS IMAGE cost-confirmation rule unless the user already authorized automatic refinement.
10. Deliver according to the user's explicit output intent:
    - For “生成图片PPT”, “制作一页图片PPT”, or “输出图片”, deliver PNG by default.
    - Package accepted page images into PPTX only when the user explicitly asks for a PPTX or presentation file.
    - Do not infer PPTX merely from the words “PPT”, “slide”, “deck”, or “presentation” used to describe the visual format.
    - For multiple styles, deliver every option as an independently usable finished image. Keep option names only in filenames or the external delivery note, never inside the artwork unless explicitly requested.
11. Report the delivered file path, actual CRS size and quality, and any material limitation. Include the compiled prompt when requested or useful; do not report a score.

## Autonomous composition rules

- Choose layouts from content relationships, not from the number of content sections.
- Require one unmistakable primary visual center on every page.
- Let images and meaningful visual elements carry the main expression; do not use imagery merely as a blurred background decoration.
- Use unequal scale, contrast, position, and depth to distinguish primary, supporting, and detail content.
- Prefer disciplined asymmetry and free composition when it strengthens the message.
- Never fill intentional whitespace merely to make the page look busy.
- Unless the user explicitly requests them, forbid nine-grid layouts, equal three- or four-column layouts, average splits, full-screen rounded cards, equal-size adjacent modules, dense dashboards, meaningless icon clusters, random gradients, decorative lines, and equal visual weight for all content.

## Multiple-style outputs

When the user explicitly requests two to five different styles, compositions, or options:

- Generate exactly the requested number of outputs.
- Establish a distinct layout blueprint for each output before prompt compilation.
- Compile an independent, complete prompt for each output.
- Call CRS IMAGE once per output. Never use one prompt with the `-n` parameter to produce several random near-duplicates.
- Make each image a complete standalone deliverable.
- Make every pair of outputs visibly different in overall composition and in at least one additional dimension: image treatment, spatial depth, color, material, lighting, or typographic relationships.
- Preserve a required unified brand palette; never change brand colors merely to manufacture variation.
- Keep all user-required formal copy, data, and facts identical across outputs.
- Use option names only in filenames or external delivery notes.
- Never add `方案一/二/三`, `风格一/二/三`, `方案 A/B`, `版本一/二`, `Option 1`, `Style 1`, `Version A`, or similar distinguishing text inside the artwork.
- Add the conditional no-option-label sentence from `references/prompt-compiler.md` to every final generation prompt in this branch.

## Reference images

Treat a user-approved ChatGPT web result as the primary visual-quality benchmark. Analyze and inherit its composition ratio, focal center, image share, title position, reading path, whitespace, crop, spatial layers, color, and lighting—not only its palette.

Before planning or generation, classify every user-supplied image as either a visual reference or a required content image:

- For a visual reference, use it only to analyze composition, style, color, lighting, whitespace, or spatial depth; translate those findings into prompt instructions. Do not require the source image itself to appear in the final artwork.
- For a required content image, triggered by instructions such as “使用这些照片” or “照片必须出现在页面中”, treat the original image as actual content rather than regenerating a similar scene. Preserve its real buildings, people, equipment, environment, and other key content whenever possible. Never replace a real workplace photo with an invented AI workplace. If the current CRS command cannot accept the required number of images, explain the limitation before generation and choose a method that genuinely retains the originals; never claim the originals were used when they were not.

Declare each reference's role as composition, style, typography, or content. Preserve the new user's content and never copy unrelated text, data, logos, marks, or objects from a visual reference. When both the original prompt and web result are available, infer the added visual decisions and reproduce those decision types rather than copying pixels.

For a series, use the approved first image as visual DNA for palette, font character, image texture, lighting, margins, and finish while varying composition according to each page's content.

## Multi-page management

- Keep palette, typography character, image treatment, and material finish consistent across the deck.
- Do not repeat the exact layout on adjacent pages.
- Do not let consecutive pages all use left-text/right-image or the same card structure.
- Choose page-specific large-image, big-number, timeline, map, flow, evidence, comparison, or strategic-path compositions according to the content relationship.
- When page-by-page confirmation is requested, process one page only and wait before proceeding.

## Image-based PPTX packaging

Use this section only after the user explicitly requests a PPTX or presentation file. Use PptxGenJS with a 16:9 layout. Place each accepted page image at `x: 0`, `y: 0` across the full slide. Do not recreate the design with PowerPoint objects or add hidden text, overlays, margins, borders, captions, or navigation controls.

After writing the PPTX, check only that the file exists, the slide count matches the accepted images, and the layout is 16:9. Use deeper diagnostics only when packaging fails, the file cannot open, or the user reports a display problem.

## CRS boundary

Use CRS IMAGE as the rendering channel. Do not call `api.openai.com`, change the Codex reasoning model, or silently switch image backends. The `web-image` workflow owns layout planning, prompt compilation, lightweight review, and optional packaging; CRS owns image generation and file output.
