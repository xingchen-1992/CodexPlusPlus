#!/usr/bin/env python3
"""Run PaddleOCR in its own Python environment and emit normalized JSON."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
from typing import Any


def configure_runtime(enable_accel: bool) -> None:
    if not enable_accel:
        os.environ["FLAGS_use_mkldnn"] = "False"
        os.environ["FLAGS_use_onednn"] = "False"
        os.environ["PADDLE_PDX_ENABLE_MKLDNN_BYDEFAULT"] = "0"
    os.environ.setdefault("PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK", "True")


def normalize_box(value: Any) -> list[int] | None:
    if value is None:
        return None
    if hasattr(value, "tolist"):
        value = value.tolist()
    if isinstance(value, list) and len(value) == 4 and all(isinstance(v, (int, float)) for v in value):
        x1, y1, x2, y2 = value
        return [round(x1), round(y1), round(x2), round(y2)]
    if isinstance(value, list) and value and isinstance(value[0], list):
        xs = [point[0] for point in value]
        ys = [point[1] for point in value]
        return [round(min(xs)), round(min(ys)), round(max(xs)), round(max(ys))]
    return None


def extract_v3(item: Any) -> list[dict[str, Any]]:
    data = getattr(item, "json", None)
    if isinstance(data, dict):
        data = data.get("res", data)
    elif hasattr(item, "to_json"):
        data = item.to_json()
        if isinstance(data, str):
            data = json.loads(data)
        data = data.get("res", data)
    elif isinstance(item, dict):
        data = item.get("res", item)
    else:
        return []

    texts = data.get("rec_texts") or data.get("texts") or []
    scores = data.get("rec_scores") or data.get("scores") or []
    boxes = data.get("rec_boxes") or data.get("dt_polys") or []
    rows = []
    for index, text in enumerate(texts):
        box = normalize_box(boxes[index]) if index < len(boxes) else None
        if not str(text).strip() or box is None:
            continue
        score = float(scores[index]) if index < len(scores) else 0.0
        rows.append({"text": str(text).strip(), "score": score, "box": box})
    return rows


def extract_v2(results: Any) -> list[dict[str, Any]]:
    rows = []
    pages = results if isinstance(results, list) else [results]
    for page in pages:
        if not isinstance(page, list):
            continue
        for item in page:
            if not isinstance(item, (list, tuple)) or len(item) < 2:
                continue
            box = normalize_box(item[0])
            value = item[1]
            if box is None or not isinstance(value, (list, tuple)) or not value:
                continue
            text = str(value[0]).strip()
            score = float(value[1]) if len(value) > 1 else 0.0
            if text:
                rows.append({"text": text, "score": score, "box": box})
    return rows


def main() -> int:
    parser = argparse.ArgumentParser(description="Run PaddleOCR and write normalized OCR rows.")
    parser.add_argument("input", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--lang", default="ch", help="PaddleOCR language, such as ch or en.")
    parser.add_argument("--enable-accel", action="store_true")
    args = parser.parse_args()
    configure_runtime(args.enable_accel)

    from paddleocr import PaddleOCR

    input_path = args.input.expanduser().resolve()
    if not input_path.exists():
        raise FileNotFoundError(input_path)

    try:
        ocr = PaddleOCR(
            lang=args.lang,
            enable_mkldnn=args.enable_accel,
            use_doc_orientation_classify=False,
            use_doc_unwarping=False,
            use_textline_orientation=False,
        )
        results = ocr.predict(str(input_path))
        rows = []
        for item in results:
            rows.extend(extract_v3(item))
    except (TypeError, AttributeError):
        ocr = PaddleOCR(lang=args.lang, use_angle_cls=False, show_log=False)
        rows = extract_v2(ocr.ocr(str(input_path), cls=False))

    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(rows, ensure_ascii=False, indent=2), encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
